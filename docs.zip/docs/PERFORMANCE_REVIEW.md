# NPegged Performance Review

Reviewed 2026-10-16 against the current working tree, including staged performance
changes. This review distinguishes code observations from stored measurements.
See [OPTIMIZATION_PLAN.md](OPTIMIZATION_PLAN.md) for the current roadmap, revised
using the later [archive review](NEW_PERFORMANCE_REVIEW.md). The conclusions below
record the earlier inspection; direct generation has since progressed experimentally.

## Evidence and limits

`build/performance-acceptance.json` contains three runs, seven samples, and 2,000
iterations, on an AMD Ryzen 7 PRO 5850U with LDC 1.43.0. It reports `passed=false`.
At review time, 61 of its 62 recorded source hashes match: `src/npegged/peg.d`
differs. These are historical observations, not acceptance of the current tree.
`build/perf-check.json` matches only 53 of 62 hashes and is an older comparison,
not a controlled before/after experiment. Both files are local build artifacts.
No new timing run was performed for this documentation review.

| Stored acceptance case | Mode | Ratios in runs 1 / 2 / 3 |
| --- | --- | --- |
| PEGGrammar.Deep | validation | 5.472 / 5.331 / 5.089 |
| PEGGrammar.ManyRules | validation | 5.117 / 4.878 / 4.738 |
| Numbers.ScientificLong | validation | 1.098 / 1.130 / 1.105 |
| PEGGrammar.LongLiteral | validation | 0.598 / 0.597 / 0.604 |

This distribution motivates prioritizing recursive grammar control and fixed costs.
It does not prove a particular instruction, allocator, or combinator is responsible.
The old blanket 5–12× validation description and promises of 1-cycle dispatch or
hardware-bandwidth DFA throughput are insufficiently grounded for the current tree.
Legacy generic-tree measurements must remain separate from compact-output rows.

## Code findings

| Area | Current implementation | Remaining question |
| --- | --- | --- |
| `grammar.d`, `analysis.d` | Adjacent shareable prefix factoring, FIRST dispatch, selective memoization, conservative regular-leaf analysis | How much control work remains after optimization? |
| `dfa.d` | Bounded CTFE DFA construction and budget-capped runtime scans | Which rules fall back and how frequently? |
| `peg.d: State`, `and`, `repeat` | Recognition returns aggregate nodes through generic composition; ticks and failure tracking remain | Which aggregate copies and checks survive inlining? |
| `workload_grammars.d: BenchPEG` | Header fast paths, boundary lookahead, nested Params/Action and expression recursion | How often are boundaries and whitespace rescanned? |
| `records.d`, generated selectors | Transactional compact output, growth copies, memo snapshots | What fraction of output traffic is speculative or copied? |
| Legacy `ParseTree` path | Child/match construction and propagation retained for compatibility | Which consumers need materialized trees versus selected records? |

The DFA wrapper accelerates recognition and compact output without selected inner
records. It retains the original combinator for legacy tree capture and unsupported
execution conditions. Some failed scans also replay the original parser. This is
intentional semantic preservation, but makes isolated scanner speed an incomplete
predictor of whole-parser speed.

`RecordBuffer` owns no memory independently: its backing storage and snapshots
belong to explicit arenas. Rollback changes logical length; it does not reclaim
all arena allocations. Growing buffers retains old allocations until arena teardown.
On a typical 64-bit ABI, `CompactNode` is 32 bytes (`uint` plus three `size_t`s with
alignment), correcting the previous review's 24-byte claim. Recognition likewise
is a small aggregate, not automatically a register-only operation.

## Revised conclusion

The current optimizer addresses lexical repetition and some alternatives, but still
executes recursive syntax through generic result-producing combinators. The strongest
next architectural experiment is direct structured D generation from the analyzed
grammar, with small internal recognition results and explicit execution policies.
Follow with measured boundary reuse and native compact-output lowering. Scanner code
selection, optional lexing, and precedence lowering are secondary experiments with
semantic and code-size gates. No speedup is claimed before differential validation
and a fresh, source-matched performance gate.

## Follow-up review reconciliation (2026-10-16)

[NEW_PERFORMANCE_REVIEW.md](NEW_PERFORMANCE_REVIEW.md) is a static archive review
with no executed benchmarks. Current source inspection confirms the broad memo-entry
invalidation loop and selected-output snapshots in `State.memoizedRule`, copying in
`RecordBuffer.snapshot`, and grammar-wide action/conservative eligibility barriers
in `grammar.d`. Quadratic growth is a hypothesis to reproduce with scaling tests,
not a measured characterization of every grammar or the existing arithmetic corpus.

The revised roadmap prioritizes attribution and left-recursion scaling, then local
effect analysis and continued cursor lowering. Direct recognition/compact control
already exist experimentally; they are no longer new-backend deliverables. Compact
output and selective memoization should become easier to select, while promotion of
public defaults remains gated on acceptance and compatibility. Diagnostic replay,
combined lexing, and iterative expression lowering require explicit semantic proofs
or opt-in contracts. No performance or code validation was run for this docs update.
