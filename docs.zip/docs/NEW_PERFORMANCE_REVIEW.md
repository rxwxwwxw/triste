After inspecting the D source in `npegged.zip`, I think npegged could get substantially closer to handwritten lexer/parser performance without giving up PEG expressivity. The important change is to make the generated parser execute a much simpler representation of the grammar, reserving the general-purpose PEG machinery for cases that actually need it.

You already have several good foundations:

- Compile-time DFA generation for regular expressions.
- FIRST-byte analysis and predictive choice dispatch.
- A direct-code backend that lowers grammar expressions into imperative D.
- Selective packrat memoization and left-recursion support.
- Compact parse records, in addition to traditional parse trees.
- Arena allocation and a recognition-only parsing mode.

The problem is that these optimizations don't yet combine into a sufficiently lightweight hot path.

## 1. The largest performance opportunities

Based on static inspection, this is how I would prioritize the work. These are suspected costs from the implementation, not measured profiling results.

| Priority  | Area                         | Current cost                                                      | Recommended change                                                        |
| --------- | ---------------------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------- |
| Very high | Default parser configuration | Full memoization, combinator backend, full tree                   | Make a direct, selective, compact parser the performance-oriented default |
| Very high | Left-recursion handling      | Repeated global memo invalidation and record copying              | Use dependency-aware growth and avoid copying intermediate trees          |
| Very high | Parse-tree construction      | Many small arena allocations, arrays and copies                   | Build only explicitly requested syntax nodes                              |
| High      | Generated rule execution     | Multiple result objects, bounds/budget checks and function layers | Generate cursor-based imperative code                                     |
| High      | Lexer                        | DFA scanning mixed with recursive PEG evaluation                  | Generate specialized token scanners with a regular fast path              |
| High      | Error tracking               | Failure bookkeeping during ordinary parsing                       | Separate normal parsing from detailed diagnostic collection               |
| Medium    | Memo lookup                  | Hash lookup, pointer chasing and per-entry allocation             | Use rule-indexed sparse or dense memo tables                              |
| Medium    | Action handling              | Actions can disable fast parsing across the entire grammar        | Isolate action-dependent rules                                            |
| Medium    | Scanner and rule dispatch    | Indirect calls and generic bitmask checks                         | Specialize common patterns and fuse adjacent operations                   |

I would not start with SIMD, custom allocators, or aggressive inlining. The existing architecture has larger algorithmic opportunities.

## 2. First, use the fastest path that already exists

In `grammar.d`, your grammar generator defaults to:

```
string grammar(
    Memoization memo = Memoization.yes,
    alias Selector = void,
    ParserBackend backend = ParserBackend.combinators
)(string definition)
```

That is a reasonable compatibility-oriented default, but not a good performance default.

For grammars that don't require memoization everywhere, the fastest configuration to test first is:

```
mixin(grammar!(
    Memoization.selective,
    void,
    ParserBackend.direct
)(grammarSource));
```

For recognition only:

```
ParseContext ctx;
auto result = check!(MyGrammar.opCall)(ctx, input);
```

For a compact syntax tree, compile with a selector and then use `parseRecords`:

```
uint selectNode(string name) @nogc nothrow pure
{
    switch (name) {
        case "MyGrammar.Expression": return 1;
        case "MyGrammar.Statement":  return 2;
        case "MyGrammar.Identifier": return 3;
        default: return uint.max;
    }
}

mixin(grammar!(
    Memoization.selective,
    selectNode,
    ParserBackend.direct
)(grammarSource));

ParseContext ctx;

// Input must remain alive for the duration of the result's use.
auto result = parseRecords!(
    MyGrammar.opCall,
    selectNode,
    false
)(ctx, input);
```

This avoids the input copy, avoids the traditional `ParseTree` representation, and gives the compiler much more opportunity to generate efficient code.

Selective memoization is not universally faster: grammars with substantial overlapping backtracking may benefit from additional memoization. That needs benchmarking.

I would establish separate benchmarks for `parse`, `check`, and `parseRecords`, because they measure meaningfully different workloads.

## 3. Fix the left-recursion algorithm

This may be the most important source-level issue, especially if your benchmarks involve expressions, arithmetic, or long left-associative sequences.

In `peg.d`, `State.memoizedRule` contains:

```
for (auto dependent = entries;
     dependent !is null;
     dependent = dependent.next)
{
    if (!dependent.active && dependent.position >= pos)
        dependent.valid = false;
}
```

Every time a left-recursive seed grows, this walks the entire memo-entry list.

For an expression like:

```
Expr <- Expr '+' Number / Number
```

the seed may grow repeatedly as the expression gets longer. Meanwhile, the number of memo entries also increases.

This can make invalidation alone approach \\(O(n^2)\\), rather than \\(O(n)\\), for certain inputs.

There's a second issue in the same routine:

```
entry.output = snapshotOutput(outputBase);
```

`RecordBuffer.snapshot` copies the selected nodes. If each growth extends an existing expression tree, the total amount of copying can be

\\[ 1+2+\cdots+n = \frac{n(n+1)}{2}. \\]

You can therefore have quadratic work from both memo invalidation and output snapshots, independently of the actual grammar.

### How I would redesign it

Use a left-recursion head associated with a particular input position and recursion component, rather than invalidating every memo entry at or after that position.

Track dependencies between rules in the same recursive strongly connected component. When a seed grows, invalidate or reevaluate only entries that actually depend on that seed.

For output, avoid repeatedly copying the entire accumulated tree. Possibilities include immutable AST fragments referenced by memo entries, a persistent record structure, or recognition-first parsing followed by deferred construction of the final successful subtree.

For common left-recursive expression grammars, I would go further and generate a specialized iterative parser:

```
auto lhs = parsePrimary(cursor);

while (true)
{
    auto op = parseOperator(cursor);
    if (!op.found)
        break;

    auto rhs = parsePrimary(cursor);
    lhs = combine(lhs, op, rhs);
}
```

The generator would only apply this transformation when it can prove equivalence to the original PEG rule, including associativity and action behavior.

General left recursion would still use seed growing, but with much more targeted dependency tracking.

## 4. Stop generating intermediate parser results

Your direct backend in `grammar.d` is already moving in the right direction.

For instance, `emitDirect` generates code involving variables such as:

```
size_t resultEnd;
size_t resultFail;
bool resultOk;
```

However, it also creates many nested groups of these variables, invokes rule wrappers, and frequently falls back to functions returning `RecognitionNode`.

In `peg.d`, the recognition node contains:

```
struct RecognitionNode
{
    size_t begin, end, failEnd;
    bool successful;
}
```

That's typically a 32-byte result on a 64-bit platform, passed through many layers of code.

Ideally, successful parsing should largely consist of incrementing one cursor, comparing input bytes, and occasionally branching.

For example, a rule equivalent to:

```
Identifier <- [a-zA-Z_] [a-zA-Z_0-9]*
```

should generate something closer to:

```
bool parseIdentifier(scope const(char)[] input,
                     ref size_t pos) @nogc nothrow
{
    size_t p = pos;

    if (p == input.length || !isIdentifierStart(cast(ubyte)input[p]))
        return false;

    ++p;

    while (p < input.length &&
           isIdentifierContinue(cast(ubyte)input[p]))
        ++p;

    pos = p;
    return true;
}
```

Here, `isIdentifierStart` and `isIdentifierContinue` would themselves be inlined compile-time-generated predicates.

No result object, allocation, failure tree, memo lookup, or intermediary array is necessary.

The necessary bookkeeping could happen at the rule boundary rather than at every combinator boundary.

### Compile to a cursor-oriented intermediate representation

I would make the parser generator internally lower grammars through these stages:

PEG grammar and semantic actions

Grammar IR — ordered choices, sequences, predicates, recursion

Optimized parsing IR — cursor movement, scanner loops, rule dispatch, backtracking checkpoints

Direct D code

Deterministic regions, inlined matching and AST emission

General PEG fallback

Complex recursion, backtracking, predicates and dynamic actions

The key is not to change the language accepted by a grammar. It's to generate the simplest equivalent implementation for each region of that grammar.

Your current `emitDirect` can evolve into this design rather than being discarded.

## 5. Separate parsing, tree construction, and diagnostics

The ordinary `ParseTree` path is expensive.

Consider what happens in `and`, `repeat`, `defined`, and `transform` in `peg.d`.

In full-tree mode, combinators collect `matches` and `children` arrays, while `defined` can allocate another node just to preserve the named rule boundary.

Furthermore, `State.Builder.put` grows storage geometrically, allocating new arrays and copying previous contents.

For a parser that produces a large concrete syntax tree, that represents a lot of copying and memory traffic.

I would make syntax-tree construction use a compact event stream:

```
enum EventKind : ubyte
{
    start,
    finish,
    token
}

struct Event
{
    EventKind kind;
    uint rule;
    uint offset;
}
```

A parser records events into a contiguous buffer. Failed alternatives roll back to a previous event index.

Once parsing succeeds, the final tree can be materialized from the event stream if needed.

You already have most of this architecture in `records.d`; I would make it the primary output system and keep the full `ParseTree` as a compatibility layer.

On an ordinary successful parse, a retained syntax node ideally costs just one compact record or a pair of events. Unretained grammar rules should cost no storage.

For inputs below 4 GiB, 32-bit offsets and indices could also substantially reduce record size compared with the current `CompactNode` containing three `size_t` fields.

### Error handling deserves a separate execution path

Right now, the engine eagerly tracks farthest failures. A mismatch in an alternative that the parser later abandons still updates global diagnostic state.

That is useful for informative errors but relatively expensive.

A performance mode could do minimal error tracking during the first parse. If parsing fails, it could rerun the input with full diagnostics enabled.

This preserves the accepted language and can reproduce detailed errors on failure. It would not necessarily preserve `failEnd` observed on successful parses, so an exact-diagnostics mode should remain available.

There is an important qualification: arbitrary semantic actions must not be executed twice. The diagnostic replay would need either a recognition-only implementation with equivalent semantics or a fallback for action-dependent rules.

## 6. Make the DFA lexer more like a conventional lexer

Your DFA code is useful, but it is currently employed primarily to accelerate eligible regular subexpressions.

In `grammar.d`, `regularTable` requires a repeated component before it generates a DFA. That means fixed literals and several other common token patterns still use the generic parser machinery.

In `dfa.d`, failed DFA recognition can also replay the original PEG expression:

```
return Original(s, pos);
```

That preserves existing behavior, but on speculative failures it can duplicate scanning work, particularly in compact-record mode.

I would make DFA failure return sufficient information directly wherever exact equivalence can be established.

More importantly, I would support a combined lexical DFA for sets of ordinary tokens, rather than compiling each token independently.

For example, when recognizing identifiers, numbers, whitespace, punctuation, and keywords, a combined scanner can return a token kind and end offset. Grammar parsing then works on those token kinds rather than repeatedly examining the underlying bytes.

This is where a substantial portion of the speed difference between a scannerless PEG and lex/yacc can disappear.

There is one semantic complication worth preserving carefully: PEG ordered choice is not equivalent to ordinary maximal-munch tokenization. Your combined scanner must encode priority and contextual restrictions correctly, or only combine regions that static analysis proves equivalent.

For context-sensitive lexing, semantic predicates, or ambiguous lexical regions, keep the original PEG machinery available. A hybrid token/byte parser is a reasonable solution.

## 7. Remove whole-grammar optimization barriers

I noticed an especially significant restriction in `grammar.d`.

The generator detects whether any rule contains an action:

```
bool actionGrammar;
foreach (rule; rules)
    foreach (i; 0 .. rule.body.length)
        if (startsWith(rule.body[i .. $], "action!("))
            actionGrammar = true;
```

That single boolean subsequently inhibits direct-code generation for the entire grammar.

It also causes recognition and compact parsing to use tree fallbacks for action-containing grammars.

This seems unnecessarily broad.

A semantic action in one rule should not prevent the identifier, whitespace, number, and ordinary expression rules elsewhere from being compiled efficiently.

I would replace `actionGrammar` with per-rule effect analysis, distinguishing pure recognition, syntax-tree actions, parse-controlling actions, and potentially side-effectful actions.

Then propagate dependencies through the rule call graph. Only action-dependent regions would need the conservative implementation.

Similarly, `analyzed.conservative` is used in ways that can affect optimization across the grammar. I'd prefer local proof obligations rather than a global conservative flag wherever possible.

This would allow a large grammar with a handful of difficult constructs to remain fast everywhere else.

## 8. Reduce the cost of memoization

The current memo table uses dynamically allocated linked entries with a hash table and per-entry pointers.

For every memoized rule call, that involves key hashing, a lookup, checks for active or invalid states, and sometimes allocation.

For a deterministic parser, this is overhead that a handwritten recursive-descent parser doesn't incur.

I would use integer rule IDs and memoization policies assigned per rule.

For rules that are frequently reused at multiple positions, sparse open-addressing tables can be a good default. For heavily recursive rules with dense position coverage, indexed arrays can be faster.

Crucially, keep a distinction between rules requiring memoization for left-recursion correctness and rules that benefit from it for avoiding backtracking.

It may also be useful for the generator to recognize explicit commit points: once a valid discriminator has selected a branch, later failure should not retry alternatives that are provably impossible. This is a natural way to generate predictive parsing without sacrificing general PEG choice elsewhere.

## 9. Performance testing I would do before a major rewrite

I couldn't execute a D benchmark from the supplied archive in this environment, so I wouldn't assign numerical speedup estimates yet.

I'd build a benchmark harness around the same grammars and inputs, compiled with LDC in release optimization mode, and use Linux `perf` to inspect CPU time and cache behavior.

The key comparisons would be:

| Variant                                          | Purpose                                |
| ------------------------------------------------ | -------------------------------------- |
| Existing default `parse`                         | Compatibility baseline                 |
| Selective-memoized `parse`                       | Quantify memoization overhead          |
| Direct `check`                                   | Measure pure recognition speed         |
| Direct `parseRecords`                            | Measure actual AST-producing speed     |
| Proposed cursor-based generated code             | Measure remaining abstraction overhead |
| Handwritten lexer + recursive descent or Pratt   | Practical speed target                 |
| flex/bison or comparable lex/yacc implementation | Conventional generated-parser baseline |

I'd measure valid inputs separately from invalid inputs, and test long left-associative expressions specifically.

Internally, I would instrument per-rule call counts, memo hits, seed growth iterations, invalidation counts, snapshot bytes copied, arena allocation counts, DFA fallbacks, and tree-record counts.

These counters should quickly identify whether the time is going into recognition, backtracking, allocations, memo handling, or output construction.

## 10. What I would ultimately aim for

I would retain npegged's declarative grammar syntax and PEG semantics, but generate three kinds of execution paths internally.

Fast deterministic parsing would be used for lexical rules, predictable alternatives, simple repetition, and structured expression grammars. It should look very similar to handwritten parsing code after compilation.

General PEG parsing would handle ordered alternatives that really need backtracking, lookahead predicates, indirect recursion, and other complex constructs. Memoization would be selective and dependency-aware.

Semantic construction would be separated from recognition wherever possible, using compact records or deferred actions, with full-tree execution reserved for rules that genuinely depend on it.

The main distinction is that expressivity belongs in the grammar language, not necessarily in every instruction executed by the generated parser.

For a mostly deterministic programming-language grammar, getting close to handwritten parser speed is a plausible goal. For arbitrary PEG grammars with pathological backtracking or extensive semantic actions, the general machinery will still have unavoidable costs.

### My preferred implementation order

I would begin with fixing the left-recursion invalidation and snapshot-copying behavior, followed by making compact/direct parsing the normal production path. Then I would make action and conservative-analysis restrictions local to individual rules, move the generator toward scalar cursor-based parsing throughout, and finally introduce combined lexical scanning.

Those changes attack the fundamental differences between your current execution model and a handwritten parser. Optimizing byte-class checks, DFA transition tables, or allocations further should be much more productive after that restructuring.

The long-term target would be to have npegged act less like a fast interpreter for PEG combinators and more like an optimizing compiler that happens to accept PEG grammars.
