# NPegged Performance Optimization Plan

Revised 2026-10-17 using [NEW_PERFORMANCE_REVIEW.md](NEW_PERFORMANCE_REVIEW.md),
the source-based [Mouse 2.3 review](MOUSE_REVIEW.md), current source inspection,
and the experiments in
[PERFORMANCE_IMPLEMENTATION.md](PERFORMANCE_IMPLEMENTATION.md). This supersedes
the earlier roadmap. [PERFORMANCE_REVIEW.md](PERFORMANCE_REVIEW.md) retains the
prior review and its measurement provenance.

## Objective and current position

Keep the acceptance target: every equal-output NPegged/handwritten case must be
at most 5× slower in each of three runs with at least seven samples. Aim for 2×
on recursive validation cases as an experimental target, not a forecast. Measure
recognition, selected spans, compact trees, and legacy full trees separately.

The new review is static inspection of an archive, not a profile or benchmark of
this checkout. Its suspected costs need measurement. Source inspection confirms
broad memo invalidation during recursive seed growth, compact-record snapshot
copies, and grammar-wide action/conservative barriers. The current invalidator
unlinks retired entries from lookup and subsequent walks; remaining active-list
work and arena-retained storage still need source-matched measurement. The impact
of these costs depends on the grammar and output obligation.

Direct generation is already implemented experimentally: scalar recognition and
record calls, primitive/control lowering, tracing-free eligible calls, and bounded
zero-width batching. Factoring, FIRST dispatch, DFA scanning, compact selectors,
and selective memoization also exist. Extend these rather than restarting them.
The implementation record reports 383/387 checks passing for the scalar-record
snapshot, with failures on small PEG validation cases; later experiments have
separate verification status. No snapshot is accepted by those partial results.

## Revised priorities

| Order | Workstream | First deliverable and promotion evidence |
| --- | --- | --- |
| 0 | Source-matched baseline and cost attribution | Extend existing recursion matrix/counters with per-rule rescans, reuse and backtracking |
| 1 | Left-recursion invalidation and output growth | Independent dependency/output prototypes; compare restricted recursive ascent only after attribution |
| 2 | Performance configuration and compact output | Document opt-in direct/selective APIs; measure legacy and compact costs separately |
| 3 | Local effect and conservative analysis | Explain eligibility/conflicts; add failure/productivity facts and literal-prefix proofs; retain fast pure regions |
| 4 | Cursor-oriented lowering and execution policies | Remove measured wrapper/result traffic; retain exact checked behavior |
| 5 | Memo layout and repeated boundary work | Profile-selected policy/table/cache experiments with bounded memory |
| 6 | Scanner failure and combined lexical regions | Proven PEG-equivalent fast failures and opt-in combined scanning |
| Conditional | Diagnostic replay and expression lowering | Explicit semantics, action safety, and whole-parser benefit |

Order 0 precedes algorithm changes. Prioritize left-recursion scaling even if the
existing gate does not expose it; reproduce the suspected problem before committing
to a redesign. Continue small-input acceptance work independently of that redesign.

## 0. Establish the measurement contract

Capture source hashes and a fresh baseline on an idle machine. Compare full-memo
combinator `parse`, selective combinator `parse`, direct selective `check`, and direct
selective `parseRecords`. Add intermediate variants to isolate backend, memo policy,
and output effects. Compare speed only within equal language/output obligations;
legacy tree versus recognition is a cost breakdown, not an acceptance ratio.
Borrowed and owned input are distinct lifetime contracts; report input copying,
construction, flattening/materialization, and disposal included in each timing.

Use optimized LDC builds and Linux `perf` where available to measure cycles,
instructions, branches/misses, and cache behavior. Report ns/parse for tiny inputs
and throughput for long inputs. Keep instrumentation out of timed binaries.
Extend diagnostic counters for per-rule calls, bytes revisited, memo hits/misses,
seed iterations, entries visited/invalidated, snapshot bytes, restored records,
record growth copies, speculative output, arena allocations, and DFA fallback
reasons/replayed bytes. Record unsupported profiling separately from clean checks.

The checkout already provides aggregate `NPeggedMetrics` counters for memo calls,
hits, seed growth, invalidation visits/entries and snapshot bytes, plus
`scripts/recursion-matrix.sh` for separate timed/diagnostic backend and memo-policy
runs. Verify source hashes and actual report completeness before reusing results.
The implementation record's 256→512-term baseline reproduces near-quadratic
indirect-recognition and record-payload growth in that historical snapshot; it does
not isolate a cause or characterize the current invalidator.

Following Mouse's `ParserTest` design, distinguish revisits to a rule/position
without reuse from actual memo hits. Add successful calls, failures with/without
backtracking, total/max backtrack distance and its input location. Rank rules by
rescanned work and join those rankings to static conflict reports. Distance is a
work proxy, not elapsed time or an exact count of bytes examined. Use generated
integer IDs and parse-owned optional arrays, with no default-path profiling overhead.
Exact visited-position sets need an explicit memory budget; label sampled estimates
and measure profiling overhead separately. Keep failed-growth evaluations distinct
from ordinary backtracking so the report does not recommend evicting required seeds.

Extend the corpus with direct and indirect left recursion, nullable recursive
components, long left-associative expressions at geometrically increasing sizes,
and malformed suffixes. Include action-bearing grammars with large pure regions.
For recursion, measure recognition, selected records, and full-tree execution;
plot time, invalidation work, snapshot bytes, and peak retained memory against size.
Do not assume the existing arithmetic workload exercises seed growth.
A flex/bison-style comparator is optional follow-up after matching semantics and
outputs; it must not block the existing handwritten acceptance gate.

## 1. Bound left-recursion bookkeeping and output copying

`State.memoizedRule` walks the entire entry list after recursive seed growth and
invalidates completed entries at or after the seed position. `snapshotOutput`
copies the selected output after each successful candidate, through
`RecordBuffer.snapshot`. Repeated growth can therefore accumulate quadratic work;
confirm it with the scaling corpus and counters before assigning speed estimates.

Prototype recursion heads keyed by input position and recursive component, with
explicit dependency tracking for entries affected by a growing seed. Static SCC
membership alone does not prove the full dynamic dependency set: dependencies can
cross component and position boundaries. Preserve a conservative fallback until
transitive invalidation, active seeds, nested heads, and termination are proven.
Measure dependency bookkeeping and retained storage as well as saved list walks.

Separately prototype immutable/shared record fragments or deferred final output to
avoid copying every growing prefix. Preserve ordered record shape, parent indexes,
lookahead suppression, rollback, memo replay, and sticky allocation failures.
Recognition-first construction is eligible only if replay preserves actions,
resource limits, and output semantics; arbitrary callbacks cannot execute twice.
Retain arena/RAII ownership and valid fragment lifetimes across rollback.

Deliver independent invalidation and output-copy experiments before combining them.
Require differential tests for direct/indirect/mutual recursion, nullable cycles,
failed growth, overlapping alternatives, nested records, actions/tracing, and finite
memory/step/depth limits. Show scaling improvement on reproduced pathological cases
and no unexplained regression in ordinary recursive or nonrecursive cases.

### Conditional alternative: generated recursive ascent

Mouse's recursion classes identify entries, exits and seeds, then generate suffix
parsing and ascent through predecessors. After cost attribution, compare a separate,
action-free direct-left-recursion prototype with dependency-aware seed growth;
do not combine both changes in the first measurement. Reuse the existing left-edge
SCC analysis, adding the expression-level information needed for the proof.

Promotion requires equivalent PEG priority, associativity, output shape, failure
positions, tracing, and step/depth/memory behavior. Measure stack growth on long
chains, generated size and compiler cost as well as invalidation/snapshot savings.
Mouse rejects recursive forms and action combinations that triste supports: retain
the general backend for nullable-leading forms, indirect/mutual recursion and actions
until individually proved. Acceptance alone is insufficient to establish equivalence.
A failed proof or no whole-parser benefit ends the experiment without narrowing
triste's grammar language. This is distinct from Pratt/operator-table lowering.

## 2. Make the performance path easy to select

Document and benchmark `grammar!(Memoization.selective, void,
ParserBackend.direct)(definition)` with `check` for recognition. For compact output,
supply an explicit selector and use `parseRecords`; record the input ownership
choice. Borrowed input must outlive all result use. Selective memoization can lose
on overlapping backtracking; retain full and explicit per-rule policy experiments.

Keep existing public defaults during experimentation. Promote an opt-in performance
preset only after current-tree correctness and performance acceptance. A later
change to defaults needs a documented migration covering output shape, input
ownership, memo behavior, diagnostics, actions, and fallback coverage. Selecting
a backend cannot silently change an API from full trees to selected records.

Continue native compact output; arithmetic/CSV equal-output adapters already exist.
Measure discarded records, growth copies, memo snapshots, and final materialization.
Compare contiguous storage with chunks/shared fragments only where profiles justify
it, including flattening when callers require a slice. Keep legacy ParseTree as an
explicit compatibility path: transformed/discarded matches cannot always be rebuilt
from contiguous input spans. An event stream is an alternative representation to
measure, not a mandatory replacement of the existing records subsystem.

`CompactNode` normally occupies 32 bytes on a 64-bit ABI (one `uint`, three
`size_t`s). A four-`uint` form can occupy 16 bytes, but requires checked offset/node
limits and a wide fallback or explicit error; never truncate inputs or indexes.

## 3. Localize optimization barriers

Replace grammar-wide `actionGrammar` decisions with per-rule effect facts, propagated
to callers through the analyzed graph. Distinguish pure recognition, capture-dependent
actions, parse-controlling effects, and unknown/side-effectful callbacks. Treat opaque
external calls and parameterized rules conservatively until their contracts are known.
Localize `analyzed.conservative` only where local proof supports the optimization.

Use explicit adapters at effect boundaries so pure identifier/whitespace/number rules
can execute directly while effectful regions retain their established semantics.
Preserve captures, action order/count, seed-growth callbacks, dynamic tracing,
memo identities, and CTFE behavior. Do not mark actions pure merely because their
syntax appears harmless. First acceptance fixture: one action-bearing recursive
grammar with pure lexical regions, compared across all supported output modes and
finite limits, with callback logs and generated fast-path coverage checked.

### Explain analysis and extend only the missing proofs

FIRST-byte sets, continuation analysis, predictive dispatch and Tarjan SCCs already
exist. Build on them rather than porting Mouse's dense matrices or adding a second
analysis engine. First emit a text or machine-readable report with rule/expression
identity, optimization eligibility/fallback reason, following context and colliding
terminal pairs. Correlate potential conflicts with measured rescans. A possible
LL(1) conflict is neither PEG ambiguity nor a grammar error.

Add conservative failure/productivity facts, with unknown states for opaque calls,
parameters and effects. Use them to explain hidden alternatives after never-failing
branches, redundant optionals, nullable repetition and non-progress cycles. Start as
warnings unless the existing contract already rejects the form. Distinguish calls
before input consumption from cycles whose surrounding context cannot consume;
retain graph witnesses for diagnostics rather than requiring dense transitive closure.

Then test richer terminal-prefix proofs where byte FIRST sets overlap: literals
`"ab"` and `"ac"` are distinguishable beyond the first byte. Compare bounded
lookahead or a trie with existing factoring and direct literal lowering. Preserve
priority for prefix cases such as `"a" / "ab"`; never substitute maximal munch.
Unknown tails, predicates, EOF, complemented classes, UTF-8 ranges and effects
require explicit proof or fallback. Diagnostics and finite budgets must remain exact.

First fixtures cover empty/never-failing alternatives, nullable loops and tails,
productive/unproductive cycles, shared literal prefixes, prefix alternatives,
complemented-class/range boundaries and EOF. Require stable explanation witnesses,
short exhaustive backend comparisons, and bounded analysis time/memory on large
grammars. User-facing explanations can ship independently of new fast paths.

## 4. Continue cursor-oriented generation

Evolve `emitDirect` into an explicit optimized parsing IR: cursor movement, scanner
loops, saved-cursor branches, diagnostic merges, output checkpoints, rule dispatch,
and resource/depth checks. Lower deterministic regions to ordinary D; retain generic
PEG adapters at unsupported boundaries. Current scalar lowering is the starting point.
Inspect optimized code before removing aggregate returns or wrappers: source-level
`RecognitionNode` temporaries do not prove surviving machine-code copies.

Preserve rule identity for memoization and output boundaries. Bound expansion by
recursion SCCs and emitted size; measure generated source/object size, build time,
and peak compiler memory on DMD/LDC/GDC. Avoid aggressive inlining or a bytecode VM
without evidence. Target surviving tiny-input fixed costs and recursive PEG control.
Require repeatable 20% improvement on a targeted case for a substantial expansion;
report per-case regressions rather than hiding them in an aggregate.

Retain exact diagnostics and checked budgets as the reference policy. `size_t.max`
is still finite; additions must not wrap. Long scanner/loop work must be bounded
before it executes, rather than checked only at rule exits. Preserve existing step
accounting until an explicit alternative contract is introduced. Keep depth checks,
sticky errors, and dynamic-tracing fallbacks where callbacks can change tracing.

## 5. Optimize memo lookup and repeated probes after attribution

Distinguish mandatory memoization for left-recursion correctness from optional
backtracking caching. Prototype integer rule IDs with sparse open-addressed storage;
compare dense position-indexed storage only for demonstrated dense use. Include
initialization, growth, resource failures, retained memory, and dependency tracking.
Do not replace the current table merely because hashing appears in the source.

Use Mouse's bounded circular phrase caches as an optional experiment, not a new
default: compare capacities 0, 1, 2, 4 and 8 for profile-selected ordinary rules.
Measure lookup work, eviction/rescans, retained bytes and throughput on both local
reuse and adversarial shared-prefix inputs. Bounded caches lose general packrat
linear-time protection. Keep mandatory active recursion state separate and
non-evictable; cache entries must replay required output and diagnostics and obey
effect contracts. A bound on entries does not bound arena retention or referenced
output. Reject the policy if budget behavior, correctness or worst-case work is
unacceptable; retain full memoization as an explicit option.

Instrument `TopBoundary`, `ParamAhead`, whitespace, and header probes. Compare fused
probes with bounded per-parse caches only for pure context-independent results.
Keys must include relevant state; preserve failure merges and suppression. Avoid
blanket packrat allocation on currently allocation-free workloads. Generate commit
or predictive dispatch only when later alternatives are proven impossible, preserving
ordered PEG failure behavior.

## 6. Reduce scanner replay and test combined lexical regions

Measure `dfaToken` fallbacks by semantic proof, state budget, capture requirements,
tracing/resource policy, and failed-scan replay. Return failure information directly
only where it reproduces partial failures, diagnostics, records, and finite work
accounting. Fixed literals already have direct primitive lowering; compare that path
before broadening DFA construction to every literal.

Compare table DFAs, state switches, byte classes, and specialized runs on measured
hot tokens. Then prototype an opt-in combined scanner for proven lexical regions,
returning token kind and byte interval. Define priority, keyword boundaries,
whitespace/comments, lexical state, backtracking buffers, and tokenization costs.
A hybrid byte/token parser must preserve scannerless semantics at its boundaries.
PEG choice is not maximal munch: `('a' / 'ab') 'c'` rejects `abc`, and `'a'* 'a'`
rejects `a`. Keep conservative fallback where equivalence cannot be established.

Bound DFA construction and generated size. Preserve Unicode semantics and input
bounds, including tails/page boundaries. Defer SIMD and allocator changes until
whole-parser profiles demonstrate a remaining bottleneck.

## Conditional semantic policies

Minimal diagnostics followed by detailed replay may reduce success-path work, but
changes successful `failEnd` observations. Expose it as an explicit policy with an
exact mode retained. Replay must not repeat side effects or reset limits to allow
unbounded additional work. Define total replay budgets and allocation-failure
behavior. Action-dependent parsing retains the exact path unless safe replay is
proven. Benchmark invalid inputs separately because replay can increase their cost.

Iterative expression/Pratt lowering is eligible only for declared operator tables
or a proof covering PEG priority, associativity, captures, actions, and failure
behavior. General dependency-aware seed growth remains available. This is a separate
experiment after the recursion measurements, not a universal left-recursion rewrite.

## Acceptance and implementation records

Run both `PARSER_BACKEND=combinators` and `PARSER_BACKEND=direct` with
`python3 scripts/performance_gate.py --iterations=2000 --samples=7 --runs=3 --modes
validation spans tree`, using separate report paths via `--output`. Arithmetic/CSV
and JSON/ambiguity cover output modes; numbers/PEG syntax remain validation-only.
The recursion matrix/corpus and aggregate counters already have tooling; source-matched
results, the wider configuration baseline, per-rule reports and any lexical comparator
remain separate evidence. The current gate alone does not establish those obligations.

Store raw samples, CPU/compiler flags, source hashes, backend/memo/output policies,
allocation metrics, and counter/scaling results. Treat source-mismatched reports as
history. Update the implementation record with completed evidence and outstanding
checks; partial passes cannot promote defaults or establish full acceptance.

For code changes require adjacent contract-mirroring unit tests, timeout-bound
integration tests, >90% line/branch coverage per executable `src/` module, `dfmt`,
zero Phobos, warning-free DMD/LDC/GDC builds, and clean ASan/LSan/Valgrind checks.
Include short exhaustive differential tests, malformed and recursive inputs,
actions/tracing, CTFE, selected records, and finite resource boundaries. Keep the
reference backend until supported behavior and acceptance are demonstrated.

## Mouse provenance and implementation boundaries

The per-rule rescan/backtracking distinction, bounded phrase-cache experiment,
failure/productivity diagnostics, tail-conflict explanations and recursive-ascent
alternative are informed by Mouse 2.3 by Roman R. Redziejowski (Apache 2.0).
[MOUSE_REVIEW.md](MOUSE_REVIEW.md) maps these ideas to exact vendored source files
and records their limitations. This plan incorporates design observations, not
Mouse implementation code, generated parsers or copied grammar fixtures.

For any later copied or adapted material, record the upstream files in the changed
source and project NOTICE, retain applicable notices, mark modifications and ship
[Mouse's Apache 2.0 license](../third-party/Mouse-2.3/LICENSE.txt). Preserve any
applicable upstream NOTICE. Qualify the project's current blanket Boost statement
about new code if Apache-derived material is introduced; keep that material's scope
explicit. Independently implemented ideas should still credit Mouse as a design
reference. No prototype becomes accepted or implemented merely by entering this plan.
