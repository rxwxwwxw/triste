# Performance Implementation Record

This document records the empirical implementation history, compiler verification, and benchmark measurements for NPegged performance optimizations.

---

## 1. Milestone 1: Slab Allocation Subsystem (Completed)

* **Files:** `src/npegged/storage.d`, callers in `src/npegged/peg.d`.
* **Changes:**
  - Implemented 4 KiB slab allocation cursor in `Arena`.
  - Added dedicated blocks for oversized requests without displacing the current slab.
  - Enforced exact reserved-byte accounting and sticky resource-limit failures.
* **Results:**
  - Allocation calls dropped by 95%–98% on medium-to-large inputs.
  - Memory leak clean under Valgrind Memcheck and AddressSanitizer.

---

## 2. Milestone 2: Recognition Mode & Scalar Repetition Scanners (Completed)

* **Files:** `src/npegged/peg.d`, `src/npegged/grammar.d`.
* **Changes:**
  - Introduced `RecognitionNode` (32 bytes) and `State!(CT, Check)` specialization.
  - Implemented `check!(Parser.opCall)` for synchronous borrowed input validation with zero match/child AST allocations.
  - Implemented `repeat.scan` for tight byte-loop scanning of `charClass` and ASCII `charRange`.
  - Added single-slice input borrowing for fused repetition captures.
* **Results:**
  - Whitespace-heavy JSON scanning reached 177 MB/s (105x faster than Pegged).
  - Ambiguity and JSON validation achieved **1.8x – 4.7x handwritten speed** (passing the $\le 5\times$ target).

---

## 3. Milestone 3: Grammar Graph Analysis & Selective Memoization (Completed)

* **Files:** `src/npegged/analysis.d`, `src/npegged/grammar.d`.
* **Changes:**
  - Implemented `GrammarAnalysis`: computes nullability and 256-bit FIRST byte sets (`CharSetMask`) as fixed points over expression graphs.
  - Integrated Tarjan's Strongly Connected Components (SCC) algorithm to detect left-recursive rule cycles.
  - Added `Memoization.selective`: non-left-recursive, non-conservative rules bypass memo tables.
  - Automated `predictiveChoice` jump-table generation for disjoint alternatives.
  - Regenerated bootstrap parser `src/npegged/parser.d`.
* **Results:**
  - 100% `@nogc nothrow` CTFE analysis.
  - All `src/` modules maintained $>90\%$ branch and line coverage (e.g., `analysis.d` 98.96%, `grammar.d` 92.01%).

---

## 4. Milestone 4: Compact Records Subsystem (Completed in `records.d`)

* **Files:** `src/npegged/records.d`, `src/npegged/peg.d`.
* **Changes:**
  - Implemented `CompactNode` (24 bytes: `kind`, `begin`, `end`, `parent`) and `RecordBuffer`.
  - Implemented transactional output checkpoints and rollback on speculative choices.
  - Avoided quadratic match string copying and generic tree projection.
* **Results:**
  - JSON tree and spans modes achieved **2.2x – 4.9x handwritten speed** (passing the $\le 5\times$ target).

---

## 5. Working-tree status update (2026-10-16)

The milestones above are historical implementation notes, not verification of the
current staged tree. Their timings and coverage percentages are not current acceptance.
The old remaining-work list is superseded by
[OPTIMIZATION_PLAN.md](OPTIMIZATION_PLAN.md).

Code inspection now finds adjacent prefix factoring in `grammar.d`, conservative
PEG-equivalence analysis in `analysis.d`, bounded automata in `dfa.d`, generated
compact-record selectors, and DFA workload/scanner tests. Their presence does not
establish complete compiler, sanitizer, or performance acceptance.

The stored `build/performance-acceptance.json` reports failure, including recursive
PEG validation over 5×. At review time its `peg.d` source hash differs from the
working tree. See [PERFORMANCE_REVIEW.md](PERFORMANCE_REVIEW.md) for selected ratios
and provenance. No benchmarks were rerun for this documentation update.

Corrections to the historical notes: `CompactNode` currently contains a `uint` and
three `size_t` fields, normally occupying 32 bytes on a 64-bit ABI. Compact output
already has generated integration; legacy tree conversion still has real allocation
and semantic costs. DFA and factoring work should be extended based on profiles,
not treated as entirely unimplemented milestones.

Next implementation records must include source hashes, backend/policy, output
obligation, compiler/flags, per-case repeated ratios, allocation metrics, and the
correctness checks actually run. Record direct-emission prototypes and experiments
separately from completed acceptance milestones.

## 6. Direct recognition backend experiments (2026-10-16, in progress)

The new opt-in API is `grammar!(Memoization.selective, void,
ParserBackend.direct)(definition)`. The backend is also forwarded through runtime
`generate` and `asModule`. The default remains `ParserBackend.combinators`.
`PARSER_BACKEND=direct python3 scripts/performance_gate.py --output <report>`
selects it in the equal-output benchmark matrix and records the selection in metadata.

A fresh source-matched baseline in `build/direct-baseline.json` failed four of 249
checks (worst 5.087×). The first direct-control prototype in
`build/direct-prototype.json` failed twelve checks: PEG Deep regressed from an
average 5.150 µs to 8.564 µs per parse. Adding inlining and direct predictive switches
in `build/direct-switch-prototype.json` reduced that to 5.912 µs, still slower than
the baseline. Arithmetic Small/Deep improved approximately 5%/6%, below the plan's
20% threshold for expansion. These reports represent successive source snapshots;
they are not acceptance of later edits.

The next experiment passes scalar cursor/failure results between eligible
non-memoized rules. Memoized/left-recursive entries, parameterized grammars, actions,
tracing, CTFE execution modes, and output obligations retain explicit compatible
paths. Lowering currently covers sequences, ordered choices, predictive choices,
and optional/repeated expressions; unsupported operators retain their combinators.

Differential integration tests enumerate short recursive inputs, 48 step budgets,
and depth limits, comparing status, success, end, and failure offsets. A focused
LDC unittest executable passed after each prototype. An initial complete LDC build
passed before later iterations. Full current-tree compiler, coverage, sanitizer,
and output verification remain pending. The backend has not been promoted.

The scalar-call experiment in `build/direct-scalar-prototype.json` passed 248/249
checks. Against the fresh baseline, average NPegged time improved by 23% on
Arithmetic Small, 25% on Arithmetic Deep, 34% on Arithmetic Flat, and 11% on PEG
ManyRules. PEG Deep was unchanged. One run of PEG Permissive failed at 5.157×.
This meets the expansion threshold on arithmetic, but not yet on recursive PEG.
The next iteration lowers recognition predicates with diagnostic checkpoints and
specializes tracing away on eligible internal rule calls; measurement is pending.

The predicate experiment in `build/direct-predicate-prototype.json` passed 244/249
checks, with all failures in run 1 on tiny validation cases. PEG Deep improved
approximately 5% versus the baseline and arithmetic retained larger gains. This
remains a failed gate, irrespective of the distribution across runs.

The current revision avoids routing DFA-only public rules through a scalar adapter,
bounds direct expansion by depth and a serial budget, and fixes nullable predictive
fallback handling exposed by differential tests. DMD and LDC full unit/integration
builds passed; the direct hot-path fixture passed all three compiler diagnostics.
Formatting, Phobos checks, and hook lifecycle tests passed. GDC full tests, current
performance measurements, coverage, and sanitizer verification are still pending.

Verification of this snapshot: full DMD/LDC/GDC unit/integration suites passed,
LDC ASan/LSan passed, and Valgrind Memcheck exited 0 with no invalid accesses and
zero definitely/indirectly lost bytes. Valgrind reported 32 possibly-lost bytes in
druntime GC initialization and 216 still-reachable bytes. Loader debug symbols
were supplied through `DEBUGINFOD_URLS=https://debuginfod.cachyos.org` with a
workspace-local cache. Branch coverage collection is still running.

Optimized-code inspection of the predicate prototype found surviving literal/class
calls and trace callback sites in PEG `_cursor_Primary`. The tracing policy exists
but generated scalar calls still select its default; wiring the tracing-free policy
and lowering primitive recognition are the next experiments, after this verification
snapshot finishes. This corrects the earlier description of tracing specialization
as already active.

## 7. Primitive and compact-output lowering (in progress)

The prior snapshot passed >90% line and branch coverage in every executable source
module; its source manifest and summary are retained in
`build/pre-native-coverage-sources.json` and `build/pre-native-coverage-summary.json`.
The following changes postdate that verification and require another full check.

Primitive recognition now lowers literals, byte classes, end/empty matches, and
predictive negative lookahead. Generated scalar calls select the tracing-free policy.
Differential tests include UTF-8 bytes, partial literal failures, long inputs with
small budgets, and both root and individual-rule recognition.

Arithmetic/CSV adapters now provide equal spans and concrete rule trees. Arithmetic
spans contain number/identifier intervals; trees retain Root/Term/Factor/Primary and
number/identifier nodes. CSV spans contain Field intervals including quotes and
surrounding whitespace; trees add a Root parent. Empty fields, including the field
after a trailing separator, are retained. Every invalid parse exposes no records.
Handwritten parsers emit during parsing, rather than validating and reparsing input.
The performance gate compares actual records before timing, then consumes identical
fingerprints, including construction and disposal. Numbers/PEG remain validation-only.

The expanded first gate (`build/direct-native-expanded.json`) passed 365/387 checks.
Arithmetic validation averaged 28% faster on Small and 41% faster on Flat versus the
fresh original baseline; PEG Deep was approximately 20% faster. CSV spans/trees
remained approximately 6× slower than handwritten. PEG header performance regressed
after fixing missing comment handling exposed by workload unit tests. The optimized
headers now consume the same comments as the handwritten recognizer.

The next revision merges proven closed terminal regions into scanners, while retaining
named-rule boundaries and their record/budget behavior. A first attempt to merge
across named rules failed a finite-budget record test and was restricted accordingly.
Direct control now also lowers compact-output sequences/choices/repetitions and
predicates, with checkpoints, rollback, and nested output suppression. Selected rule
boundaries retain the established capture/memoization paths. Focused LDC differential
and output-helper tests pass, including finite output limits and step budgets.
Measurement of this revision is pending in `build/direct-record-expanded.json`.

## 8. Scalar record calls and empty-match accounting (in progress)

`build/direct-scalar-record-expanded.json` passed 383/387 checks. Every spans/tree
row met 5× in all three runs; four small PEG validation checks failed. Arithmetic
Small/Flat validation averaged approximately 27%/40% faster than the original
baseline. PEG ManyRules was approximately unchanged and PEG Deep improved 14%.
Non-memoized record calls now pass scalar results, retaining selected rule capture,
parent restoration, rollback, and sticky allocation errors. Recognition values are
preserved when capture subsequently hits a resource error, matching seed/backtracking
semantics. Opaque parsers retain dynamic tracing behavior; an integration fixture
turns tracing on during a parse to verify that fallback.

Transparent recognition wrappers now lower their children while retaining existing
bulk scan members. CTFE parser calls remain on the reference backend, with explicit
compile-time tree and recognition tests. Unused concrete CTFE cursor bodies were
removed. The wrapper-only gate (`build/direct-wrapper-expanded.json`) still failed
six small PEG validation checks; all output rows remained below 5×.

The next experiment batches work for proven closed zero-width matches. A conservative
expression walk rejects reachable suffix-dependent predicates and opaque/named calls.
The existing optimized expression is evaluated at CTFE to measure work and diagnostic
behavior for an outside-FIRST byte and EOF. Separate validation/record probes preserve
their different failed-scan replay costs. Runtime guards retain the normal path near
a finite budget boundary; additions cannot wrap or exceed the limit. This experiment
keeps bounded budgets and depth enforcement.

Differential tests compare every byte value plus EOF over 40 step budgets, including
actual step counts and diagnostic-presence flags. Additional cases compare suffix
predicates, root recognition, records, and resource errors. These tests exposed a
one-unit record-mode replay difference; measuring record-mode costs separately fixed
it. Focused LDC core and direct-output suites pass. Current full compiler, sanitizer,
coverage, and final acceptance checks remain pending. The current timing report is
`build/direct-empty-expanded.json` (running).

## 9. Roadmap reconciliation after the archive review (2026-10-16)

The [new static review](NEW_PERFORMANCE_REVIEW.md) and
[revised plan](OPTIMIZATION_PLAN.md) supersede the experiment order above, without
changing the historical results or completing their pending checks. The next work
is a source-matched configuration baseline and left-recursion scaling corpus, then
independent dependency-aware invalidation and snapshot-copy experiments. Per-rule
effect analysis follows so isolated actions need not block all direct generation.
Existing scalar, record, and scanner lowering should be extended from current code.

No dependency-aware growth, new memo layout, diagnostic replay, combined lexer,
32-bit records, or default change is claimed as implemented. No benchmarks or code
verification were rerun for this documentation revision. Future records must identify
configuration/output contracts and distinguish targeted scaling evidence from full
performance acceptance.

## 10. Left-recursion scaling baseline (2026-10-16)

Added `benchmark/recursion_scaling.d`, the timeout-bound LDC release runner
`scripts/recursion-scaling.sh`, and `scripts/summarize-recursion.py`. The probe
selectively memoizes direct and indirect left-recursive grammars, samples seven
sizes (8–512 terms) seven times each, and separates valid/trailing-operator inputs
and recognition/borrowed records/owned legacy trees. All named rules are selected
for records. Timing includes construction and disposal. Metadata captures source
hashes, compiler/flags, CPU, and backend. The summary rejects incomplete samples or
unexpected corpus groups; four timeout-bound Python tests cover aggregation errors.

The combinator baseline completed all 588 samples in
`build/recursion-scaling-baseline.csv`, with metadata preserved in
`build/recursion-scaling-baseline.metadata.json`. For valid inputs at 256→512 terms:

| Grammar/mode | Median ns, 256→512 | Requested payload bytes, 256→512 |
| --- | --- | --- |
| Direct recursion / recognition | 7,324→11,932 | 592→592 |
| Indirect recursion / recognition | 60,855→231,616 | 24,224→48,800 |
| Direct recursion / records | 1,545,717→5,745,405 | 2,162,288→8,519,280 |
| Indirect recursion / records | 4,447,635→16,858,145 | 6,372,064→25,328,352 |

These local medians reproduce near-quadratic scaling in indirect recognition and
record payload growth. They do not isolate invalidation from other recursive work;
diagnostic counters and independent algorithm experiments remain required. This is
not full acceptance, a live-memory profile, or a controlled speedup comparison.
The direct-backend run is tracked separately. DMD/GDC compiled the probe without
warnings; LDC built and executed the baseline. Python summary tests, `dfmt`, shell
syntax, and whitespace checks passed. No library code changed in this step; full
library/compiler/coverage/memory acceptance remains outstanding for later changes.

The direct-backend probe also completed all 588 samples, preserved in
`build/recursion-scaling-direct.csv` and its `.metadata.json` sibling. At 512 valid
terms, direct/indirect recognition medians were 11,692/237,857 ns; record medians
were 5,822,340/17,087,938 ns. Payload totals matched the combinator baseline.
Switching the direct backend alone does not remove this recursive bookkeeping or
output scaling. Runs were sequential local probes, not the three-run acceptance gate.


## 11. Mouse review incorporated into roadmap (2026-10-17)

The [performance plan](OPTIMIZATION_PLAN.md) now incorporates the source-based
[Mouse 2.3 review](MOUSE_REVIEW.md), crediting Roman R. Redziejowski and linking
Apache 2.0 provenance. Per-rule rescan/backtracking attribution extends the existing
aggregate metrics and recursion matrix. Grammar explanations and richer terminal
proofs extend existing analysis; bounded ordinary-rule caches and restricted
recursive ascent remain independent, conditional experiments. Dependency-aware
invalidation and output-copy experiments retain priority after attribution.

The plan also acknowledges current retired-entry unlinking and the historical
scaling baseline without treating either as acceptance of this checkout. No Mouse
code was imported, no runtime behavior changed, and no benchmark/compiler/sanitizer
results are added by this documentation update. Implementation and promotion still
require the plan's differential, resource, memory and performance gates.
