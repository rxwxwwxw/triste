/** Parsing engine derived from Philippe Sigaud's Pegged. Boost Software License 1.0. */
module npegged.peg;
public import npegged.storage : Arena, Status;
import npegged.storage : growthCapacity;
public import npegged.records : CompactNode;
import npegged.records : RecordBuffer, RecordSnapshot;

/// Non-owning node. Runtime slices belong to the enclosing ParseResult.
struct ParseTree {
    string name;
    bool successful;
    string[] matches;
    string input;
    size_t begin, end;
    ParseTree[] children;
    size_t failEnd;
    ParseTree[] failedChild;
    @property auto toString() const @nogc nothrow {
        import npegged.formatting : formatTree;

        return formatTree(this);
    }

    @property auto failMsg() const @nogc nothrow {
        import npegged.formatting : failureMessage;

        return failureMessage(this);
    }

    ref inout(ParseTree) opIndex(size_t i) inout return @nogc nothrow {
        return children[i];
    }

    inout(ParseTree)[] opIndex() inout return @nogc nothrow {
        return children;
    }

    size_t opDollar() const @nogc nothrow {
        return children.length;
    }

    inout(ParseTree)[] opSlice(size_t a, size_t b) inout return @nogc nothrow {
        return children[a .. b];
    }
}

@nogc nothrow unittest {
    ParseTree[2] children;
    children[0].name = "a";
    ParseTree tree;
    tree.children = children[];
    assert(tree[0].name == "a");
    assert(tree[].length == 2);
    assert(tree[0 .. $].length == 2);
    auto text = tree.toString;
    assert(text.status == Status.ok && text.data.length);
    auto failure = tree.failMsg;
    assert(failure.status == Status.ok && failure.data.length);
}

/// Internal recognition value: no input views, names, output or diagnostic arrays.
struct RecognitionNode {
    size_t begin, end, failEnd;
    bool successful;
}

@nogc nothrow unittest {
    static assert(RecognitionNode.sizeof < ParseTree.sizeof);
    RecognitionNode node;
    assert(!node.successful && node.begin == 0 && node.end == 0 && node.failEnd == 0);
}

/// Limits are per parse; contexts can be reused or used independently by threads.
// Diagnostic builds only: timed builds contain neither counters nor branches.
version (NPeggedMetrics) {
    struct ParseMetrics {
        ulong memoCalls, memoHits, seedGrowths, invalidationVisits, invalidatedEntries;
        ulong snapshotBytes;
    }

    @nogc nothrow unittest {
        ParseMetrics metrics;
        assert(metrics.memoCalls == 0 && metrics.snapshotBytes == 0);
    }
}

struct ParseContext {
    version (NPeggedMetrics) ParseMetrics* metrics;
    size_t memoryLimit = 256 * 1024 * 1024;
    size_t stepLimit = 10_000_000;
    size_t depthLimit = 1024;
    void* userData;
    void function(string, size_t, bool, void*) @nogc nothrow trace;
}

/// Owns input and all runtime tree storage. Views expire when this owner is destroyed.
struct ParseResult {
    Arena arena;
    ParseTree tree;
    Status status = Status.invalidInput;
    alias tree this;
    @disable this(this);
    @disable this(ref ParseResult);
}

/// One invocation's storage and rule state. CTFE instantiations use compiler storage.
struct State(bool CT, int Check = 0) {
    static if (Check)
        alias Node = RecognitionNode;
    else
        alias Node = ParseTree;
    Arena* arena;
    string input;
    ParseContext context;
    Status status;
    size_t steps, depth;
    static if (Check == 2)
        private RecordBuffer* records;
    static if (Check == 2) {
        /// Non-owning backend setup; the builder and its arenas must outlive this state.
        void attachRecords(ref RecordBuffer output) @nogc nothrow {
            records = &output;
        }
    }
    private Entry* entries;
    private Entry*[] buckets;
    private size_t entryCount;
    static if (Check != 1)
        private string captureInput;
    static if (Check) {
        // Recognition only exposes the furthest offset. Saving lookahead state
        // must not copy unused begin/end/success fields on every probe.
        private struct FailureOffset {
            size_t failEnd;
        }

        private FailureOffset furthestFailure;
    } else
        private Node furthestFailure;
    private bool hasFailure;
    private alias ParserIdentity = Node function(ref State!(CT, Check), size_t) nothrow;
    private struct Entry {
        ParserIdentity identity;
        size_t position, hash;
        Node seed;
        bool active, recursive, valid;
        static if (Check == 2) {
            RecordSnapshot output;
            bool suppressed;
        }
        Entry* next;
        Entry* bucketNext;
    }

    private static size_t keyHash(string key) @nogc nothrow pure {
        size_t hash = 2166136261;
        foreach (c; key)
            hash = (hash ^ cast(ubyte)c) * 16777619;
        return hash;
    }
    /// Local builder owns its capacity until its final snapshot is returned.
    struct Builder(T) {
        State* owner;
        T[] storage;
        size_t length;
        bool put(T[] values) nothrow {
            if (values.length > size_t.max - length) {
                owner.status = Status.resourceLimit;
                return false;
            }
            size_t required = length + values.length;
            if (required > storage.length) {
                size_t capacity = growthCapacity(storage.length, required, 4);
                auto replacement = owner.allocate!T(capacity);
                if (!replacement.length)
                    return false;
                replacement[0 .. length] = storage[0 .. length];
                storage = replacement;
            }
            storage[length .. required] = values[];
            length = required;
            return true;
        }

        T[] data() nothrow {
            return storage[0 .. length];
        }
    }

    /// Isolated tree execution preserves action-visible captures and memo seeds.
    Node treeFallback(alias parser)(size_t pos) nothrow {
        State!(CT, false) outputState;
        outputState.arena = arena;
        outputState.input = input;
        static if (Check != 1)
            outputState.captureInput = captureInput;
        outputState.context = context;
        outputState.steps = steps;
        outputState.depth = depth;
        outputState.status = status;
        auto result = parser(outputState, pos);
        steps = outputState.steps;
        depth = outputState.depth;
        status = outputState.status;
        input = outputState.input;
        context = outputState.context;
        if (outputState.hasFailure) {
            auto failed = node(outputState.furthestFailure.begin, outputState.furthestFailure.end, false);
            failed.failEnd = outputState.furthestFailure.failEnd;
            recordFailure(failed);
        }
        static if (Check == 2)
            if (result.successful && status == Status.ok)
                projectRecords(result);
        auto recognized = node(result.begin, result.end, result.successful);
        recognized.failEnd = result.failEnd;
        return recognized;
    }

    private void projectRecords(ParseTree tree) nothrow {
        static if (Check == 2) {
            if (records.suppressed || !tree.successful || !tick())
                return;
            if (depth >= context.depthLimit) {
                status = Status.resourceLimit;
                return;
            }
            ++depth;
            scope (exit)
                --depth;
            // defined() retains an inner node with the same public rule boundary.
            while (tree.children.length == 1 && tree.children[0].name == tree.name
                    && tree.children[0].begin == tree.begin && tree.children[0].end == tree.end) {
                if (!tick())
                    return;
                tree = tree.children[0];
            }
            const parent = records.parent;
            auto index = records.open(tree.name, tree.begin);
            syncOutput();
            scope (exit)
                records.parent = parent;
            foreach (child; tree.children)
                projectRecords(child);
            records.finish(index, tree.end);
        }
    }

    static if (!Check) {
        /// Only root-owned, contiguous slices can replace a fused byte copy.
        private bool contiguousView(string[] matches, out string view) nothrow {
            static if (CT)
                if (__ctfe)
                    return false;
            bool started;
            size_t start, cursor;
            const base = cast(size_t)captureInput.ptr;
            foreach (match; matches) {
                if (!match.length)
                    continue;
                auto address = cast(size_t)match.ptr;
                if (address < base || address - base > captureInput.length)
                    return false;
                auto offset = address - base;
                if (match.length > captureInput.length - offset)
                    return false;
                if (!started) {
                    start = cursor = offset;
                    started = true;
                }
                if (offset != cursor)
                    return false;
                cursor += match.length;
            }
            view = started ? captureInput[start .. cursor] : null;
            return true;
        }

        private string retainCapture(string data) nothrow {
            static if (CT) {
                if (!__ctfe) {
                    if (ownsCapture(data))
                        return data;
                }
            } else if (ownsCapture(data))
                return data;
            auto bytes = allocate!char(data.length);
            if (bytes.length)
                bytes[] = data[];
            return cast(string)bytes;
        }

        private bool ownsCapture(string data) nothrow {
            auto address = cast(size_t)data.ptr;
            auto base = cast(size_t)captureInput.ptr;
            return address >= base && address - base <= captureInput.length
                && data.length <= captureInput.length - (address - base);
        }
    }

    T[] allocate(T)(size_t n) nothrow {
        static if (CT) {
            if (__ctfe)
                return new T[n];
        }
        auto data = arena.allocate!T(n);
        if (arena.status != Status.ok)
            status = arena.status;
        return data;
    }

    T[] append(T)(T[] a, T[] b) nothrow {
        if (!b.length)
            return a;
        if (a.length > size_t.max - b.length) {
            status = Status.resourceLimit;
            return null;
        }
        auto data = allocate!T(a.length + b.length);
        if (data.length) {
            data[0 .. a.length] = a[];
            data[a.length .. $] = b[];
        }
        return data;
    }

    T[] single(T)(T value) nothrow {
        static if (Check && (is(T == string) || is(T == ParseTree)))
            return null;
        auto data = allocate!T(1);
        if (data.length)
            data[0] = value;
        return data;
    }

    pragma(inline, true) bool tick() nothrow {
        if (status != Status.ok)
            return false;
        if (steps >= context.stepLimit) {
            status = Status.resourceLimit;
            return false;
        }
        ++steps;
        return true;
    }

    pragma(inline, true) Node node(size_t start, size_t end, bool success = true) nothrow {
        Node result;
        static if (!Check)
            result.input = input;
        result.begin = start;
        result.end = end;
        result.failEnd = end;
        result.successful = success && status == Status.ok;
        return result;
    }

    Node failure(size_t pos, string expected) nothrow {
        auto result = node(pos, pos, false);
        static if (!Check)
            result.matches = single(expected);
        recordFailure(result);
        return result;
    }

    pragma(inline, true) void recordFailure(Node candidate) nothrow {
        static if (!Check)
            while (candidate.failedChild.length && tick())
                candidate = candidate.failedChild[0];
        if (candidate.end > candidate.failEnd)
            candidate.failEnd = candidate.end;
        if (!hasFailure || candidate.failEnd >= furthestFailure.failEnd) {
            static if (Check)
                furthestFailure.failEnd = candidate.failEnd;
            else
                furthestFailure = candidate;
            hasFailure = true;
        }
    }

    pragma(inline, true) Node finish(Node tree) nothrow {
        if (tree.end > tree.failEnd)
            tree.failEnd = tree.end;
        if (hasFailure && furthestFailure.failEnd >= tree.failEnd && (!tree.successful
                || furthestFailure.failEnd > tree.end)) {
            tree.failEnd = furthestFailure.failEnd;
            static if (!Check)
                tree.failedChild = single(furthestFailure);
        }
        return tree;
    }

    size_t outputCheckpoint() const nothrow {
        static if (Check == 2)
            return records.length;
        else
            return 0;
    }

    void rollbackOutput(size_t checkpoint) nothrow {
        static if (Check == 2)
            records.rollback(checkpoint);
    }

    private void syncOutput() nothrow {
        static if (Check == 2)
            if (status == Status.ok && records.status != Status.ok)
                status = records.status;
    }

    private RecordSnapshot snapshotOutput(size_t checkpoint) nothrow {
        static if (Check == 2) {
            version (NPeggedMetrics)
                if (context.metrics !is null)
                    context.metrics.snapshotBytes += (records.length - checkpoint) * CompactNode
                        .sizeof;
            auto result = records.snapshot(*arena, checkpoint);
            if (arena.status != Status.ok)
                status = arena.status;
            return result;
        } else
            return RecordSnapshot.init;
    }

    private void restoreOutput(RecordSnapshot saved) nothrow {
        static if (Check == 2) {
            if (!records.suppressed)
                records.restore(saved);
            syncOutput();
        }
    }

    pragma(inline, true) private Node capturedRule(alias body, string name, bool memoize, long RecordKind)(
            size_t pos) nothrow {
        const checkpoint = records.length;
        const parent = records.parent;
        scope (exit)
            records.parent = parent;
        static if (RecordKind >= 0 && (RecordKind & (1L << 32))) {
            assert(records.selector(name) == cast(uint)RecordKind);
            static if (memoize)
                auto result = memoizedRule!(body, name)(pos);
            else
                auto result = ruleBody!(body, name)(pos);
            if (result.successful && status == Status.ok) {
                assert(records.length == checkpoint, "A compiled leaf emitted a selected descendant");
                auto index = records.openKind(cast(uint)RecordKind, pos);
                syncOutput();
                if (status == Status.ok)
                    records.finish(index, result.end);
                else
                    records.rollback(checkpoint);
            } else
                records.rollback(checkpoint);
            return result;
        } else {
            static if (RecordKind == -1)
                const index = records.open(name, pos);
            else {
                assert(records.selector(name) == (RecordKind == -2 ? uint.max : cast(uint)RecordKind),
                        "Composed compact grammars must share their selector mapping");
                static if (RecordKind == -2)
                    const index = size_t.max;
                else
                    const index = records.openKind(cast(uint)RecordKind, pos);
            }
            syncOutput();
            static if (memoize)
                auto result = memoizedRule!(body, name)(pos);
            else
                auto result = ruleBody!(body, name)(pos);
            syncOutput();
            if (result.successful && status == Status.ok)
                records.finish(index, result.end);
            else
                records.rollback(checkpoint);
            // Status controls public success; preserve a stored seed's recognition value.
            return result;
        }
    }

    pragma(inline, true) Node rule(alias body, string name, bool memoize = true, long RecordKind = -1)(
            size_t pos) nothrow if (!memoize) {
        static if (Check == 2 && RecordKind != -3)
            return capturedRule!(body, name, false, RecordKind)(pos);
        else
            return ruleBody!(body, name)(pos);
    }

    Node rule(alias body, string name, bool memoize = true, long RecordKind = -1)(size_t pos) nothrow
            if (memoize) {
        static if (Check == 2 && RecordKind != -3)
            return capturedRule!(body, name, true, RecordKind)(pos);
        else
            return memoizedRule!(body, name)(pos);
    }

    /// Inline non-memoized calls so tiny lexical rules do not pass nodes through stack frames.
    pragma(inline, true) private Node ruleBody(alias body, string name)(size_t pos) nothrow {
        if (!tick())
            return node(pos, pos, false);
        if (depth >= context.depthLimit) {
            status = Status.resourceLimit;
            return node(pos, pos, false);
        }
        ++depth;
        auto candidate = body(this, pos);
        --depth;
        static if (!Check)
            candidate.name = name;
        if (context.trace !is null)
            context.trace(name, pos, candidate.successful, context.userData);
        return candidate;
    }

    static if (Check == 1 || Check == 2) {
        /// A value checkpoint for recognition predicates; no output or ownership escapes.
        struct FailureCheckpoint {
            size_t failEnd;
            bool present;
            static if (Check == 2) {
                size_t recordLength;
                bool suppressed;
            }
        }

        FailureCheckpoint checkpointFailure() const @nogc nothrow {
            static assert(Check == 1 || Check == 2);
            return FailureCheckpoint(furthestFailure.failEnd, hasFailure);
        }

        @nogc nothrow unittest {
            static if (!CT && Check == 1) {
                State state;
                assert(!state.checkpointFailure().present);
                state.recordFailure(state.node(0, 3, false));
                auto saved = state.checkpointFailure();
                assert(saved.present && saved.failEnd == 3);
            }
        }

        /// Restore the outer diagnostic scope and return the nested predicate failure.
        FailureCheckpoint restoreFailure(FailureCheckpoint saved) @nogc nothrow {
            static assert(Check == 1 || Check == 2);
            auto nested = checkpointFailure();
            furthestFailure.failEnd = saved.failEnd;
            hasFailure = saved.present;
            return nested;
        }

        @nogc nothrow unittest {
            static if (!CT && Check == 1) {
                State state;
                auto saved = state.checkpointFailure();
                state.recordFailure(state.node(0, 4, false));
                auto nested = state.restoreFailure(saved);
                assert(nested.present && nested.failEnd == 4);
                assert(!state.checkpointFailure().present);
                assert(!state.restoreFailure(nested).present);
                assert(state.checkpointFailure().failEnd == 4);
            }
        }

        /// Suppress speculative records while retaining the outer diagnostic scope.
        pragma(inline, true) FailureCheckpoint beginProbe() @nogc nothrow {
            auto saved = checkpointFailure();
            static if (Check == 2) {
                saved.recordLength = records.length;
                saved.suppressed = records.suppressed;
                records.suppressed = true;
            }
            return saved;
        }

        @nogc nothrow unittest {
            static if (!CT && Check == 1) {
                State state;
                assert(!state.beginProbe().present);
            }
        }

        /// End a predicate, discarding its output and restoring diagnostics.
        pragma(inline, true) FailureCheckpoint finishProbe(FailureCheckpoint saved) @nogc nothrow {
            auto nested = restoreFailure(saved);
            static if (Check == 2) {
                records.rollback(saved.recordLength);
                records.suppressed = saved.suppressed;
            }
            return nested;
        }

        @nogc nothrow unittest {
            static if (!CT && Check == 1) {
                State state;
                auto saved = state.beginProbe();
                state.recordFailure(state.node(0, 4, false));
                assert(state.finishProbe(saved).failEnd == 4);
                assert(!state.checkpointFailure().present);
            } else static if (!CT && Check == 2) {
                Arena owner;
                RecordBuffer output;
                output.arena = &owner;
                State state;
                state.attachRecords(output);
                const root = output.openKind(1, 0);
                const length = output.length;
                auto saved = state.beginProbe();
                assert(output.openKind(2, 1) == size_t.max && output.length == length);
                auto inner = state.beginProbe();
                state.finishProbe(inner);
                assert(output.suppressed);
                state.recordFailure(state.node(0, 4, false));
                assert(state.finishProbe(saved).failEnd == 4);
                assert(!output.suppressed && output.length == length && output.parent == root);
            }
        }

    }

    /// Recognition rule boundary with scalar results; memoized rules keep Node seeds.
    pragma(inline, true) bool recognizeRule(alias body, string name, bool Trace = true)(ref size_t end,
            ref size_t failEnd) nothrow {
        static assert(Check == 1 || Check == 2);
        const pos = end;
        if (!tick()) {
            failEnd = pos;
            return false;
        }
        if (depth >= context.depthLimit) {
            status = Status.resourceLimit;
            failEnd = pos;
            return false;
        }
        ++depth;
        const successful = body(this, end, failEnd);
        --depth;
        static if (Trace)
            if (context.trace !is null)
                context.trace(name, pos, successful, context.userData);
        return successful;
    }

    @nogc nothrow unittest {
        static if (!CT && Check == 1) {
            static bool advance(ref State state, ref size_t end, ref size_t failure) @nogc nothrow {
                ++end;
                failure = end;
                return true;
            }

            static void trace(string name, size_t pos, bool success, void* data) @nogc nothrow {
                assert(name == "test" && pos == 0 && success);
                ++*cast(size_t*)data;
            }

            State state;
            size_t end, failure, calls;
            state.context.trace = &trace;
            state.context.userData = &calls;
            assert(state.recognizeRule!(advance, "test")(end, failure));
            assert(end == 1 && failure == 1 && state.depth == 0 && calls == 1);
            end = failure = 0;
            state.context.depthLimit = 0;
            assert(!state.recognizeRule!(advance, "test")(end, failure));
            assert(state.status == Status.resourceLimit && end == 0 && failure == 0);
            assert(!state.recognizeRule!(advance, "test")(end, failure));
            state.status = Status.ok;
            state.context.stepLimit = 0;
            assert(!state.recognizeRule!(advance, "test")(end, failure));
        }
    }

    /// Non-memoized compact rule entry with scalar recognition and transactional capture.
    pragma(inline, true) bool recognizeRecordedRule(alias body, string name, long RecordKind = -1)(
            ref size_t end, ref size_t failEnd) nothrow {
        static assert(Check == 2);
        static if (RecordKind == -3)
            return recognizeRule!(body, name, false)(end, failEnd);
        else {
            const pos = end;
            const checkpoint = records.length;
            const parent = records.parent;
            scope (exit)
                records.parent = parent;
            static if (RecordKind >= 0 && (RecordKind & (1L << 32))) {
                assert(records.selector(name) == cast(uint)RecordKind);
                const successful = recognizeRule!(body, name, false)(end, failEnd);
                if (successful && status == Status.ok) {
                    assert(records.length == checkpoint, "A compiled leaf emitted a selected descendant");
                    const index = records.openKind(cast(uint)RecordKind, pos);
                    syncOutput();
                    if (status == Status.ok)
                        records.finish(index, end);
                    else
                        records.rollback(checkpoint);
                } else
                    records.rollback(checkpoint);
                return successful;
            } else {
                static if (RecordKind == -1)
                    const index = records.open(name, pos);
                else {
                    assert(records.selector(name) == (RecordKind == -2 ? uint.max : cast(uint)RecordKind));
                    static if (RecordKind == -2)
                        const index = size_t.max;
                    else
                        const index = records.openKind(cast(uint)RecordKind, pos);
                }
                syncOutput();
                const successful = recognizeRule!(body, name, false)(end, failEnd);
                syncOutput();
                if (successful && status == Status.ok)
                    records.finish(index, end);
                else
                    records.rollback(checkpoint);
                return successful;
            }
        }
    }

    @nogc nothrow unittest {
        static if (!CT && Check == 2) {
            static bool advance(ref State state, ref size_t end, ref size_t failure) @nogc nothrow {
                ++end;
                failure = end;
                return true;
            }

            static uint select(string name) @nogc nothrow pure {
                return name == "leaf" ? 7 : uint.max;
            }

            Arena owner;
            RecordBuffer output;
            output.arena = &owner;
            output.selector = &select;
            State state;
            state.attachRecords(output);
            state.input = "abcd";
            size_t end, failure;
            assert(state.recognizeRecordedRule!(advance, "leaf", (1L << 32) | 7)(end, failure));
            assert(output.nodes.length == 1 && output.nodes[0] == CompactNode(7, 0, 1, size_t.max));
            assert(state.recognizeRecordedRule!(advance, "skip", -2)(end, failure));
            assert(state.recognizeRecordedRule!(advance, "leaf")(end, failure));
            assert(state.recognizeRecordedRule!(advance, "skip", -3)(end, failure));
            assert(output.nodes.length == 2 && output.parent == size_t.max && state.depth == 0);
            Arena exhausted;
            exhausted.limit = 0;
            RecordBuffer limited;
            limited.arena = &exhausted;
            limited.selector = &select;
            state.attachRecords(limited);
            end = failure = 0;
            assert(state.recognizeRecordedRule!(advance, "leaf", (1L << 32) | 7)(end, failure));
            assert(state.status == Status.resourceLimit && limited.nodes.length == 0);
            assert(!state.recognizeRecordedRule!(advance, "leaf", 7)(end, failure));
        }
    }

    // Retired entries stay arena-owned, but must not be revisited by later
    // seed growth or hash lookup. Active seeds remain reachable.
    private void invalidateMemo(size_t pos) nothrow {
        Entry* previous;
        auto current = entries;
        while (current !is null) {
            auto next = current.next;
            version (NPeggedMetrics)
                if (context.metrics !is null)
                    ++context.metrics.invalidationVisits;
            if (!current.active && current.position >= pos) {
                version (NPeggedMetrics)
                    if (context.metrics !is null)
                        ++context.metrics.invalidatedEntries;
                current.valid = false;
                auto link = &buckets[current.hash & (buckets.length - 1)];
                while (*link !is current)
                    link = &(*link).bucketNext;
                *link = current.bucketNext;
                --entryCount;
                if (previous is null)
                    entries = next;
                else
                    previous.next = next;
            } else
                previous = current;
            current = next;
        }
    }

    @nogc nothrow unittest {
        Arena owner;
        State!(false, 1) state;
        state.arena = &owner;
        version (NPeggedMetrics) {
            ParseMetrics metrics;
            state.context.metrics = &metrics;
        }
        auto nodes = state.allocate!(typeof(state).Entry)(5);
        assert(nodes.length == 5);
        foreach (i, ref entry; nodes) {
            entry.valid = true;
            entry.position = i;
            entry.next = i + 1 < nodes.length ? &nodes[i + 1] : null;
        }
        state.buckets = state.allocate!(typeof(state).Entry*)(1);
        state.buckets[0] = &nodes[0];
        foreach (i, ref entry; nodes)
            entry.bucketNext = i + 1 < nodes.length ? &nodes[i + 1] : null;
        nodes[2].active = true;
        state.entries = &nodes[0];
        state.entryCount = nodes.length;
        state.invalidateMemo(1);
        assert(state.entryCount == 2 && state.entries == &nodes[0]);
        assert(nodes[0].next == &nodes[2] && nodes[2].next is null);
        assert(state.buckets[0] == &nodes[0] && nodes[0].bucketNext == &nodes[2]);
        assert(nodes[2].bucketNext is null);
        assert(!nodes[1].valid && !nodes[3].valid && !nodes[4].valid);
        assert(nodes[0].valid && nodes[2].valid);
        state.invalidateMemo(0);
        assert(state.entryCount == 1 && state.entries == &nodes[2]);
        nodes[2].active = false;
        state.invalidateMemo(0);
        assert(state.entries is null && state.entryCount == 0 && state.buckets[0] is null);
        state.invalidateMemo(0);
        assert(state.entryCount == 0);
        version (NPeggedMetrics)
            assert(metrics.invalidationVisits == 8 && metrics.invalidatedEntries == 5);
    }

    /// Seed growth, with dependent memo entries invalidated whenever a seed grows.
    private Node memoizedRule(alias body, string name)(size_t pos) nothrow {
        version (NPeggedMetrics)
            if (context.metrics !is null)
                ++context.metrics.memoCalls;
        if (!tick())
            return node(pos, pos, false);
        enum baseHash = keyHash(body.mangleof);
        size_t hash = baseHash ^ (pos * cast(size_t)0x9E3779B1);
        const outputBase = outputCheckpoint();
        if (!buckets.length || entryCount > buckets.length * 3 / 4) {
            auto replacement = allocate!(Entry*)(buckets.length ? buckets.length * 2 : 64);
            if (!replacement.length)
                return node(pos, pos, false);
            entryCount = 0;
            for (auto existing = entries; existing !is null; existing = existing.next) {
                if (!existing.valid)
                    continue;
                auto slot = existing.hash & (replacement.length - 1);
                existing.bucketNext = replacement[slot];
                replacement[slot] = existing;
                ++entryCount;
            }
            buckets = replacement;
        }
        auto slot = hash & (buckets.length - 1);
        for (auto entry = buckets[slot]; entry !is null; entry = entry.bucketNext) {
            if (entry.valid && entry.identity == &body && entry.position == pos) {
                static if (Check == 2)
                    if (!entry.active && entry.suppressed != records.suppressed)
                        continue;
                static if (CT) {
                    if (__ctfe)
                        assert(!entry.active, "Left-recursive input parsing is supported only at runtime");
                }
                version (NPeggedMetrics)
                    if (context.metrics !is null)
                        ++context.metrics.memoHits;
                if (entry.active)
                    entry.recursive = true;
                else if (!entry.seed.successful)
                    recordFailure(entry.seed);
                static if (Check == 2)
                    restoreOutput(entry.output);
                return entry.seed;
            }
        }
        if (depth >= context.depthLimit) {
            status = Status.resourceLimit;
            return node(pos, pos, false);
        }
        auto storage = allocate!Entry(1);
        if (!storage.length)
            return node(pos, pos, false);
        auto entry = &storage[0];
        entry.identity = &body;
        static if (Check == 2)
            entry.suppressed = records.suppressed;
        entry.hash = hash;
        entry.valid = true;
        entry.bucketNext = buckets[slot];
        buckets[slot] = entry;
        ++entryCount;
        entry.position = pos;
        entry.seed = node(pos, pos, false);
        entry.active = true;
        entry.next = entries;
        entries = entry;
        ++depth;
        scope (exit)
            --depth;
        do {
            rollbackOutput(outputBase);
            auto candidate = body(this, pos);
            static if (!Check)
                candidate.name = name;
            if (!candidate.successful || (entry.seed.successful && candidate.end <= entry.seed.end)) {
                if (!entry.seed.successful)
                    entry.seed = candidate;
                break;
            }
            version (NPeggedMetrics)
                if (context.metrics !is null)
                    ++context.metrics.seedGrowths;
            entry.seed = candidate;
            static if (Check == 2)
                entry.output = snapshotOutput(outputBase);
            if (!entry.recursive)
                break;
            invalidateMemo(pos);
        }
        while (tick());
        rollbackOutput(outputBase);
        static if (Check == 2)
            restoreOutput(entry.output);
        entry.active = false;
        if (context.trace !is null)
            context.trace(name, pos, entry.seed.successful, context.userData);
        return entry.seed;
    }

}

@nogc nothrow unittest {
    Arena arena;
    State!false state;
    state.arena = &arena;
    state.input = "abc";
    auto data = state.single(42);
    assert(data == [42]);
    assert(state.append(data, data) == [42, 42]);
    assert(state.append(data, cast(int[])null) == [42]);
    assert(state.failure(1, "x").matches == ["x"]);
    state.context.stepLimit = 0;
    assert(!state.tick());
    assert(state.status == Status.resourceLimit);

    assert(State!false.keyHash("") == 2166136261);

    state.status = Status.ok;
    State!false.Builder!int b = {owner: &state, length: size_t.max};
    int[1] val = [1];
    assert(!b.put(val[]));
    assert(state.status == Status.resourceLimit);

    state.status = Status.ok;
    state.captureInput = "abc";
    assert(state.ownsCapture(state.captureInput[0 .. 2]));
    assert(!state.ownsCapture("foreign"));
    assert(!state.ownsCapture(state.captureInput.ptr[0 .. 100]));
    assert(state.retainCapture(state.captureInput[0 .. 1]) == "a");
    assert(state.retainCapture("foreign") == "foreign");

    string view;
    string[1] foreignArr = ["foreign"];
    assert(!state.contiguousView(foreignArr[], view));
    string[2] mixedArr = ["", state.captureInput[0 .. 1]];
    assert(state.contiguousView(mixedArr[], view));
    assert(view == "a");

    int[1] arr = [1];
    assert(state.append(arr.ptr[0 .. size_t.max], arr[]) is null);
}

ParseResult parse(alias parser)(ref ParseContext context, scope string input) @nogc nothrow {
    ParseResult result;
    result.arena.limit = context.memoryLimit;
    auto owned = result.arena.copy!char(input);
    if (result.arena.status != Status.ok) {
        result.status = result.arena.status;
        return result;
    }
    State!false state;
    state.arena = &result.arena;
    state.context = context;
    state.input = cast(string)owned;
    state.captureInput = state.input;
    result.tree = state.finish(parser(state, 0));
    result.status = state.status != Status.ok ? state.status : (result.tree.successful ? Status.ok : Status
            .mismatch);
    if (state.status != Status.ok)
        result.tree.successful = false;
    return result;
}

/// Synchronous recognition borrows input only for the duration of this call.
/// Memo storage and conservative action fallbacks remain owned by this result.
struct CheckResult {
    Arena arena;
    Status status = Status.invalidInput;
    bool successful;
    size_t end, failEnd;
    @disable this(this);
    @disable this(ref CheckResult);
}

pragma(inline, true) CheckResult check(alias parser)(ref ParseContext context, scope string input) @nogc nothrow {
    CheckResult result;
    result.arena.limit = context.memoryLimit;
    State!(false, true) state;
    state.arena = &result.arena;
    state.input = input;
    state.context = context;
    auto tree = state.finish(parser(state, 0));
    result.status = state.status != Status.ok ? state.status : (tree.successful ? Status.ok : Status
            .mismatch);
    result.successful = result.status == Status.ok;
    result.end = tree.end;
    result.failEnd = tree.failEnd;
    return result;
}

@nogc nothrow unittest {
    ParseContext context;
    auto good = check!(and!(literal!"ab", eoi))(context, "ab");
    assert(good.successful && good.end == 2 && good.arena.allocationCalls == 0);
    auto bad = check!(and!(literal!"ab", eoi))(context, "ax");
    assert(bad.status == Status.mismatch && bad.failEnd == 1 && bad.arena.used == 0);
    context.stepLimit = 0;
    auto limited = check!(literal!"a")(context, "a");
    assert(limited.status == Status.resourceLimit && !limited.successful);
}

/// Owns copied input, compact preorder output, and parser scratch independently.
struct CompactResult {
    Arena arena;
    Arena outputArena;
    string input;
    CompactNode[] nodes;
    Status status = Status.invalidInput;
    bool successful;
    size_t end, failEnd;
    @disable this(this);
    @disable this(ref CompactResult);
}

/// Selector returns uint.max to omit a rule; other values tag retained intervals.
CompactResult parseRecords(alias parser, alias selector, bool OwnInput = true)(
        ref ParseContext context, scope string input, size_t outputLimit = 256 * 1024 * 1024) @nogc nothrow {
    static if (is(parser == struct))
        alias Owner = parser;
    else
        alias Owner = __traits(parent, parser);
    static if (__traits(hasMember, Owner, "compactRuleNames")) {
        static assert(Owner.compactRuleNames.length == Owner.compactRuleKinds.length);
        static foreach (i, name; Owner.compactRuleNames)
            static assert(selector(name) == Owner.compactRuleKinds[i],
                    "The selector differs from the grammar's compiled compact projection");
    }
    CompactResult result;
    result.arena.limit = context.memoryLimit;
    result.outputArena.limit = outputLimit;
    string parsedInput;
    static if (OwnInput) {
        auto owned = result.arena.copy!char(input);
        if (result.arena.status != Status.ok) {
            result.status = result.arena.status;
            return result;
        }
        result.input = cast(string)owned;
        parsedInput = result.input;
    } else
        parsedInput = input;
    RecordBuffer records;
    records.arena = &result.outputArena;
    records.selector = &selector;
    State!(false, 2) state;
    state.arena = &result.arena;
    state.input = parsedInput;
    static if (OwnInput)
        state.captureInput = parsedInput;
    state.context = context;
    state.attachRecords(records);
    static if (__traits(compiles, parser(state, 0)))
        auto node = state.finish(parser(state, 0));
    else
        auto node = state.finish(state.treeFallback!parser(0));
    result.status = state.status != Status.ok ? state.status : node.successful ? Status.ok : Status
        .mismatch;
    result.successful = result.status == Status.ok;
    result.end = node.end;
    result.failEnd = node.failEnd;
    if (result.successful)
        result.nodes = records.nodes;
    return result;
}

version (unittest) private uint omitRecord(string name) @nogc nothrow pure {
    return uint.max;
}

@nogc nothrow unittest {
    static assert(!__traits(compiles, { CompactResult result; auto copy = result; }));
    ParseContext context;
    char[1] input = ['a'];
    auto result = parseRecords!(literal!"a", omitRecord)(context, cast(string)input[]);
    input[0] = 'x';
    assert(result.successful && result.input == "a" && result.nodes.length == 0);
    assert(result.outputArena.allocationCalls == 0);
    auto bad = parseRecords!(literal!"a", omitRecord)(context, "x");
    assert(bad.status == Status.mismatch && bad.nodes.length == 0);
    context.memoryLimit = 0;
    assert(parseRecords!(literal!"a", omitRecord)(context, "a").status == Status.resourceLimit);
    auto borrowed = parseRecords!(literal!"a", omitRecord, false)(context, "a");
    assert(borrowed.successful && borrowed.input is null && borrowed.end == 1);
    assert(borrowed.arena.allocationCalls == 0 && borrowed.outputArena.allocationCalls == 0);
    context = ParseContext.init;
    context.stepLimit = 0;
    assert(parseRecords!(literal!"a", omitRecord)(context, "a").status == Status.resourceLimit);
}

version (unittest) private ParseTree legacyRecordParser(ref State!false state, size_t pos) @nogc nothrow {
    return named!(defined!(literal!"a", "Other"), "Legacy")(state, pos);
}

version (unittest) private uint legacyKind(string name) @nogc nothrow pure {
    return name == "Legacy" ? 4 : uint.max;
}

@nogc nothrow unittest {
    ParseContext context;
    auto output = parseRecords!(legacyRecordParser, legacyKind)(context, "a");
    assert(output.successful && output.nodes.length == 1);
    assert(output.nodes[0] == CompactNode(4, 0, 1));
    auto bad = parseRecords!(legacyRecordParser, legacyKind)(context, "x");
    assert(!bad.successful && bad.status == Status.mismatch && bad.nodes.length == 0);
    auto limited = parseRecords!(legacyRecordParser, legacyKind)(context, "a", 0);
    assert(!limited.successful && limited.status == Status.resourceLimit && limited.nodes.length == 0);
}

/// CTFE entry point. Allocation is confined to compiler-managed storage.
ParseTree parseCT(alias parser)(string input) nothrow {
    assert(__ctfe, "Use parse!(parser)(context, input) at runtime");
    State!true state;
    state.input = input;
    auto tree = state.finish(parser(state, 0));
    assert(state.status == Status.ok, "Compile-time parser resource limit exceeded");
    return tree;
}

State!(CT, Check).Node eps(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
    auto result = s.node(pos, pos);
    static if (!Check)
        result.matches = s.single("");
    return result;
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!eps(context, "");
    assert(result.successful && result.matches == [""]);
}

State!(CT, Check).Node fail(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
    return s.failure(pos, "failure");
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!fail(context, "a");
    assert(result.status == Status.mismatch);
}

State!(CT, Check).Node eoi(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
    return pos == s.input.length ? s.node(pos, pos) : s.failure(pos, "end of input");
}

@nogc nothrow unittest {
    ParseContext context;
    auto empty = parse!eoi(context, "");
    assert(empty.successful);
    auto nonempty = parse!eoi(context, "x");
    assert(!nonempty.successful);
}

alias endOfInput = eoi;
State!(CT, Check).Node any(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
    if (!s.tick() || pos >= s.input.length)
        return s.failure(pos, "any char");
    auto result = s.node(pos, pos + 1);
    static if (!Check)
        result.matches = s.single(s.input[pos .. pos + 1]);
    return result;
}

@nogc nothrow unittest {
    ParseContext context;
    auto character = parse!any(context, "é");
    assert(character.end == 1);
    auto empty = parse!any(context, "");
    assert(!empty.successful);
}

/// Literal matching uses byte offsets, as in the upstream engine.
struct literal(string text) {
    enum byteScanner = text.length == 1;
    static if (byteScanner) {
        static bool byteMatches(ubyte c) @nogc nothrow pure {
            return c == cast(ubyte)text[0];
        }

        static size_t byteSteps(ubyte c) @nogc nothrow pure {
            return 1;
        }
    }
    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        if (!s.tick())
            return s.node(pos, pos, false);
        static if (text.length == 0) {
            return s.node(pos, pos);
        } else static if (text.length == 1) {
            if (pos < s.input.length && s.input[pos] == text[0]) {
                auto result = s.node(pos, pos + 1);
                static if (!Check)
                    result.matches = s.single(s.input[pos .. pos + 1]);
                return result;
            }
            auto result = s.failure(pos, text);
            result.failEnd = pos;
            s.recordFailure(result);
            return result;
        } else {
            if (pos + text.length <= s.input.length && s.input[pos .. pos + text.length] == text) {
                auto result = s.node(pos, pos + text.length);
                static if (!Check)
                    result.matches = s.single(s.input[pos .. pos + text.length]);
                return result;
            }
            size_t i;
            while (i < text.length && pos + i < s.input.length && s.input[pos + i] == text[i])
                ++i;
            auto result = s.failure(pos, text);
            result.failEnd = pos + i;
            s.recordFailure(result);
            return result;
        }
    }
}

@nogc nothrow unittest {
    ParseContext ctx;
    auto result = parse!(literal!"abc")(ctx, "abcd");
    assert(result.successful && result.end == 3);
    assert(result.matches == ["abc"]);
    auto bad = parse!(literal!"abc")(ctx, "ax");
    assert(bad.status == Status.mismatch && bad.failEnd == 1);
    auto empty = parse!(literal!"")(ctx, "");
    assert(empty.successful && empty.matches.length == 0);
    auto end = parse!eoi(ctx, "x");
    assert(!end.successful);
    auto end2 = parse!eoi(ctx, "");
    assert(end2.successful);
    auto one = parse!any(ctx, "ab");
    assert(one.end == 1);
    auto none = parse!any(ctx, "");
    assert(!none.successful);
    ctx.memoryLimit = 0;
    auto exhausted = parse!any(ctx, "x");
    assert(exhausted.status == Status.resourceLimit);
}

/// Strict UTF-8 scalar decoding for ranges and case-insensitive literals.
bool decode(scope string input, ref size_t pos, out dchar value) @nogc nothrow pure {
    if (pos >= input.length)
        return false;
    auto first = cast(ubyte)input[pos++];
    if (first < 0x80) {
        value = first;
        return true;
    }
    uint count = first >= 0xC2 && first <= 0xDF ? 1 : first >= 0xE0 && first <= 0xEF
        ? 2 : first >= 0xF0 && first <= 0xF4 ? 3 : 0;
    if (!count || count > input.length - pos)
        return false;
    uint scalar = first & ((1u << (6 - count)) - 1);
    foreach (i; 0 .. count) {
        auto next = cast(ubyte)input[pos++];
        if ((next & 0xC0) != 0x80)
            return false;
        scalar = (scalar << 6) | (next & 0x3F);
    }
    if (scalar < (count == 1 ? 0x80 : count == 2 ? 0x800 : 0x10000) || scalar > 0x10FFFF
            || (scalar >= 0xD800 && scalar <= 0xDFFF))
        return false;
    value = cast(dchar)scalar;
    return true;
}

@nogc nothrow unittest {
    foreach (text; ["a", "é", "€", "😀"]) {
        size_t pos;
        dchar value;
        assert(decode(text, pos, value) && pos == text.length);
    }
    foreach (text; [
        "", "\x80", "\xc0\xaf", "\xe0\x80\x80", "\xed\xa0\x80", "\xf4\x90\x80\x80", "\xc2x", "\xe2"
    ]) {
        size_t pos;
        dchar value;
        assert(!decode(text, pos, value));
    }
}

struct charRange(dchar low, dchar high) {
    static size_t byteSteps(ubyte c) @nogc nothrow pure {
        return 1;
    }

    enum byteScanner = high < 128;
    enum expectation = "character range";
    static bool byteMatches(ubyte c) @nogc nothrow pure {
        return c >= low && c <= high;
    }

    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (high < 128) {
            if (!s.tick() || pos >= s.input.length)
                return s.failure(pos, "character range");
            const char c = s.input[pos];
            if (c < low || c > high)
                return s.failure(pos, "character range");
            auto result = s.node(pos, pos + 1);
            static if (!Check)
                result.matches = s.single(s.input[pos .. pos + 1]);
            return result;
        } else {
            size_t end = pos;
            dchar value;
            if (!s.tick() || !decode(s.input, end, value) || value < low || value > high)
                return s.failure(pos, "character range");
            auto result = s.node(pos, end);
            static if (!Check)
                result.matches = s.single(s.input[pos .. end]);
            return result;
        }
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(charRange!('α', 'ω'))(context, "β");
    assert(result.successful && result.end == 2);
    auto bad = parse!(charRange!('a', 'z'))(context, "1");
    assert(!bad.successful);
}

struct CharSetMask {
    ulong[4] bits;

    void addChar(dchar c) @nogc nothrow pure @safe {
        if (c < 256) {
            bits[(cast(uint)c) >> 6] |= (1UL << ((cast(uint)c) & 63));
        }
    }

    void addRange(dchar low, dchar high) @nogc nothrow pure @safe {
        if (low <= high && high < 256) {
            for (uint c = cast(uint)low; c <= cast(uint)high; ++c) {
                bits[c >> 6] |= (1UL << (c & 63));
            }
        }
    }

    static CharSetMask fromRanges(const(char[2])[] ranges...) @nogc nothrow pure @safe {
        CharSetMask mask;
        foreach (range; ranges) {
            mask.addRange(range[0], range[1]);
        }
        return mask;
    }

    static CharSetMask fromChars(const(char)[] chars...) @nogc nothrow pure @safe {
        CharSetMask mask;
        foreach (c; chars) {
            mask.addChar(c);
        }
        return mask;
    }

    bool contains(char c) const @nogc nothrow pure @safe {
        return (bits[(cast(ubyte)c) >> 6] & (1UL << ((cast(ubyte)c) & 63))) != 0;
    }

    bool empty() const @nogc nothrow pure @safe {
        return (bits[0] | bits[1] | bits[2] | bits[3]) == 0;
    }

    bool intersects(CharSetMask other) const @nogc nothrow pure @safe {
        return ((bits[0] & other.bits[0]) | (bits[1] & other.bits[1]) | (bits[2] & other.bits[2]) | (
                bits[3] & other.bits[3])) != 0;
    }

    CharSetMask opBinary(string op : "|")(CharSetMask other) const @nogc nothrow pure @safe {
        CharSetMask res;
        res.bits[0] = bits[0] | other.bits[0];
        res.bits[1] = bits[1] | other.bits[1];
        res.bits[2] = bits[2] | other.bits[2];
        res.bits[3] = bits[3] | other.bits[3];
        return res;
    }

    CharSetMask opBinary(string op : "&")(CharSetMask other) const @nogc nothrow pure @safe {
        CharSetMask res;
        res.bits[0] = bits[0] & other.bits[0];
        res.bits[1] = bits[1] & other.bits[1];
        res.bits[2] = bits[2] & other.bits[2];
        res.bits[3] = bits[3] & other.bits[3];
        return res;
    }

    CharSetMask opUnary(string op : "~")() const @nogc nothrow pure @safe {
        CharSetMask res;
        res.bits[0] = ~bits[0];
        res.bits[1] = ~bits[1];
        res.bits[2] = ~bits[2];
        res.bits[3] = ~bits[3];
        return res;
    }
}

@nogc nothrow unittest {
    CharSetMask mask;
    assert(mask.empty());
    mask.addChar('a');
    mask.addRange('0', '9');
    assert(mask.contains('a'));
    assert(mask.contains('0'));
    assert(mask.contains('9'));
    assert(!mask.contains('b'));
    assert(!mask.empty());

    CharSetMask other = CharSetMask.fromRanges(['b', 'd']);
    assert(!mask.intersects(other));
    auto combined = mask | other;
    assert(combined.contains('c'));
    assert(mask.intersects(combined));
    auto intersected = mask & combined;
    assert(intersected.contains('a'));
    assert(!intersected.contains('b'));
    auto inverted = ~mask;
    assert(!inverted.contains('a'));
    assert(inverted.contains('b'));
}

struct charClass(ulong b0, ulong b1, ulong b2, ulong b3) {
    static size_t byteSteps(ubyte c) @nogc nothrow pure {
        return 1;
    }

    enum byteScanner = true;
    enum expectation = "character class";
    static bool byteMatches(ubyte c) @nogc nothrow pure {
        enum ulong[4] bits = [b0, b1, b2, b3];
        return (bits[c >> 6] & (1UL << (c & 63))) != 0;
    }

    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        if (!s.tick() || pos >= s.input.length)
            return s.failure(pos, "character class");
        const ubyte c = cast(ubyte)s.input[pos];
        enum ulong[4] bits = [b0, b1, b2, b3];
        if ((bits[c >> 6] & (1UL << (c & 63))) == 0)
            return s.failure(pos, "character class");
        auto result = s.node(pos, pos + 1);
        static if (!Check)
            result.matches = s.single(s.input[pos .. pos + 1]);
        return result;
    }
}

template charClass(CharSetMask mask) {
    alias charClass = charClass!(mask.bits[0], mask.bits[1], mask.bits[2], mask.bits[3]);
}

@nogc nothrow unittest {
    ParseContext context;
    enum mask = CharSetMask.fromRanges(['0', '9'], ['a', 'f']);
    auto valid = parse!(charClass!mask)(context, "a");
    assert(valid.successful && valid.end == 1 && valid.matches == ["a"]);
    auto digit = parse!(charClass!mask)(context, "5");
    assert(digit.successful && digit.end == 1);
    auto bad = parse!(charClass!mask)(context, "z");
    assert(!bad.successful && bad.status == Status.mismatch);
    auto empty = parse!(charClass!mask)(context, "");
    assert(!empty.successful);
}

struct and(rules...) {
    static if (rules.length == 2 && __traits(hasMember, rules[0], "bytePredicate")
            && rules[0].bytePredicate && __traits(isSame, rules[1], npegged.peg.any)) {
        enum byteScanner = true;
        static bool byteMatches(ubyte c) @nogc nothrow pure {
            return rules[0].predicateMatches(c);
        }

        static size_t byteSteps(ubyte c) @nogc nothrow pure {
            // Sequence ticks before each child, plus any's terminal tick.
            return 3 + rules[0].predicateSteps(c);
        }
    } else
        enum byteScanner = false;
    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (Check == 1) {
            pragma(inline, true);
        }
        auto result = s.node(pos, pos);
        static if (!Check) {
            State!(CT, Check).Builder!string matches = {owner: &s};
            State!(CT, Check).Builder!ParseTree children = {owner: &s};
        }
        static foreach (r; rules) {
            {
                if (!s.tick())
                    return s.node(pos, pos, false);
                auto next = r(s, result.end);
                if (!next.successful) {
                    result.successful = false;
                    result.failEnd = next.failEnd;
                    static if (!Check)
                        result.matches = next.matches;
                    static if (!Check)
                        result.failedChild = s.single(next);
                    return result;
                }
                result.end = next.end;
                static if (!Check) {
                    matches.put(next.matches);
                    children.put(next.children);
                }
                static if (!Check)
                    result.matches = matches.data();
                static if (!Check)
                    result.children = children.data();
            }
        }
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(and!(literal!"a", literal!"b"))(context, "ab");
    assert(result.end == 2 && result.matches == ["a", "b"]);
    auto bad = parse!(and!(literal!"a", literal!"b"))(context, "ac");
    assert(bad.failEnd == 1 && bad.status == Status.mismatch);
}

struct choice(bool longest, rules...) {
    private static bool canScan() {
        static foreach (rule; rules) {
            static if (!__traits(hasMember, rule, "byteScanner") || !__traits(hasMember, rule,
                    "byteMatches") || !__traits(hasMember, rule, "byteSteps"))
                return false;
            else static if (!rule.byteScanner)
                return false;
        }
        return rules.length > 0;
    }

    enum byteScanner = canScan();
    static if (byteScanner) {
        private static CharSetMask computeByteMask() {
            CharSetMask m;
            foreach (c; 0 .. 256) {
                bool match = false;
                static foreach (rule; rules)
                    if (rule.byteMatches(cast(ubyte)c))
                        match = true;
                if (match)
                    m.addChar(cast(char)c);
            }
            return m;
        }

        enum byteMask = computeByteMask();

        static bool byteMatches(ubyte c) @nogc nothrow pure {
            return (byteMask.bits[c >> 6] & (1UL << (c & 63))) != 0;
        }

        static size_t byteSteps(ubyte c) @nogc nothrow pure {
            size_t steps;
            static foreach (rule; rules) {
                steps += rule.byteSteps(c);
                static if (!longest)
                    if (rule.byteMatches(c))
                        return steps;
            }
            return steps;
        }
    }
    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (Check == 1) {
            pragma(inline, true);
        }
        auto result = s.node(pos, pos, false);
        const checkpoint = s.outputCheckpoint();
        static if (Check == 2 && longest)
            RecordSnapshot selected;
        static foreach (r; rules) {
            {
                s.rollbackOutput(checkpoint);
                auto candidate = r(s, pos);
                if (candidate.successful) {
                    if (!longest)
                        return candidate;
                    if (!result.successful || candidate.end > result.end) {
                        result = candidate;
                        static if (Check == 2 && longest)
                            selected = s.snapshotOutput(checkpoint);
                    }
                } else if (!result.successful && candidate.failEnd >= result.failEnd)
                    result = candidate;
            }
        }
        s.rollbackOutput(checkpoint);
        static if (Check == 2 && longest)
            if (result.successful)
                s.restoreOutput(selected);
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(choice!(true, named!(literal!"a", "first"), named!(literal!"a", "second")))(
            context, "a");
    assert(result.name == "first");
    alias nullable = choice!(false, literal!"a", option!(literal!"b"));
    static assert(!nullable.byteScanner);
    assert(check!nullable(context, "").successful);
    assert(check!nullable(context, "b").end == 1);
}

template or(rules...) {
    alias or = choice!(false, rules);
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(or!(literal!"x", literal!"a"))(context, "a");
    assert(result.successful);
}

template branch(alias Rule, ulong b0, ulong b1, ulong b2, ulong b3, bool Nullable = false) {
    alias rule = Rule;
    enum CharSetMask mask = CharSetMask([b0, b1, b2, b3]);
    enum nullable = Nullable;
}

template branch(alias Rule, CharSetMask mask, bool Nullable = false) {
    alias branch = branch!(Rule, mask.bits[0], mask.bits[1], mask.bits[2], mask.bits[3], Nullable);
}

struct predictiveChoice(branches...) {
    static assert(branches.length <= ubyte.max, "Predictive choices use byte branch indices");
    private static size_t computeFallback() {
        size_t result;
        static foreach (i, branch; branches)
            static if (branch.nullable) {
                static assert(i + 1 == branches.length, "Only the last alternative may be nullable");
                result = i + 1;
            }
        return result;
    }

    enum fallback = computeFallback();
    private static bool canScan() {
        static foreach (branch; branches) {
            static if (!__traits(hasMember, branch.rule, "byteScanner") || !__traits(hasMember,
                    branch.rule, "byteMatches") || !__traits(hasMember, branch.rule, "byteSteps"))
                return false;
            else static if (!branch.rule.byteScanner)
                return false;
            else static if (branch.nullable)
                return false;
        }
        return branches.length > 0;
    }

    enum byteScanner = canScan();
    static if (byteScanner) {
        static bool byteMatches(ubyte c) @nogc nothrow pure {
            const target = branchTable[c];
            static foreach (i, branch; branches)
                if (target == i + 1)
                    return branch.rule.byteMatches(c);
            return false;
        }

        static size_t byteSteps(ubyte c) @nogc nothrow pure {
            const target = branchTable[c];
            static foreach (i, branch; branches)
                if (target == i + 1)
                    return 1 + branch.rule.byteSteps(c);
            return 1;
        }
    }

    private static ubyte[256] computeTable() {
        ubyte[256] table = cast(ubyte)fallback;
        foreach (i, b; branches) {
            foreach (c; 0 .. 256) {
                if (b.mask.contains(cast(char)c)) {
                    table[c] = cast(ubyte)(i + 1);
                }
            }
        }
        return table;
    }

    static immutable ubyte[256] branchTable = computeTable();

    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (Check == 1) {
            pragma(inline, true);
        }
        if (!s.tick())
            return s.node(pos, pos, false);
        if (pos >= s.input.length) {
            static if (fallback)
                return branches[fallback - 1].rule(s, pos);
            else {
                auto result = s.failure(pos, "choice");
                result.failEnd = pos;
                s.recordFailure(result);
                return result;
            }
        }
        const ubyte b = cast(ubyte)s.input[pos];
        const ubyte target = branchTable[b];
        switch (target) {
            static foreach (i; 0 .. branches.length) {
        case i + 1:
                static if (fallback && i + 1 != fallback) {
                    const checkpoint = s.outputCheckpoint();
                    auto result = branches[i].rule(s, pos);
                    if (result.successful || s.status != Status.ok)
                        return result;
                    s.rollbackOutput(checkpoint);
                    return branches[fallback - 1].rule(s, pos);
                } else
                    return branches[i].rule(s, pos);
            }
        default:
            auto result = s.failure(pos, "choice");
            result.failEnd = pos;
            s.recordFailure(result);
            return result;
        }
    }
}

@nogc nothrow unittest {
    ParseContext context;
    enum maskA = CharSetMask.fromChars('a');
    enum maskB = CharSetMask.fromChars('b');
    alias pred = predictiveChoice!(branch!(literal!"a", maskA), branch!(literal!"b", maskB));
    auto resA = parse!pred(context, "a");
    assert(resA.successful && resA.end == 1);
    auto resB = parse!pred(context, "b");
    assert(resB.successful && resB.end == 1);
    auto resC = parse!pred(context, "c");
    assert(!resC.successful);
    auto resEmpty = parse!pred(context, "");
    assert(!resEmpty.successful);
    alias nullable = predictiveChoice!(branch!(literal!"ab", maskA),
            branch!(zeroOrMore!(literal!"b"), maskB, true));
    static assert(!nullable.byteScanner);
    assert(check!nullable(context, "").successful);
    assert(check!nullable(context, "bbx").end == 2);
    auto rolledBack = check!nullable(context, "aX");
    assert(rolledBack.successful && rolledBack.end == 0 && rolledBack.failEnd == 1);
    assert(check!nullable(context, "x").end == 0);
    assert(check!nullable(context, "ab").end == 2);
    context.stepLimit = 1;
    assert(check!nullable(context, "ab").status == Status.resourceLimit);
}

template longest_match(rules...) {
    alias longest_match = choice!(true, rules);
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(longest_match!(literal!"a", literal!"ab"))(context, "ab");
    assert(result.end == 2);
}

struct repeat(alias r, size_t minimum, size_t maximum = size_t.max) {
    enum byteScanner = __traits(hasMember, r, "byteScanner") && r.byteScanner && __traits(hasMember,
                r, "byteMatches") && __traits(hasMember, r, "byteSteps");
    static if (byteScanner) {
        /// Preserve generic repetition's loop/terminal ticks and stopping mismatch.
        static State!(CT, Check).Node scan(bool Capture, bool CT, int Check = 0)(ref State!(CT, Check) s,
                size_t pos) nothrow {
            auto result = s.node(pos, pos);
            size_t count;
            const size_t remainingBytes = s.input.length - result.end;
            const size_t maxSteps = (1 + r.byteSteps(0)) * (remainingBytes + 1);
            if (s.status == Status.ok && s.context.stepLimit > s.steps && s.context.stepLimit - s
                    .steps >= maxSteps) {
                while (count < maximum && result.end < s.input.length) {
                    const c = cast(ubyte)s.input[result.end];
                    if (!r.byteMatches(c))
                        break;
                    s.steps += 1 + r.byteSteps(c);
                    ++result.end;
                    ++count;
                }
            }
            while (count < maximum && s.tick()) {
                if (result.end < s.input.length) {
                    const c = cast(ubyte)s.input[result.end];
                    const cost = r.byteSteps(c);
                    if (r.byteMatches(c) && cost <= s.context.stepLimit - s.steps) {
                        s.steps += cost;
                        ++result.end;
                        ++count;
                        continue;
                    }
                }
                // Preserve exact diagnostics and partial budget behavior at the boundary.
                const checkpoint = s.outputCheckpoint();
                auto next = r(s, result.end);
                if (!next.successful) {
                    s.rollbackOutput(checkpoint);
                    if (count < minimum)
                        return next;
                    break;
                }
                result.end = next.end;
                ++count;
            }
            if (count < minimum || s.status != Status.ok)
                result.successful = false;
            static if (!Check) {
                if (!result.successful) {
                    // Failed transforms retain the unfused child output.
                    static if (!Check)
                        result.matches = s.allocate!string(count);
                    foreach (i; 0 .. result.matches.length)
                        result.matches[i] = s.input[pos + i .. pos + i + 1];
                } else static if (Capture) {
                    if (result.end != pos)
                        static if (!Check)
                            result.matches = s.single(s.retainCapture(s.input[pos .. result.end]));
                }
            }
            return result;
        }
    }
    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (Check == 1) {
            pragma(inline, true);
        }
        static if (Check && byteScanner)
            return scan!false(s, pos);
        else {
            auto result = s.node(pos, pos);
            static if (!Check) {
                State!(CT, Check).Builder!string matches = {owner: &s};
                State!(CT, Check).Builder!ParseTree children = {owner: &s};
            }
            size_t count;
            while (count < maximum && s.tick()) {
                const checkpoint = s.outputCheckpoint();
                auto next = r(s, result.end);
                if (!next.successful) {
                    s.rollbackOutput(checkpoint);
                    if (count < minimum)
                        return next;
                    break;
                }
                static if (!Check) {
                    matches.put(next.matches);
                    children.put(next.children);
                }
                static if (!Check)
                    result.matches = matches.data();
                static if (!Check)
                    result.children = children.data();
                ++count;
                if (next.end == result.end)
                    break;
                result.end = next.end;
            }
            if (count < minimum || s.status != Status.ok)
                result.successful = false;
            return result;
        }
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(repeat!(digit, 2, 3))(context, "1234");
    assert(result.end == 3);
    auto bad = parse!(repeat!(digit, 2, 3))(context, "1");
    assert(!bad.successful);
}

version (unittest) private State!(CT, Check).Node wrappedDigit(bool CT, int Check = 0)(ref State!(CT,
        Check) state, size_t pos) nothrow {
    return digit(state, pos);
}

@nogc nothrow unittest {
    foreach (input; ["", "x", "1", "12", "1234", "12x"]) {
        foreach (budget; 0 .. 14) {
            ParseContext context;
            context.stepLimit = budget;
            auto specialized = parse!(fuse!(repeat!(digit, 2, 3)))(context, input);
            auto generic = parse!(fuse!(repeat!(wrappedDigit, 2, 3)))(context, input);
            assert(specialized.status == generic.status);
            assert(specialized.successful == generic.successful);
            assert(specialized.end == generic.end && specialized.failEnd == generic.failEnd);
            assert(specialized.matches == generic.matches);
            auto checked = check!(repeat!(digit, 2, 3))(context, input);
            assert(checked.status == generic.status && checked.end == generic.end);
            assert(checked.failEnd == generic.failEnd && checked.arena.allocationCalls == 0);
        }
    }
    ParseContext context;
    auto discarded = parse!(discard!(zeroOrMore!digit))(context, "123x");
    assert(discarded.end == 3 && discarded.matches.length == 0);
    auto unicode = parse!(fuse!(oneOrMore!(charRange!('α', 'ω'))))(context, "αβx");
    assert(unicode.matches == ["αβ"] && unicode.end == 4);
    enum mask = CharSetMask.fromRanges(['0', '9']);
    auto bytes = check!(oneOrMore!(charClass!mask))(context, "12x");
    assert(bytes.successful && bytes.end == 2 && bytes.arena.used == 0);
}

version (unittest) private State!(CT, Check).Node wrappedRun(bool CT, int Check = 0)(ref State!(CT,
        Check) state, size_t pos) nothrow {
    return and!(negLookahead!(or!(doublequote, backslash, charRange!(0, 31))), any)(state, pos);
}

@nogc nothrow unittest {
    alias run = and!(negLookahead!(or!(doublequote, backslash, charRange!(0, 31))), any);
    static assert(run.byteScanner);
    foreach (input; ["", "abc", "a\"", "a\\", "a\x01", "\xffa", "αβ"]) {
        foreach (budget; 0 .. 65) {
            ParseContext context;
            context.stepLimit = budget;
            auto scanned = parse!(fuse!(repeat!(run, 1, 3)))(context, input);
            auto generic = parse!(fuse!(repeat!(wrappedRun, 1, 3)))(context, input);
            assert(scanned.status == generic.status && scanned.successful == generic.successful);
            assert(scanned.end == generic.end && scanned.failEnd == generic.failEnd);
            assert(scanned.matches == generic.matches);
            auto checked = check!(repeat!(run, 1, 3))(context, input);
            auto reference = check!(repeat!(wrappedRun, 1, 3))(context, input);
            assert(checked.status == reference.status && checked.end == reference.end);
            assert(checked.failEnd == reference.failEnd && checked.arena.used == 0);
        }
    }
    alias positive = and!(posLookahead!(or!(literal!"a", literal!"b")), any);
    alias longest = and!(negLookahead!(longest_match!(literal!"a", literal!"b")), any);
    ParseContext context;
    auto yes = check!(oneOrMore!positive)(context, "abba!");
    assert(yes.successful && yes.end == 4);
    auto no = check!(oneOrMore!longest)(context, "cda");
    assert(no.successful && no.end == 2);
}

version (unittest) template unscanned(alias Rule) {
    State!(CT, Check).Node unscanned(bool CT, int Check = 0)(ref State!(CT, Check) state, size_t pos) nothrow {
        return Rule(state, pos);
    }
}

@nogc nothrow unittest {
    enum a = CharSetMask.fromRanges(['a', 'a']);
    enum b = CharSetMask.fromRanges(['b', 'b']);
    alias delimiters = predictiveChoice!(branch!(literal!"a", a), branch!(literal!"b", b));
    assert(delimiters.byteMatches('a') && delimiters.byteMatches('b'));
    assert(!delimiters.byteMatches('c'));
    assert(delimiters.byteSteps('a') == 2 && delimiters.byteSteps('b') == 2);
    assert(delimiters.byteSteps('c') == 1);
    alias run = and!(negLookahead!delimiters, any);
    static assert(run.byteScanner);
    foreach (input; ["", "a", "b", "c", "cca", "\xffc"]) {
        foreach (budget; 0 .. 25) {
            ParseContext context;
            context.stepLimit = budget;
            auto scanned = parse!(fuse!(repeat!(run, 1, 3)))(context, input);
            auto generic = parse!(fuse!(repeat!(unscanned!run, 1, 3)))(context, input);
            assert(scanned.status == generic.status && scanned.successful == generic.successful);
            assert(scanned.end == generic.end && scanned.failEnd == generic.failEnd);
            assert(scanned.matches == generic.matches);
        }
    }
}

template zeroOrMore(alias r) {
    alias zeroOrMore = repeat!(r, 0);
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(zeroOrMore!digit)(context, "x");
    assert(result.successful && result.end == 0);
}

template oneOrMore(alias r) {
    alias oneOrMore = repeat!(r, 1);
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(oneOrMore!digit)(context, "12x");
    assert(result.end == 2);
}

template option(alias r) {
    alias option = repeat!(r, 0, 1);
}

@nogc nothrow unittest {
    ParseContext context;
    auto absent = parse!(option!digit)(context, "x");
    assert(absent.successful);
    auto present = parse!(option!digit)(context, "1");
    assert(present.end == 1);
}

struct lookahead(alias r, bool positive) {
    enum bytePredicate = __traits(hasMember, r, "byteScanner") && r.byteScanner;
    static if (bytePredicate) {
        static bool predicateMatches(ubyte c) @nogc nothrow pure {
            return r.byteMatches(c) == positive;
        }

        static size_t predicateSteps(ubyte c) @nogc nothrow pure {
            return r.byteSteps(c);
        }
    }
    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (Check == 1) {
            pragma(inline, true);
        }
        static if (Check == 2) {
            const checkpoint = s.records.length;
            const suppressed = s.records.suppressed;
            s.records.suppressed = true;
            scope (exit) {
                s.records.rollback(checkpoint);
                s.records.suppressed = suppressed;
            }
        }
        auto saved = s.furthestFailure;
        bool hadFailure = s.hasFailure;
        auto next = r(s, pos);
        auto nestedFailure = s.furthestFailure;
        bool nestedHadFailure = s.hasFailure;
        s.furthestFailure = saved;
        s.hasFailure = hadFailure;
        auto result = s.node(pos, pos, next.successful == positive);
        if (!result.successful) {
            static if (positive) {
                static if (!Check)
                    result.matches = next.matches;
                result.failEnd = next.failEnd;
                if (nestedHadFailure) {
                    static if (Check) {
                        auto failure = s.node(pos, pos, false);
                        failure.failEnd = nestedFailure.failEnd;
                        s.recordFailure(failure);
                    } else
                        s.recordFailure(nestedFailure);
                } else
                    s.recordFailure(result);
            } else
                result = s.failure(pos, "negative lookahead");
        }
        return result;
    }
}

@nogc nothrow unittest {
    State!(false, 1) limited;
    limited.input = "a";
    limited.steps = 2;
    limited.context.stepLimit = 1;
    assert(!lookahead!(literal!"a", true)(limited, 0).successful);
    assert(limited.status == Status.resourceLimit && limited.steps == 2);

    import npegged.meta : AliasSeq;

    alias bytes = or!(literal!"a", charRange!('0', '9'));
    alias predicted = predictiveChoice!(branch!(literal!"a", CharSetMask.fromChars('a')),
            branch!(literal!"b", CharSetMask.fromChars('b')));
    static foreach (child; AliasSeq!(and!(literal!"ab", literal!"c"), or!(literal!"abcd", literal!"ax"))) {
        static foreach (positive; [false, true]) {
            foreach (input; ["abx", "ab", "ax", "abc", "abcd"]) {
                ParseContext context;
                auto recognized = check!(lookahead!(child, positive))(context, input);
                auto legacy = parse!(lookahead!(child, positive))(context, input);
                assert(recognized.status == legacy.status);
                assert(recognized.end == legacy.end && recognized.failEnd == legacy.failEnd);
            }
        }
    }
    static foreach (child; AliasSeq!(bytes, predicted, literal!"a", charClass!(CharSetMask.fromChars(
            'x')))) {
        static foreach (positive; [false, true]) {
            foreach (input; ["", "a", "b", "1", "x", "!", "\xff"]) {
                foreach (budget; 0 .. 12) {
                    ParseContext context;
                    context.stepLimit = budget;
                    auto fast = check!(lookahead!(child, positive))(context, input);
                    auto generic = check!(lookahead!(unscanned!child, positive))(context, input);
                    assert(fast.status == generic.status && fast.successful == generic.successful);
                    assert(fast.end == generic.end && fast.failEnd == generic.failEnd);
                }
            }
        }
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(lookahead!(digit, false))(context, "1");
    assert(!result.successful && result.end == 0);
}

template posLookahead(alias r) {
    alias posLookahead = lookahead!(r, true);
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(posLookahead!digit)(context, "x");
    assert(!result.successful);
}

/// A pure negative probe cannot match a nonempty input outside its FIRST set.
struct predictiveNot(alias r, ulong b0, ulong b1, ulong b2, ulong b3) {
    enum mask = CharSetMask([b0, b1, b2, b3]);
    enum bytePredicate = __traits(hasMember, r, "byteScanner") && r.byteScanner;
    static if (bytePredicate) {
        static bool predicateMatches(ubyte c) @nogc nothrow pure {
            return !mask.contains(c);
        }

        static size_t predicateSteps(ubyte c) @nogc nothrow pure {
            return r.byteSteps(c);
        }
    }
    static State!(CT, Check).Node opCall(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (Check == 1) {
            pragma(inline, true);
        }
        if (s.context.trace is null && pos < s.input.length && !mask.contains(cast(ubyte)s.input[pos])) {
            if (!s.tick())
                return s.node(pos, pos, false);
            return s.node(pos, pos);
        }
        return negLookahead!r(s, pos);
    }
}

@nogc nothrow unittest {
    enum mask = CharSetMask.fromChars('a');
    alias probe = predictiveNot!(literal!"ab", mask.bits[0], mask.bits[1], mask.bits[2], mask.bits[3]);
    ParseContext context;
    foreach (input; ["", "x", "a", "ab", "ax"]) {
        auto expected = check!(negLookahead!(literal!"ab"))(context, input);
        auto result = check!probe(context, input);
        assert(result.successful == expected.successful && result.end == expected.end);
        assert(result.failEnd == expected.failEnd);
    }
    context.stepLimit = 0;
    assert(check!probe(context, "x").status == Status.resourceLimit);
}

template negLookahead(alias r) {
    alias negLookahead = lookahead!(r, false);
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(negLookahead!digit)(context, "1");
    assert(!result.successful);
}

/// Tree transforms keep grammar nodes only; primitive combinators are flattened.
template transform(alias r, char operation) {
    State!(CT, Check).Node transform(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if ((operation == '~' || operation == ':') && __traits(hasMember, r, "scan")) {
            return r.scan!(operation == '~')(s, pos);
        } else static if (Check) {
            return r(s, pos);
        } else {
            auto result = r(s, pos);
            if (!result.successful)
                return result;
            static if (operation == '~') {
                string joined;
                if (!s.contiguousView(result.matches, joined)) {
                    size_t length;
                    foreach (match; result.matches) {
                        if (match.length > size_t.max - length) {
                            s.status = Status.resourceLimit;
                            result.successful = false;
                            return result;
                        }
                        length += match.length;
                    }
                    auto bytes = s.allocate!char(length);
                    size_t offset;
                    if (bytes.length == length)
                        foreach (match; result.matches) {
                            bytes[offset .. offset + match.length] = match[];
                            offset += match.length;
                        }
                    joined = cast(string)bytes;
                }
                if (result.matches.length)
                    result.matches = s.single(joined);
                result.children = null;
            } else static if (operation == ':') {
                result.matches = null;
                result.children = null;
            } else static if (operation == ';')
                result.children = null;
            else static if (operation == '%') {
                ParseTree[] children;
                foreach (child; result.children)
                    children = s.append(children, child.children);
                result.children = children;
            } else static if (operation == '^') {
                if (!result.children.length)
                    result.children = s.single(result);
            }
            return result;
        }
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(transform!(oneOrMore!digit, '~'))(context, "123");
    assert(result.matches == ["123"]);
}

@nogc nothrow unittest {
    ParseContext context;
    auto contiguous = parse!(transform!(and!(literal!"a", literal!"b"), '~'))(context, "ab");
    assert(contiguous.matches == ["ab"] && contiguous.matches[0].ptr == contiguous.input.ptr);
    auto spaced = parse!(transform!(wrapAround!(spacing, literal!"a", spacing), '~'))(context, " a ");
    assert(spaced.matches == ["a"] && spaced.matches[0].ptr == spaced.input.ptr + 1);
    auto changed = parse!(transform!(and!(caseInsensitiveLiteral!"a", literal!"b"), '~'))(context, "Ab");
    assert(changed.matches == ["ab"] && changed.matches[0].ptr != changed.input.ptr);
    auto empty = parse!(transform!(eps, '~'))(context, "");
    assert(empty.matches == [""]);
}

template fuse(alias r) {
    alias fuse = transform!(r, '~');
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(fuse!(and!(literal!"a", discard!(literal!"b"), literal!"c")))(context, "abc");
    assert(result.matches == ["ac"]);
}

template discard(alias r) {
    alias discard = transform!(r, ':');
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(and!(literal!"a", discard!(literal!"b")))(context, "ab");
    assert(result.matches == ["a"]);
}

template drop(alias r) {
    alias drop = transform!(r, ';');
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(drop!(defined!(literal!"a", "Node")))(context, "a");
    assert(result.matches == ["a"] && result.children.length == 0);
}

template propagate(alias r) {
    alias propagate = transform!(r, '%');
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(propagate!(defined!(defined!(literal!"a", "Child"), "Parent")))(context, "a");
    assert(result.children[0].name == "Child");
}

template keep(alias r) {
    alias keep = transform!(r, '^');
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(keep!(literal!"a"))(context, "a");
    assert(result.children.length == 1 && result.children[0].matches == ["a"]);
}

template discardChildren(alias r) {
    alias discardChildren = drop!r;
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(discardChildren!(defined!(literal!"a", "Node")))(context, "a");
    assert(result.children.length == 0);
}

template defined(alias r, string name) {
    pragma(inline, true) State!(CT, Check).Node defined(bool CT, int Check = 0)(ref State!(CT, Check) s,
            size_t pos) nothrow {
        auto result = r(s, pos);
        static if (!Check)
            result.name = name;
        static if (!Check)
            if (result.matches.length || !result.successful)
                result.children = s.single(result);
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(defined!(literal!"a", "Node"))(context, "a");
    assert(result.name == "Node" && result.children[0].name == "Node");
}

template named(alias r, string name) {
    pragma(inline, true) State!(CT, Check).Node named(bool CT, int Check = 0)(ref State!(CT, Check) s,
            size_t pos) nothrow {
        auto result = r(s, pos);
        static if (!Check)
            result.name = name;
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(named!(literal!"a", "Node"))(context, "a");
    assert(result.name == "Node" && result.children.length == 0);
}

template action(alias r, alias act) {
    State!(CT, Check).Node action(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        static if (Check) {
            return s.treeFallback!(npegged.peg.action!(r, act))(pos);
        } else {
            auto result = r(s, pos);
            if (s.status != Status.ok) {
                result.successful = false;
                return result;
            }
            static if (__traits(compiles, act(s, result)))
                result = act(s, result);
            else
                result = act(result);
            if (!result.successful)
                s.recordFailure(result);
            return result;
        }
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(action!(literal!"a", (ParseTree p) @nogc nothrow{ p.name = "acted"; return p; }))(
            context, "a");
    assert(result.name == "acted");
}

@nogc nothrow unittest {
    ParseContext context;
    alias inspected = action!(literal!"a", (ParseTree tree) @nogc nothrow{
        assert(tree.matches == ["a"]);
        tree.successful = tree.input.length == 1;
        return tree;
    });
    auto good = check!inspected(context, "a");
    assert(good.successful && good.arena.allocationCalls > 0);
    auto bad = check!inspected(context, "ab");
    assert(!bad.successful && bad.status == Status.mismatch);
    context.memoryLimit = 0;
    auto exhausted = check!inspected(context, "a");
    assert(!exhausted.successful && exhausted.status == Status.resourceLimit);
}

template wrapAround(alias before, alias target, alias after) {
    State!(CT, Check).Node wrapAround(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        auto leading = before(s, pos);
        if (!leading.successful)
            return leading;
        auto result = target(s, leading.end);
        if (!result.successful)
            return result;
        auto trailing = after(s, result.end);
        if (!trailing.successful)
            return trailing;
        result.begin = leading.begin;
        result.end = trailing.end;
        static if (!Check)
            if (result.children.length == 1 && result.children[0].name == result.name) {
                auto child = result.children[0];
                child.begin = result.begin;
                child.end = result.end;
                static if (!Check)
                    result.children = s.single(child);
            }
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(wrapAround!(literal!"(", literal!"a", literal!")"))(context, "(a)");
    assert(result.end == 3 && result.matches == ["a"]);
    auto bad = parse!(wrapAround!(literal!"(", literal!"a", literal!")"))(context, "(a");
    assert(!bad.successful);
}

alias digit = charRange!('0', '9');
alias alpha = charRange!('a', 'z');
alias Alpha = charRange!('A', 'Z');
alias hexDigit = charClass!(CharSetMask.fromRanges(['0', '9'], ['a', 'f'], ['A', 'F']));
alias endOfLine = or!(literal!"\r\n", literal!"\n", literal!"\r");
alias eol = endOfLine;
alias space = or!(literal!" ", literal!"\t", literal!"\v");
alias blank = or!(space, endOfLine);
alias tab = literal!"\t";
alias spaces = fuse!(oneOrMore!space);
alias spacing = discard!(zeroOrMore!blank);
alias digits = fuse!(oneOrMore!digit);
private enum identStartMask = () {
    auto m = CharSetMask.fromRanges(['a', 'z'], ['A', 'Z']);
    m.addChar('_');
    return m;
}();
private enum identCharMask = () {
    auto m = CharSetMask.fromRanges(['a', 'z'], ['A', 'Z'], ['0', '9']);
    m.addChar('_');
    return m;
}();
alias ident = and!(oneOrMore!(charClass!identStartMask), zeroOrMore!(charClass!identCharMask));
alias identifier = named!(fuse!ident, "identifier");
alias qualifiedIdentifier = fuse!(and!(identifier, zeroOrMore!(and!(literal!".", identifier))));
alias slash = literal!"/";
alias backslash = literal!"\\";
alias quote = literal!"'";
alias doublequote = literal!"\"";
alias backquote = literal!"`";
template list(alias element, alias separator) {
    alias list = and!(element, zeroOrMore!(and!(discard!separator, element)));
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(list!(digit, literal!","))(context, "1,2,3");
    assert(result.matches == ["1", "2", "3"]);
}

template list0(alias element, alias separator) {
    alias list0 = option!(list!(element, separator));
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(list0!(digit, literal!","))(context, "");
    assert(result.successful && result.end == 0);
}

@nogc nothrow unittest {
    ParseContext ctx;
    auto seq = parse!(and!(literal!"a", literal!"b"))(ctx, "ab");
    assert(seq.matches == ["a", "b"] && seq.end == 2);
    auto bad = parse!(and!(literal!"a", literal!"b"))(ctx, "ac");
    assert(!bad.successful && bad.failedChild.length == 1);
    auto alternatives = parse!(or!(literal!"x", literal!"ab"))(ctx, "ab");
    assert(alternatives.successful);
    auto longest = parse!(longest_match!(literal!"a", literal!"ab"))(ctx, "ab");
    assert(longest.end == 2);
    auto repeated = parse!(oneOrMore!digit)(ctx, "123x");
    assert(repeated.matches == ["1", "2", "3"]);
    auto none = parse!(oneOrMore!digit)(ctx, "x");
    assert(!none.successful);
    auto nullable = parse!(zeroOrMore!eps)(ctx, "");
    assert(nullable.successful);
    auto optional = parse!(option!digit)(ctx, "x");
    assert(optional.successful);
    auto positive = parse!(posLookahead!digit)(ctx, "1");
    assert(positive.end == 0 && positive.successful);
    auto negative = parse!(negLookahead!digit)(ctx, "x");
    assert(negative.successful);
    auto fused = parse!(fuse!(oneOrMore!digit))(ctx, "123");
    assert(fused.matches == ["123"]);
    auto id = parse!identifier(ctx, "hello_42");
    assert(id.matches == ["hello_42"]);
    auto range = parse!(charRange!('é', 'ê'))(ctx, "é");
    assert(range.end == 2);
}

/// Full Unicode folding, preserving Pegged's fixed byte-length literal consumption.
template caseInsensitiveLiteral(string text) {
    State!(CT, Check).Node caseInsensitiveLiteral(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t pos) nothrow {
        if (!s.tick() || pos > s.input.length || text.length > s.input.length - pos
                || !caseEqual(s.input[pos .. pos + text.length], text))
            return s.failure(pos, text);
        auto result = s.node(pos, pos + text.length);
        static if (!Check)
            result.matches = s.single(text);
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(caseInsensitiveLiteral!"Σ")(context, "σ");
    assert(result.successful && result.matches == ["Σ"]);
}

bool caseEqual(scope string a, scope string b) @nogc nothrow pure {
    import npegged.unicode : folded;

    size_t ap, bp;
    string af, bf;
    size_t ai, bi;
    dchar ac, bc;
    bool advance(scope string input, ref size_t pos, ref string expansion, ref size_t i, out dchar value) @nogc nothrow pure {
        if (i < expansion.length)
            return decode(expansion, i, value);
        if (!decode(input, pos, value))
            return false;
        expansion = folded(value);
        i = 0;
        if (expansion.length)
            return decode(expansion, i, value);
        return true;
    }

    while (ap < a.length || ai < af.length) {
        if (!advance(a, ap, af, ai, ac) || !advance(b, bp, bf, bi, bc) || ac != bc)
            return false;
    }
    return bp == b.length && bi == bf.length;
}

@nogc nothrow unittest {
    assert(caseEqual("AbCΣß", "abcσss"));
    assert(!caseEqual("x", "xx"));
    assert(!caseEqual("xy", "x"));
    assert(!caseEqual("\xff", "a"));
    assert(!caseEqual("a", "\xff"));
    ParseContext ctx;
    auto result = parse!(caseInsensitiveLiteral!"Begin")(ctx, "BEGIN");
    assert(result.successful && result.matches == ["Begin"]);
    auto bad = parse!(caseInsensitiveLiteral!"Begin")(ctx, "End");
    assert(!bad.successful);
}

/// Matches a boundary between alphabetic and non-alphabetic input (zero bytes).
State!(CT, Check).Node wordBoundary(bool CT, int Check = 0)(ref State!(CT, Check) state, size_t pos) nothrow {
    import npegged.unicode : isAlphabetic;

    bool left, right;
    dchar value;
    if (pos > 0 && pos <= state.input.length) {
        size_t start = pos - 1;
        while (start && (cast(ubyte)state.input[start] & 0xC0) == 0x80)
            --start;
        size_t end = start;
        left = decode(state.input, end, value) && end == pos && isAlphabetic(value);
    }
    if (pos < state.input.length) {
        size_t end = pos;
        right = decode(state.input, end, value) && isAlphabetic(value);
    }
    return left != right ? state.node(pos, pos) : state.failure(pos, "word boundary");
}

@nogc nothrow unittest {
    ParseContext context;
    auto start = parse!wordBoundary(context, "α");
    assert(start.successful && start.end == 0);
    auto finish = parse!(and!(literal!"α", wordBoundary))(context, "α ");
    assert(finish.successful);
    auto inside = parse!(and!(literal!"α", wordBoundary))(context, "αβ");
    assert(!inside.successful);
    auto empty = parse!wordBoundary(context, "");
    assert(!empty.successful);
}

template keywords(words...) {
    State!(CT, Check).Node keywords(bool CT, int Check = 0)(ref State!(CT, Check) state, size_t pos) nothrow {
        auto best = state.node(pos, pos, false);
        static foreach (word; words) {
            {
                auto candidate = literal!word(state, pos);
                if (candidate.successful)
                    return candidate;
            }
        }
        return best;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(keywords!("interface", "int", "in"))(context, "interface");
    assert(result.successful && result.end == 9);
    auto bad = parse!(keywords!("in", "int"))(context, "x");
    assert(!bad.successful);
}

template discardMatches(alias parser) {
    State!(CT, Check).Node discardMatches(bool CT, int Check = 0)(ref State!(CT, Check) state, size_t pos) nothrow {
        auto result = parser(state, pos);
        if (result.successful)
            static if (!Check)
                result.matches = null;
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(discardMatches!(defined!(literal!"a", "A")))(context, "a");
    assert(result.successful && result.matches.length == 0 && result.children.length == 1);
}

template spaceAnd(alias separator, parsers...) {
    State!(CT, Check).Node spaceAnd(bool CT, int Check = 0)(ref State!(CT, Check) state, size_t pos) nothrow {
        auto result = state.node(pos, pos);
        State!(CT, Check).Builder!string matches = {owner: &state};
        State!(CT, Check).Builder!ParseTree children = {owner: &state};
        static foreach (parser; parsers) {
            {
                auto part = wrapAround!(separator, parser, separator)(state, result.end);
                if (!part.successful)
                    return part;
                result.end = part.end;
                static if (!Check) {
                    matches.put(part.matches);
                    children.put(part.children);
                }
            }
        }
        static if (!Check)
            result.matches = matches.data();
        static if (!Check)
            result.children = children.data();
        return result;
    }
}

@nogc nothrow unittest {
    ParseContext context;
    auto result = parse!(spaceAnd!(spacing, literal!"a", literal!"b"))(context, " a b ");
    assert(result.successful && result.end == 5 && result.matches == ["a", "b"]);
}

struct Position {
    size_t line, col, index;
}

Position position(scope string input) @nogc nothrow pure {
    Position result;
    char previous = 0;
    foreach (c; input) {
        if (c == '\r' || c == '\n' && previous != '\r') {
            ++result.line;
            result.col = 0;
        } else if (c != '\n')
            ++result.col;
        previous = c;
        ++result.index;
    }
    return result;
}

@nogc nothrow unittest {
    assert(position("one\r\ntwo\r\nthree") == Position(2, 5, 15));
    assert(position("") == Position(0, 0, 0));
    assert(position("a\nb") == Position(1, 1, 3));
}

Position position(scope const ref ParseTree tree) @nogc nothrow pure {
    size_t end = tree.end <= tree.input.length ? tree.end : tree.input.length;
    return position(tree.input[0 .. end]);
}

@nogc nothrow unittest {
    ParseTree tree;
    tree.input = "a\nb";
    tree.end = 3;
    assert(position(tree) == Position(1, 1, 3));
}

@nogc nothrow unittest {
    ParseContext context;
    // Fail allocations and work budgets at different points in nested parser execution.
    foreach (budget; 0 .. 80) {
        context = ParseContext.init;
        context.memoryLimit = budget * 128;
        auto result = parse!(and!(defined!(fuse!(oneOrMore!digit), "Number"), literal!"x"))(
                context, "12345678901234567890x");
        assert(result.status == Status.ok || result.status == Status.resourceLimit);
        context = ParseContext.init;
        context.stepLimit = budget;
        auto limited = parse!(action!(oneOrMore!digit, (ParseTree tree) @nogc nothrow => tree))(context,
                "1234567890");
        assert(limited.status == Status.ok || limited.status == Status.resourceLimit);
    }
    auto leading = parse!(wrapAround!(literal!"(", literal!"a", literal!")"))(context, "a)");
    assert(!leading.successful);
    auto kept = parse!(keep!(defined!(literal!"a", "Child")))(context, "a");
    assert(kept.successful);
    auto failed = parse!(discardMatches!(literal!"a"))(context, "x");
    assert(!failed.successful);
    auto separated = parse!(spaceAnd!(spacing, literal!"a", literal!"b"))(context, " a x ");
    assert(!separated.successful);
    auto equalLength = parse!(caseInsensitiveLiteral!"abc")(context, "xyz");
    assert(!equalLength.successful);
    auto middle = parse!(and!(any, wordBoundary))(context, "α");
    assert(!middle.successful);
    auto word = parse!(and!(literal!"1", wordBoundary))(context, "1x");
    assert(word.successful);
    context.stepLimit = 0;
    auto byteLimited = parse!any(context, "a");
    assert(byteLimited.status == Status.resourceLimit);
    auto caseLimited = parse!(caseInsensitiveLiteral!"a")(context, "a");
    assert(caseLimited.status == Status.resourceLimit);
    auto rangeLimited = parse!(charRange!('a', 'z'))(context, "a");
    assert(rangeLimited.status == Status.resourceLimit);
}

@nogc nothrow unittest {
    ParseContext context;
    alias listParser = and!(literal!"[", digit, zeroOrMore!(and!(literal!",", digit)), literal!"]", eoi);
    auto invalid = parse!listParser(context, "[1,]");
    assert(invalid.status == Status.mismatch && invalid.failEnd == 3);
    auto diagnostic = invalid.failMsg;
    assert(diagnostic.data.length);
    auto valid = parse!listParser(context, "[1,2]");
    assert(valid.successful);
    // Failed matches inside a successful negative predicate must not override the real error.
    auto predicate = parse!(and!(negLookahead!(literal!"abc"), literal!"x"))(context, "abz");
    assert(!predicate.successful && predicate.failEnd == 0);
    auto positive = parse!(posLookahead!(literal!"abc"))(context, "abz");
    assert(positive.failEnd == 2);
    auto negative = parse!(negLookahead!(literal!"abc"))(context, "abc");
    assert(!negative.successful);
}
