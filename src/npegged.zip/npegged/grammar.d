/** Grammar frontend derived from Pegged's extended PEG syntax (Boost 1.0).
    Runtime code generation is a cold path using selective druntime GC. */
module npegged.grammar;
public import npegged.peg;
public import npegged.dfa;
import npegged.io;
import npegged.analysis : GrammarAnalysis, Expression, ExpressionKind, Nullable, FirstFacts;

nothrow:

struct Diagnostic {
    size_t offset;
    string message;
}

enum Memoization {
    no,
    yes,
    selective
}

/// The direct backend lowers recognition control; other modes retain combinators.
enum ParserBackend {
    combinators,
    direct
}

private string number(ulong value) pure nothrow {
    char[32] digits;
    size_t start = digits.length;
    do {
        digits[--start] = cast(char)('0' + value % 10);
        value /= 10;
    }
    while (value);
    return digits[start .. $].idup;
}

unittest {
    assert(number(0) == "0");
    assert(number(123) == "123");
}

private bool startsWith(scope string s, scope string prefix) @nogc nothrow pure @safe {
    return s.length >= prefix.length && s[0 .. prefix.length] == prefix;
}

private string ulongHex(ulong value) pure nothrow {
    if (value == 0)
        return "0x0UL";
    char[22] buf;
    buf[0 .. 2] = "0x";
    enum hex = "0123456789abcdef";
    char[16] digits;
    size_t len;
    ulong v = value;
    while (v) {
        digits[len++] = hex[v & 0xF];
        v >>= 4;
    }
    size_t outLen = 2;
    while (len) {
        buf[outLen++] = digits[--len];
    }
    return (buf[0 .. outLen] ~ "UL").idup;
}

unittest {
    assert(ulongHex(0) == "0x0UL");
    assert(ulongHex(15) == "0xfUL");
    assert(ulongHex(256) == "0x100UL");
    assert(startsWith("hello world", "hello"));
    assert(!startsWith("hello", "world"));
}

private string quoted(string text) pure nothrow {
    string result = "\"";
    foreach (c; text) {
        switch (c) {
        case '\\':
            result ~= "\\\\";
            break;
        case '"':
            result ~= "\\\"";
            break;
        case '\n':
            result ~= "\\n";
            break;
        case '\r':
            result ~= "\\r";
            break;
        case '\t':
            result ~= "\\t";
            break;
        case '\0':
            result ~= "\\0";
            break;
        default:
            if (cast(ubyte)c < 32 || cast(ubyte)c >= 127) {
                enum hex = "0123456789ABCDEF";
                result ~= "\\x" ~ hex[(cast(ubyte)c) >> 4] ~ hex[(cast(ubyte)c) & 15];
            } else
                result ~= c;
            break;
        }
    }
    return result ~ "\"";
}

unittest {
    assert(quoted("a\n\"\\") == "\"a\\n\\\"\\\\\"");
}

/// Cold grammar frontend. Runtime generation selectively uses druntime GC; emitted parsers never do.
package struct Frontend {
    string input;
    size_t pos;
    Diagnostic error;
    bool spaced;
    struct Rule {
        string name, params, body;
    }

    Rule[] rules;
    string name, params;
    bool memoize = true;
    bool selective;
    ParserBackend backend;
    uint[] recordKinds;
    bool[] recordLeaves;
    bool[] recordSubtrees;
    string[] parameterNames;
    private GrammarAnalysis analyzed;
    private bool hasAnalysis;
    private bool[] scalarRules;
    private string directDeclarations, directRule;
    void skip() nothrow {
        while (pos < input.length) {
            if (input[pos] == ' ' || input[pos] == '\t' || input[pos] == '\n' || input[pos] == '\r')
                ++pos;
            else if (input[pos] == '#') {
                while (pos < input.length && input[pos] != '\n')
                    ++pos;
            } else
                break;
        }
    }

    bool accept(char c) nothrow {
        skip();
        if (pos < input.length && input[pos] == c) {
            ++pos;
            return true;
        }
        return false;
    }

    void require(char c) nothrow {
        if (!accept(c))
            problem("Expected '" ~ c ~ "'");
    }

    void problem(string message) nothrow {
        if (!error.message.length)
            error = Diagnostic(pos, message);
    }

    string ident() nothrow {
        skip();
        size_t start = pos;
        if (pos >= input.length || !isInitial(input[pos]))
            return null;
        ++pos;
        while (pos < input.length && (isInitial(input[pos]) || (input[pos] >= '0' && input[pos] <= '9')))
            ++pos;
        return input[start .. pos];
    }

    static bool isInitial(char c) @nogc nothrow pure {
        return c == '_' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z';
    }

    string parameters() nothrow {
        if (!accept('('))
            return null;
        string result = "(";
        do {
            auto id = ident();
            if (!id.length) {
                problem("Expected parameter name");
                break;
            }
            parameterNames ~= id;
            result ~= "alias " ~ id;
            if (accept('='))
                result ~= " = " ~ expression();
            if (!accept(','))
                break;
            result ~= ", ";
        }
        while (!error.message.length);
        require(')');
        return result ~ ")";
    }

    bool definitionAhead() nothrow {
        size_t saved = pos;
        auto id = ident();
        if (!id.length) {
            pos = saved;
            return false;
        }
        if (accept('(')) {
            size_t depth = 1;
            while (pos < input.length && depth) {
                auto c = input[pos++];
                if (c == '\'' || c == '"') {
                    auto delimiter = c;
                    while (pos < input.length && input[pos] != delimiter) {
                        if (input[pos++] == '\\' && pos < input.length)
                            ++pos;
                    }
                    if (pos < input.length)
                        ++pos;
                    continue;
                }
                if (c == '(')
                    ++depth;
                if (c == ')')
                    --depth;
            }
        }
        skip();
        bool result = pos < input.length && input[pos] == '<';
        pos = saved;
        return result;
    }

    string expression() nothrow {
        skip();
        char kind = 0;
        if (pos < input.length && (input[pos] == '/' || input[pos] == '|'))
            kind = input[pos++];
        string[] choices;
        choices ~= sequence();
        while (!error.message.length) {
            skip();
            if (pos >= input.length || (input[pos] != '/' && input[pos] != '|'))
                break;
            char next = input[pos++];
            if (kind && kind != next) {
                problem("Cannot mix / and | in one expression");
                break;
            }
            kind = next;
            choices ~= sequence();
        }
        if (choices.length == 1)
            return choices[0];
        string result = kind == '|' ? "longest_match!(" : "or!(";
        foreach (i, choice; choices)
            result ~= (i ? ", " : "") ~ choice;
        return result ~ ")";
    }

    string sequence() nothrow {
        string[] pieces;
        while (!error.message.length) {
            skip();
            if (pos >= input.length || input[pos] == ')' || input[pos] == ',' || input[pos] == '/'
                    || input[pos] == '|' || definitionAhead())
                break;
            auto before = pos;
            auto piece = prefix();
            if (pos == before) {
                problem("Expected parsing expression");
                break;
            }
            pieces ~= piece;
        }
        if (!pieces.length) {
            problem("Empty sequence");
            return "eps";
        }
        if (pieces.length == 1)
            return pieces[0];
        string result = "and!(";
        foreach (i, piece; pieces)
            result ~= (i ? ", " : "") ~ piece;
        return result ~ ")";
    }

    string prefix() nothrow {
        skip();
        string operators;
        while (pos < input.length && isPrefix(input[pos])) {
            operators ~= input[pos++];
            skip();
        }
        auto result = primary();
        while (!error.message.length) {
            if (accept('?'))
                result = "option!(" ~ result ~ ")";
            else if (accept('*'))
                result = "zeroOrMore!(" ~ result ~ ")";
            else if (accept('+'))
                result = "oneOrMore!(" ~ result ~ ")";
            else if (accept('{'))
                result = actions(result);
            else
                break;
        }
        foreach (c; operators)
            result = operation(c) ~ "!(" ~ result ~ ")";
        return result;
    }

    static bool isPrefix(char c) @nogc nothrow pure {
        return c == '&' || c == '!' || c == '~' || c == ':' || c == '^' || c == ';' || c == '%';
    }

    static string operation(char c) @nogc nothrow pure {
        switch (c) {
        case '&':
            return "posLookahead";
        case '!':
            return "negLookahead";
        case '~':
            return "fuse";
        case ':':
            return "discard";
        case '^':
            return "keep";
        case ';':
            return "drop";
        case '%':
            return "propagate";
        default:
            assert(false);
        }
    }

    string primary() nothrow {
        skip();
        string result;
        if (accept('(')) {
            result = expression();
            require(')');
        } else if (accept('.'))
            result = "any";
        else if (accept('[')) {
            bool allAscii = true;
            CharSetMask mask;
            size_t elementCount = 0;
            dchar singleFirst = 0, singleLast = 0;
            bool singleByteEscape = false;
            string[] nonAsciiRanges;
            while (pos < input.length && input[pos] != ']' && !error.message.length) {
                bool byteEscape = input[pos] == '\\' && pos + 1 < input.length
                    && (input[pos + 1] == 'x' || input[pos + 1] >= '0' && input[pos + 1] <= '7');
                auto first = character();
                if (pos < input.length && input[pos] == '-' && pos + 1 < input.length && input[pos + 1] != ']') {
                    ++pos;
                    auto last = character();
                    if (last < 256) {
                        mask.addRange(first, last);
                    } else {
                        allAscii = false;
                        nonAsciiRanges ~= "charRange!(" ~ number(first) ~ ", " ~ number(last) ~ ")";
                    }
                    singleFirst = first;
                    singleLast = last;
                    singleByteEscape = false;
                    ++elementCount;
                } else if (byteEscape) {
                    if (first < 256) {
                        mask.addChar(first);
                    } else {
                        allAscii = false;
                        nonAsciiRanges ~= "literal!(" ~ quoted([cast(char)first].idup) ~ ")";
                    }
                    singleFirst = first;
                    singleLast = first;
                    singleByteEscape = true;
                    ++elementCount;
                } else {
                    if (first < 256) {
                        mask.addChar(first);
                    } else {
                        allAscii = false;
                        nonAsciiRanges ~= "charRange!(" ~ number(first) ~ ", " ~ number(first) ~ ")";
                    }
                    singleFirst = first;
                    singleLast = first;
                    singleByteEscape = false;
                    ++elementCount;
                }
            }
            require(']');
            if (!elementCount)
                result = "fail";
            else if (elementCount == 1 && singleByteEscape) {
                result = "literal!(" ~ quoted([cast(char)singleFirst].idup) ~ ")";
            } else if (elementCount == 1 && allAscii) {
                result = "charRange!(" ~ number(singleFirst) ~ ", " ~ number(singleLast) ~ ")";
            } else if (allAscii) {
                result = "charClass!(" ~ ulongHex(mask.bits[0]) ~ ", " ~ ulongHex(
                        mask.bits[1]) ~ ", " ~ ulongHex(mask.bits[2]) ~ ", " ~ ulongHex(mask.bits[3]) ~ ")";
            } else {
                string[] allChoices;
                if (!mask.empty)
                    allChoices ~= "charClass!(" ~ ulongHex(mask.bits[0]) ~ ", " ~ ulongHex(
                            mask.bits[1]) ~ ", " ~ ulongHex(mask.bits[2]) ~ ", " ~ ulongHex(mask.bits[3]) ~ ")";
                allChoices ~= nonAsciiRanges;
                result = "or!(";
                foreach (i, c; allChoices)
                    result ~= (i ? ", " : "") ~ c;
                result ~= ")";
            }
        } else if (pos < input.length && (input[pos] == '\'' || input[pos] == '"')) {
            auto delimiter = input[pos++];
            string text;
            while (pos < input.length && input[pos] != delimiter && !error.message.length) {
                bool byteEscape = input[pos] == '\\' && pos + 1 < input.length
                    && (input[pos + 1] == 'x' || input[pos + 1] >= '0' && input[pos + 1] <= '7');
                auto scalar = character(true);
                text ~= byteEscape ? [cast(char)scalar].idup : encode(scalar);
            }
            if (pos == input.length)
                problem("Unterminated literal");
            else
                ++pos;
            bool insensitive = pos < input.length && input[pos] == 'i';
            if (insensitive)
                ++pos;
            result = (insensitive ? "caseInsensitiveLiteral!(" : "literal!(") ~ quoted(text) ~ ")";
        } else {
            result = ident();
            if (!result.length) {
                problem("Expected literal, range, group, or rule name");
                return "fail";
            }
            while (!error.message.length) {
                size_t beforeArguments = pos;
                if (pos < input.length && input[pos] == '(') {
                    ++pos;
                    result ~= "!(";
                    size_t count;
                    do {
                        result ~= (count++ ? ", " : "") ~ expression();
                    }
                    while (accept(','));
                    require(')');
                    result ~= ")";
                } else {
                    pos = beforeArguments;
                    // Qualified rule names cannot have whitespace around the dot.
                    size_t saved = pos;
                    if (pos + 1 < input.length && input[pos] == '.' && isInitial(input[pos + 1])) {
                        ++pos;
                        auto id = ident();
                        result ~= "." ~ id;
                    } else {
                        pos = saved;
                        break;
                    }
                }
            }
        }
        if (spaced)
            result = "wrapAround!(Spacing, " ~ result ~ ", Spacing)";
        return result;
    }

    dchar character(bool literalMode = false) nothrow {
        if (pos == input.length) {
            problem("Expected character");
            return 0;
        }
        if (input[pos] != '\\') {
            dchar value;
            if (!decode(input, pos, value))
                problem("Invalid UTF-8");
            return value;
        }
        ++pos;
        if (pos == input.length) {
            problem("Incomplete escape");
            return 0;
        }
        auto c = input[pos++];
        switch (c) {
        case 'n':
            return '\n';
        case 'r':
            return '\r';
        case 't':
            return '\t';
        case 'b':
            return '\b';
        case 'f':
            return '\f';
        case 'v':
            return '\v';
        case 'x':
        case 'u':
        case 'U': {
                uint value;
                uint count = c == 'x' ? 2 : c == 'u' ? 4 : 8;
                foreach (i; 0 .. count) {
                    if (pos == input.length) {
                        problem("Incomplete hex escape");
                        return 0;
                    }
                    auto digit = input[pos++];
                    uint n = digit >= '0' && digit <= '9' ? digit - '0' : digit >= 'a' && digit <= 'f'
                        ? digit - 'a' + 10 : digit >= 'A' && digit <= 'F' ? digit - 'A' + 10 : 16;
                    if (n == 16) {
                        problem("Invalid hex escape");
                        return 0;
                    }
                    value = value * 16 + n;
                }
                if (value > 0x10FFFF || value >= 0xD800 && value <= 0xDFFF)
                    problem("Invalid Unicode scalar");
                return cast(dchar)value;
            }
        default:
            if (c >= '0' && c <= '7') {
                uint value = c - '0';
                foreach (i; 0 .. (literalMode || c <= '2' ? 2 : 1)) {
                    if (pos == input.length || input[pos] < '0' || input[pos] > '7')
                        break;
                    value = value * 8 + input[pos++] - '0';
                }
                return cast(dchar)value;
            }
            return c;
        }
    }

    string actions(string result) nothrow {
        size_t start = pos, depth;
        char quote = 0;
        bool escaped;
        while (pos < input.length) {
            char c = input[pos++];
            if (!quote && c == '/' && pos < input.length) {
                if (input[pos] == '/') {
                    while (pos < input.length && input[pos] != '\n')
                        ++pos;
                    continue;
                }
                if (input[pos] == '*') {
                    ++pos;
                    while (pos + 1 < input.length && !(input[pos] == '*' && input[pos + 1] == '/'))
                        ++pos;
                    if (pos + 1 == input.length) {
                        problem("Unterminated action comment");
                        return result;
                    }
                    pos += 2;
                    continue;
                }
                if (input[pos] == '+') {
                    ++pos;
                    size_t nesting = 1;
                    while (pos + 1 < input.length && nesting) {
                        if (input[pos] == '/' && input[pos + 1] == '+') {
                            ++nesting;
                            pos += 2;
                        } else if (input[pos] == '+' && input[pos + 1] == '/') {
                            --nesting;
                            pos += 2;
                        } else
                            ++pos;
                    }
                    if (nesting) {
                        problem("Unterminated nested action comment");
                        return result;
                    }
                    continue;
                }
            }
            if (quote) {
                if (escaped)
                    escaped = false;
                else if (c == '\\' && quote != '`')
                    escaped = true;
                else if (c == quote)
                    quote = 0;
                continue;
            }
            if (c == '\'' || c == '"' || c == '`') {
                quote = c;
                continue;
            }
            if (c == '(' || c == '[' || c == '{')
                ++depth;
            else if ((c == ')' || c == ']' || c == '}') && depth)
                --depth;
            else if (!depth && (c == ',' || c == '}')) {
                auto expression = input[start .. pos - 1];
                result = "action!(" ~ result ~ ", " ~ expression ~ ")";
                if (c == '}')
                    return result;
                start = pos;
            }
        }
        problem("Unterminated semantic action");
        return result;
    }

    void read() nothrow {
        hasAnalysis = false;
        name = ident();
        params = parameters();
        require(':');
        if (!name.length)
            problem("Expected grammar name");
        while (!error.message.length) {
            skip();
            if (pos == input.length)
                break;
            auto ruleName = ident();
            auto ruleParams = parameters();
            require('<');
            char arrow = 0;
            string arrowActions;
            if (pos < input.length) {
                if (input[pos] == '-')
                    ++pos;
                else if (isPrefix(input[pos]) && input[pos] != '!' && input[pos] != '&')
                    arrow = input[pos++];
                else if (input[pos] == '{') {
                    ++pos;
                    arrowActions = actions("__BODY__");
                } else
                    arrow = ' ';
            }
            spaced = arrow == ' ';
            auto body = expression();
            spaced = false;
            if (arrow && arrow != ' ')
                body = operation(arrow) ~ "!(" ~ body ~ ")";
            if (arrowActions.length) {
                string replaced;
                for (size_t i; i < arrowActions.length;) {
                    if (i + 8 <= arrowActions.length && arrowActions[i .. i + 8] == "__BODY__") {
                        replaced ~= body;
                        i += 8;
                    } else
                        replaced ~= arrowActions[i++];
                }
                body = replaced;
            }
            rules ~= Rule(ruleName, ruleParams, body);
        }
        if (!rules.length)
            problem("Grammar needs at least one rule");
    }

    struct FirstSetResult {
        bool known;
        bool canBeEmpty;
        CharSetMask mask;
    }

    FirstSetResult primitiveFirstSet(string expr) const nothrow {
        FirstSetResult res;
        while (expr.length > 0 && expr[0] == ' ')
            expr = expr[1 .. $];
        while (expr.length > 0 && expr[$ - 1] == ' ')
            expr = expr[0 .. $ - 1];

        if (startsWith(expr, "literal!(") || startsWith(expr, "literal!\"")) {
            size_t qStart = 0;
            while (qStart < expr.length && expr[qStart] != '"')
                qStart++;
            if (qStart < expr.length) {
                size_t qEnd = qStart + 1;
                while (qEnd < expr.length && expr[qEnd] != '"') {
                    if (expr[qEnd] == '\\' && qEnd + 1 < expr.length)
                        qEnd += 2;
                    else
                        qEnd++;
                }
                string content = expr[qStart + 1 .. qEnd];
                if (content.length == 0) {
                    res.known = true;
                    res.canBeEmpty = true;
                    return res;
                }
                char c = content[0];
                if (c == '\\' && content.length > 1) {
                    char esc = content[1];
                    switch (esc) {
                    case 'n':
                        c = '\n';
                        break;
                    case 'r':
                        c = '\r';
                        break;
                    case 't':
                        c = '\t';
                        break;
                    case '0':
                        c = '\0';
                        break;
                    case '\\':
                        c = '\\';
                        break;
                    case '"':
                        c = '"';
                        break;
                    default:
                        c = esc;
                        break;
                    }
                }
                res.known = true;
                res.canBeEmpty = false;
                res.mask.addChar(c);
                return res;
            }
        }

        if (startsWith(expr, "charRange!(")) {
            string inner = expr[11 .. $];
            if (inner.length > 0 && inner[$ - 1] == ')')
                inner = inner[0 .. $ - 1];
            size_t comma = 0;
            while (comma < inner.length && inner[comma] != ',')
                comma++;
            if (comma < inner.length) {
                string sLow = inner[0 .. comma];
                string sHigh = inner[comma + 1 .. $];
                while (sLow.length > 0 && sLow[0] == ' ')
                    sLow = sLow[1 .. $];
                while (sHigh.length > 0 && sHigh[0] == ' ')
                    sHigh = sHigh[1 .. $];
                uint low = 0, high = 0;
                foreach (ch; sLow) {
                    if (ch >= '0' && ch <= '9')
                        low = low * 10 + (ch - '0');
                }
                foreach (ch; sHigh) {
                    if (ch >= '0' && ch <= '9')
                        high = high * 10 + (ch - '0');
                }
                if (high < 128 && low <= high) {
                    res.known = true;
                    res.canBeEmpty = false;
                    res.mask.addRange(low, high);
                    return res;
                }
            }
        }

        if (startsWith(expr, "charClass!(")) {
            string inner = expr[11 .. $];
            if (inner.length > 0 && inner[$ - 1] == ')')
                inner = inner[0 .. $ - 1];
            ulong[4] b;
            size_t idx = 0;
            size_t start = 0;
            for (size_t i = 0; i <= inner.length && idx < 4; ++i) {
                if (i == inner.length || inner[i] == ',') {
                    string part = inner[start .. i];
                    while (part.length > 0 && (part[0] == ' ' || part[0] == '\t'))
                        part = part[1 .. $];
                    while (part.length > 0 && (part[$ - 1] == 'U' || part[$ - 1] == 'L' || part[$ - 1] == ' '))
                        part = part[0 .. $ - 1];
                    ulong val = 0;
                    if (startsWith(part, "0x") || startsWith(part, "0X")) {
                        foreach (ch; part[2 .. $]) {
                            uint n = ch >= '0' && ch <= '9' ? ch - '0' : ch >= 'a' && ch <= 'f'
                                ? ch - 'a' + 10 : ch >= 'A' && ch <= 'F' ? ch - 'A' + 10 : 0;
                            val = (val << 4) | n;
                        }
                    } else {
                        foreach (ch; part) {
                            if (ch >= '0' && ch <= '9')
                                val = val * 10 + (ch - '0');
                        }
                    }
                    b[idx++] = val;
                    start = i + 1;
                }
            }
            if (idx == 4) {
                res.known = true;
                res.canBeEmpty = false;
                res.mask = CharSetMask(b);
                return res;
            }
        }

        if (expr == "digit") {
            res.known = true;
            res.mask.addRange('0', '9');
            return res;
        }
        if (expr == "alpha") {
            res.known = true;
            res.mask.addRange('a', 'z');
            return res;
        }
        if (expr == "Alpha") {
            res.known = true;
            res.mask.addRange('A', 'Z');
            return res;
        }
        if (expr == "hexDigit") {
            res.known = true;
            res.mask.addRange('0', '9');
            res.mask.addRange('a', 'f');
            res.mask.addRange('A', 'F');
            return res;
        }
        if (expr == "space") {
            res.known = true;
            res.mask.addChar(' ');
            res.mask.addChar('\t');
            res.mask.addChar('\v');
            return res;
        }
        if (expr == "blank") {
            res.known = true;
            res.mask.addChar(' ');
            res.mask.addChar('\t');
            res.mask.addChar('\v');
            res.mask.addChar('\r');
            res.mask.addChar('\n');
            return res;
        }
        if (expr == "ident" || expr == "identifier") {
            res.known = true;
            res.mask.addRange('a', 'z');
            res.mask.addRange('A', 'Z');
            res.mask.addChar('_');
            return res;
        }

        return res;
    }

    private string decodedLiteral(string source) const nothrow {
        Frontend decoder;
        decoder.input = source;
        while (decoder.pos < source.length && source[decoder.pos] != '"')
            ++decoder.pos;
        if (decoder.pos == source.length)
            return null;
        ++decoder.pos;
        string bytes;
        while (decoder.pos < source.length && source[decoder.pos] != '"') {
            const byteEscape = source[decoder.pos] == '\\' && decoder.pos + 1 < source.length
                && source[decoder.pos + 1] == 'x';
            const scalar = decoder.character(true);
            bytes ~= byteEscape ? [cast(char)scalar].idup : encode(scalar);
        }
        return bytes;
    }

    nothrow unittest {
        Frontend frontend;
        assert(frontend.decodedLiteral(`literal!("a\n\x80é")`) == "a\n\x80é");
        assert(frontend.decodedLiteral("unknown") is null);
    }

    private size_t expressionNode(ref GrammarAnalysis graph, string text) const nothrow {
        while (text.length && (text[0] == ' ' || text[0] == '\t'))
            text = text[1 .. $];
        while (text.length && (text[$ - 1] == ' ' || text[$ - 1] == '\t'))
            text = text[0 .. $ - 1];
        Expression node;
        node.source = text;
        size_t marker;
        while (marker < text.length && text[marker] != '!')
            ++marker;
        bool parameter;
        if (marker == text.length)
            foreach (name; parameterNames)
                if (text == name)
                    parameter = true;
        size_t knownRule = size_t.max;
        if (marker == text.length && !parameter)
            knownRule = graph.ruleIndex(text);
        if (parameter)
            node.kind = ExpressionKind.unknown;
        else if (knownRule != size_t.max) {
            node.kind = ExpressionKind.reference;
            node.reference = text;
            node.rule = knownRule;
        } else if (marker == text.length && (text == "eps" || text == "eoi" || text == "endOfInput" || text == "fail")) {
            node.kind = ExpressionKind.terminal;
            node.known = true;
            node.nullable = text == "fail" ? Nullable.no : Nullable.yes;
        } else if (marker == text.length && text == "any") {
            node.kind = ExpressionKind.terminal;
            node.known = true;
            node.nullable = Nullable.no;
            node.first = CharSetMask([ulong.max, ulong.max, ulong.max, ulong.max]);
        } else {
            string combinator = text[0 .. marker];
            bool compound = marker + 2 < text.length && text[marker .. marker + 2] == "!(" && text[$ - 1] == ')';
            string[] args;
            if (compound)
                args = splitTemplateArgs(text[marker + 2 .. $ - 1]);
            node.arguments = args;
            bool children;
            if (compound && (combinator == "and" || combinator == "wrapAround")) {
                node.kind = ExpressionKind.sequence;
                children = true;
            } else if (compound && (combinator == "or" || combinator == "longest_match"
                    || combinator == "predictiveChoice")) {
                node.kind = ExpressionKind.choice;
                children = true;
            } else if (compound && args.length && (combinator == "option" || combinator == "zeroOrMore")) {
                node.kind = combinator == "option" ? ExpressionKind.optional : ExpressionKind
                    .repetition;
                args.length = 1;
                children = true;
            } else if (compound && args.length && (combinator == "posLookahead"
                    || combinator == "negLookahead" || combinator == "predictiveNot")) {
                node.kind = ExpressionKind.predicate;
                args.length = 1;
                children = true;
            } else if (compound && args.length && (combinator == "discard" || combinator == "fuse"
                    || combinator == "keep"
                    || combinator == "drop" || combinator == "propagate" || combinator == "oneOrMore"
                    || combinator == "named"
                    || combinator == "defined" || combinator == "branch" || combinator == "dfaToken")) {
                node.kind = ExpressionKind.wrapper;
                args.length = 1;
                children = true;
            }
            if (children) {
                node.combinator = combinator;
                foreach (arg; args)
                    node.children ~= expressionNode(graph, arg);
            } else {
                auto primitive = primitiveFirstSet(text);
                if (primitive.known) {
                    node.kind = ExpressionKind.terminal;
                    node.first = primitive.mask;
                    node.known = true;
                    node.nullable = primitive.canBeEmpty ? Nullable.yes : Nullable.no;
                } else if (startsWith(text, "charRange!(") || startsWith(text, "charClass!(")
                        || startsWith(text, "caseInsensitiveLiteral!(")) {
                    // Unknown Unicode FIRST bytes must not imply unknown rule calls.
                    node.kind = ExpressionKind.terminal;
                    node.nullable = Nullable.no;
                } else if (text == "spacing" || text == "Spacing") {
                    node.kind = ExpressionKind.terminal;
                    node.nullable = Nullable.yes;
                    node.known = true;
                    node.first = primitiveFirstSet("blank").mask;
                } else if (text == "doublequote" || text == "backslash" || text == "quote"
                        || text == "slash" || text == "backquote" || text == "tab") {
                    node.kind = ExpressionKind.terminal;
                    node.nullable = Nullable.no;
                    node.known = true;
                    node.first.addChar(text == "doublequote" ? '"' : text == "backslash"
                            ? '\\' : text == "quote" ? '\'' : text == "slash" ? '/' : text == "tab" ? '\t' : '`');
                } else if (text == "endOfLine" || text == "eol") {
                    node.kind = ExpressionKind.terminal;
                    node.nullable = Nullable.no;
                    node.known = true;
                    node.first.addChar('\r');
                    node.first.addChar('\n');
                } else if (marker == text.length) {
                    node.kind = ExpressionKind.reference;
                    node.reference = text;
                }
            }
        }
        if (node.kind == ExpressionKind.terminal && startsWith(text, "literal!")) {
            node.byteTerminal = true;
            const bytes = decodedLiteral(text);
            node.byteWidth = bytes.length;
            node.first = CharSetMask.init;
            if (bytes.length)
                node.first.addChar(bytes[0]);
            foreach (c; bytes)
                node.alphabet.addChar(c);
        } else if (node.kind == ExpressionKind.terminal && node.known && node.nullable == Nullable.no
                && (text == "any" || text == "digit" || text == "alpha" || text == "Alpha"
                    || text == "hexDigit" || text == "space" || text == "blank"
                    || text == "doublequote" || text == "backslash"
                    || text == "quote" || text == "slash" || text == "backquote" || text == "tab"
                    || startsWith(text, "charClass!(") || startsWith(text, "charRange!("))) {
            node.byteTerminal = true;
            node.byteWidth = 1;
            node.alphabet = node.first;
        }
        // A guarded byte is a common spelling of a complemented byte class.
        if (node.combinator == "and" && node.children.length == 2) {
            auto guard = graph.expressions[node.children[0]];
            auto consumedByte = graph.expressions[node.children[1]];
            if (guard.combinator == "negLookahead" && guard.children.length == 1
                    && consumedByte.kind == ExpressionKind.terminal && consumedByte.source == "any") {
                auto excluded = graph.expressions[guard.children[0]];
                bool byteChoice = false;
                CharSetMask excludedMask;
                if (excluded.byteTerminal && excluded.nullable == Nullable.no && excluded.byteWidth == 1) {
                    byteChoice = true;
                    excludedMask = excluded.first;
                } else if (excluded.kind == ExpressionKind.choice && excluded.children.length) {
                    byteChoice = true;
                    foreach (child; excluded.children) {
                        auto branch = graph.expressions[child];
                        if (!branch.byteTerminal || branch.nullable != Nullable.no || branch
                                .byteWidth != 1) {
                            byteChoice = false;
                            break;
                        }
                        excludedMask = excludedMask | branch.first;
                    }
                }
                if (byteChoice) {
                    node.kind = ExpressionKind.terminal;
                    node.children = null;
                    node.arguments = null;
                    node.combinator = null;
                    node.byteTerminal = node.known = true;
                    node.byteWidth = 1;
                    node.nullable = Nullable.no;
                    foreach (i; 0 .. 4)
                        node.first.bits[i] = ~excludedMask.bits[i];
                    node.alphabet = node.first;
                    node.source = "charClass!(" ~ ulongHex(node.first.bits[0]) ~ ", " ~ ulongHex(
                            node.first.bits[1]) ~ ", " ~ ulongHex(node.first.bits[2]) ~ ", " ~ ulongHex(
                            node.first.bits[3]) ~ ")";
                }
            }
        }
        return graph.appendExpression(node);
    }

    private void prepareAnalysis() nothrow {
        analyzed = GrammarAnalysis.init;
        foreach (rule; rules)
            analyzed.names ~= rule.name;
        foreach (rule; rules)
            analyzed.roots ~= expressionNode(analyzed, rule.body);
        analyzed.solve();
        hasAnalysis = true;
    }

    FirstSetResult computeFirstSet(string expression) nothrow {
        if (!hasAnalysis)
            prepareAnalysis();
        const saved = analyzed.expressions.length;
        scope (exit)
            analyzed.truncate(saved);
        auto root = expressionNode(analyzed, expression);
        auto value = analyzed.appendFacts(root);
        return FirstSetResult(value.known && value.nullable != Nullable.unknown,
                value.nullable != Nullable.no, value.first);
    }

    static string[] splitTemplateArgs(string args) pure nothrow {
        string[] result;
        size_t depth, start;
        bool inQuote;
        for (size_t i; i < args.length; ++i) {
            const c = args[i];
            if (inQuote && c == '\\' && i + 1 < args.length) {
                ++i;
                continue;
            }
            if (c == '"')
                inQuote = !inQuote;
            else if (!inQuote) {
                if (c == '(')
                    ++depth;
                else if (c == ')' && depth)
                    --depth;
                else if (c == ',' && !depth) {
                    result ~= args[start .. i];
                    start = i + 1;
                }
            }
        }
        if (start < args.length)
            result ~= args[start .. $];
        return result;
    }

    private string dispatchChoice(string[] choices, FirstFacts[] values) nothrow {
        if (choices.length < 2 || choices.length > ubyte.max)
            return null;
        foreach (i, value; values)
            if (!value.known || value.nullable == Nullable.unknown || value.nullable == Nullable.yes
                    && i + 1 != values.length || value.first.empty && value.nullable != Nullable.yes)
                return null;
        foreach (i; 0 .. values.length)
            foreach (j; i + 1 .. values.length)
                if (values[i].first.intersects(values[j].first))
                    return null;
        string result = "predictiveChoice!(";
        foreach (i, choice; choices) {
            const mask = values[i].first;
            result ~= (i ? ", " : "") ~ "branch!(" ~ choice ~ ", " ~ ulongHex(
                    mask.bits[0]) ~ ", " ~ ulongHex(mask.bits[1]) ~ ", " ~ ulongHex(
                    mask.bits[2]) ~ ", " ~ ulongHex(mask.bits[3]) ~ (
                    values[i].nullable == Nullable.yes ? ", true" : "") ~ ")";
        }
        return result ~ ")";
    }

    string optimizeChoice(string[] choices) nothrow {
        if (!hasAnalysis)
            prepareAnalysis();
        auto query = analyzed;
        FirstFacts[] values;
        foreach (choice; choices) {
            auto root = expressionNode(query, choice);
            values ~= query.appendFacts(root);
        }
        return dispatchChoice(choices, values);
    }

    private string emitExpression(ref GrammarAnalysis graph, size_t index) nothrow {
        auto node = graph.expressions[index];
        if (!node.children.length)
            return node.source;
        string[] args;
        foreach (i, argument; node.arguments)
            args ~= i < node.children.length ? emitExpression(graph, node.children[i]) : argument;
        if (node.combinator == "or") {
            string[] factored;
            bool changed;
            for (size_t start; start < node.children.length;) {
                const first = node.children[start];
                auto branch = graph.expressions[first];
                const prefix = branch.combinator == "and" && branch.children.length ? branch.children[0] : first;
                size_t end = start + 1;
                if (graph.shareable(prefix)) {
                    while (end < node.children.length) {
                        const candidate = node.children[end];
                        auto other = graph.expressions[candidate];
                        const head = other.combinator == "and" && other.children.length ? other
                            .children[0] : candidate;
                        if (graph.expressions[head].source != graph.expressions[prefix].source)
                            break;
                        ++end;
                    }
                }
                if (end == start + 1) {
                    factored ~= args[start];
                } else {
                    string tails = "or!(";
                    foreach (i; start .. end) {
                        auto alternative = graph.expressions[node.children[i]];
                        string tail = "discard!(eps)";
                        if (alternative.combinator == "and" && alternative.children.length > 1) {
                            tail = "and!(";
                            foreach (j, child; alternative.children[1 .. $])
                                tail ~= (j ? ", " : "") ~ emitExpression(graph, child);
                            tail ~= ")";
                        }
                        tails ~= (i == start ? "" : ", ") ~ tail;
                    }
                    tails ~= ")";
                    factored ~= "and!(" ~ emitExpression(graph, prefix) ~ ", " ~ optimizeRule(tails) ~ ")";
                    changed = true;
                }
                start = end;
            }
            if (changed) {
                if (factored.length == 1)
                    return factored[0];
                string choice = "or!(";
                foreach (i, branch; factored)
                    choice ~= (i ? ", " : "") ~ branch;
                return optimizeRule(choice ~ ")");
            }
            FirstFacts[] values;
            foreach (child; node.children)
                values ~= graph.facts[child];
            auto predicted = dispatchChoice(args, values);
            if (predicted.length)
                return predicted;
        }
        string result = node.combinator ~ "!(";
        foreach (i, arg; args)
            result ~= (i ? ", " : "") ~ arg;
        return result ~ ")";
    }

    nothrow unittest {
        Frontend frontend;
        assert(frontend.optimizeRule(`or!(and!(literal!("a"), literal!("b")), and!(literal!("a"), literal!("c")))`) == `and!(literal!("a"), predictiveChoice!(branch!(and!(literal!("b")), 0x0UL, 0x400000000UL, 0x0UL, 0x0UL), branch!(and!(literal!("c")), 0x0UL, 0x800000000UL, 0x0UL, 0x0UL)))`);
        assert(startsWith(
                frontend.optimizeRule(`or!(and!(literal!("a"), literal!("b")), literal!("a"))`),
                `and!(literal!("a"), predictiveChoice!(`));
        const separated = `or!(and!(literal!("a"), literal!("b")), literal!("x"), literal!("a"))`;
        assert(frontend.optimizeRule(separated) == separated);
        const effectful = `or!(and!(external, literal!("b")), and!(external, literal!("c")))`;
        assert(frontend.optimizeRule(effectful) == effectful);
    }

    string optimizeRule(string expression) nothrow {
        if (!hasAnalysis)
            prepareAnalysis();
        const saved = analyzed.expressions.length;
        scope (exit)
            analyzed.truncate(saved);
        auto root = expressionNode(analyzed, expression);
        analyzed.appendFacts(root);
        return emitExpression(analyzed, root);
    }

    void configureRecords(alias Selector)() nothrow {
        static if (!is(Selector == void)) {
            static assert(__traits(compiles, { uint function(string) @nogc nothrow pure fn = &Selector; }),
                    "Compact selectors must be pure @nogc nothrow uint functions");
            foreach (rule; rules)
                recordKinds ~= Selector(name ~ "." ~ rule.name);
        }
    }

    /// Emit a small regular-expression graph; determinization happens in CTFE.
    private string regularTable(ref GrammarAnalysis graph, size_t root, out size_t references) nothrow {
        bool hasRecords;
        return regularTable(graph, root, references, hasRecords);
    }

    private string regularTable(ref GrammarAnalysis graph, size_t root, out size_t references, out bool hasRecords) nothrow {
        references = 0;
        hasRecords = false;
        GrammarAnalysis* regular = &graph;
        GrammarAnalysis stripped;
        bool requireEnd;
        auto rootNode = graph.expressions[root];
        if (rootNode.combinator == "and" && rootNode.children.length) {
            const last = graph.expressions[rootNode.children[$ - 1]].source;
            if (last == "eoi" || last == "endOfInput") {
                Expression strippedNode = rootNode;
                strippedNode.children = rootNode.children[0 .. $ - 1].dup;
                root = graph.appendExpression(strippedNode);
                graph.appendFacts(root);
                requireEnd = true;
            }
        }
        if (!regular.regularLeaf(root, requireEnd))
            return null;
        RegularExpression[] nodes;
        size_t lower(size_t index, size_t depth = 0) {
            auto expression = regular.expressions[index];
            if (expression.kind == ExpressionKind.reference) {
                const targetRule = graph.referenceRule(expression);
                if (recordKinds.length == 0)
                    hasRecords = true;
                else if (targetRule < recordKinds.length && (recordKinds[targetRule] != uint.max
                        || (targetRule < recordSubtrees.length && recordSubtrees[targetRule])))
                    hasRecords = true;
                if (depth + 1 > references)
                    references = depth + 1;
                return lower(graph.roots[targetRule], depth + 1);
            }
            const escaped = regular.escapeLoop(index);
            if (escaped.known) {
                size_t prefix;
                if (escaped.doubled) {
                    prefix = nodes.length;
                    nodes ~= RegularExpression(RegularKind.bytes, regular.expressions[escaped.prefix]
                            .first);
                } else
                    prefix = lower(escaped.prefix, depth);
                const any = nodes.length;
                nodes ~= RegularExpression(RegularKind.bytes, escaped.doubled
                        ? regular.expressions[escaped.prefix].first
                        : CharSetMask([ulong.max, ulong.max, ulong.max, ulong.max]));
                const pair = nodes.length;
                nodes ~= RegularExpression(RegularKind.sequence, CharSetMask.init, [prefix, any]);
                CharSetMask ordinary, fallback;
                foreach (i; 0 .. 4) {
                    const first = regular.expressions[escaped.prefix].first.bits[i];
                    const bytes = regular.expressions[escaped.ordinary].first.bits[i];
                    ordinary.bits[i] = bytes & ~first;
                    fallback.bits[i] = bytes & first;
                }
                const ordinaryByte = nodes.length;
                nodes ~= RegularExpression(RegularKind.bytes, ordinary);
                size_t[] alternatives = [pair, ordinaryByte];
                if (!fallback.empty) {
                    const lastByte = nodes.length;
                    nodes ~= RegularExpression(RegularKind.bytes, fallback);
                    const end = nodes.length;
                    nodes ~= RegularExpression(RegularKind.endOfInput);
                    const last = nodes.length;
                    nodes ~= RegularExpression(RegularKind.sequence, CharSetMask.init, [
                        lastByte, end
                    ]);
                    alternatives ~= last;
                }
                const choice = nodes.length;
                nodes ~= RegularExpression(RegularKind.choice, CharSetMask.init, alternatives);
                const repeated = nodes.length;
                nodes ~= RegularExpression(RegularKind.repetition, CharSetMask.init, [choice]);
                if (expression.combinator == "oneOrMore") {
                    nodes ~= RegularExpression(RegularKind.sequence, CharSetMask.init, [
                        choice, repeated
                    ]);
                    return nodes.length - 1;
                }
                return repeated;
            }
            RegularExpression node;
            if (expression.kind == ExpressionKind.terminal) {
                if (startsWith(expression.source, "literal!")) {
                    node.kind = RegularKind.sequence;
                    foreach (c; decodedLiteral(expression.source)) {
                        CharSetMask mask;
                        mask.addChar(c);
                        node.children ~= nodes.length;
                        nodes ~= RegularExpression(RegularKind.bytes, mask);
                    }
                } else if (expression.source == "eps")
                    node.kind = RegularKind.sequence;
                else {
                    node.kind = RegularKind.bytes;
                    node.bytes = expression.first;
                }
            } else {
                foreach (child; expression.children)
                    node.children ~= lower(child, depth);
                if (expression.combinator == "or" || expression.combinator == "predictiveChoice")
                    node.kind = RegularKind.choice;
                else if (expression.combinator == "option")
                    node.kind = RegularKind.optional;
                else if (expression.combinator == "zeroOrMore")
                    node.kind = RegularKind.repetition;
                else if (expression.combinator == "oneOrMore") {
                    const child = node.children[0];
                    const repeated = nodes.length;
                    nodes ~= RegularExpression(RegularKind.repetition, CharSetMask.init, [child]);
                    node.children = [child, repeated];
                    node.kind = RegularKind.sequence;
                } else
                    node.kind = RegularKind.sequence;
            }
            nodes ~= node;
            return nodes.length - 1;
        }

        const index = lower(root);
        bool repeated;
        foreach (node; nodes)
            repeated = repeated || node.kind == RegularKind.repetition;
        // Fixed terminals already use inlined literal/byte matching. A state
        // machine is useful here when it replaces a character-processing loop.
        if (!repeated)
            return null;
        string source = "compileDFA([\n";
        foreach (i, node; nodes) {
            if (node.kind == RegularKind.bytes) {
                source ~= "regularByte(";
                foreach (j, bits; node.bytes.bits)
                    source ~= (j ? ", " : "") ~ ulongHex(bits);
                source ~= ")";
            } else {
                const kind = ["bytes", "sequence", "choice", "optional", "repetition", "endOfInput"][node
                        .kind];
                source ~= "regularNode(RegularKind." ~ kind ~ ", [";
                foreach (j, child; node.children)
                    source ~= (j ? ", " : "") ~ number(child);
                source ~= "])";
            }
            source ~= ", // node " ~ number(i) ~ "\n";
        }
        return source ~ "], " ~ number(index) ~ ", " ~ (requireEnd ? "true" : "false") ~ ")";
    }

    nothrow unittest {
        Frontend frontend;
        frontend.input = `Regular: Token <- [0-9]+ Unsafe <- 'a'* 'a'
            Class <- '[' '^'? ('\\' . / (!']' .))* ']'
            PlainEscapes <- ('\\' . / 'a')*`;
        frontend.read();
        frontend.prepareAnalysis();
        size_t references;
        assert(startsWith(frontend.regularTable(frontend.analyzed, frontend.analyzed.roots[0],
                references), "compileDFA(["));
        assert(frontend.regularTable(frontend.analyzed, frontend.analyzed.roots[1], references) is null);
        assert(frontend.regularTable(frontend.analyzed, frontend.analyzed.roots[2], references)
                .length);
        assert(frontend.regularTable(frontend.analyzed, frontend.analyzed.roots[3], references)
                .length);
        assert(frontend.emit().length);
    }

    /// Compile maximal eligible regions even when their enclosing rule is not regular.
    private string emitTokens(ref GrammarAnalysis graph, size_t index, string rule, ref size_t count,
            ref string declarations) nothrow {
        auto node = graph.expressions[index];
        if (node.combinator == "negLookahead" && node.children.length == 1 && !graph.conservative) {
            auto facts = graph.facts[node.children[0]];
            if (facts.known && (facts.nullable == Nullable.no || facts.eofOnly)) {
                string result = "predictiveNot!(" ~ emitTokens(graph, node.children[0], rule, count, declarations);
                foreach (bits; facts.first.bits)
                    result ~= ", " ~ ulongHex(bits);
                return result ~ ")";
            }
        }
        if (node.children.length && node.kind != ExpressionKind.reference && node.combinator != "branch") {
            size_t referenceDepth;
            bool hasRecords;
            const table = regularTable(graph, index, referenceDepth, hasRecords);
            if (table.length) {
                const symbol = "_dfa_" ~ rule ~ (count ? "_" ~ number(count) : "");
                ++count;
                declarations ~= "struct " ~ symbol ~ " { enum automaton = " ~ table
                    ~ "; enum valid = automaton.valid; enum requireEnd = automaton.requireEnd; }\n";
                return "dfaToken!(" ~ emitExpression(graph,
                        index) ~ ", " ~ symbol ~ ", " ~ number(referenceDepth) ~ ", " ~ (hasRecords
                        ? "true" : "false") ~ ")";
            }
        }
        // Merge adjacent regular children before falling back to nonregular syntax.
        // A trailing comment/recursive rule must not split a lexical header into
        // several separate scanners. Each region independently proves PEG equivalence.
        if (node.combinator == "and" && node.children.length > 2) {
            string[] regions;
            for (size_t start; start < node.children.length;) {
                size_t selected = start + 1;
                string selectedTable;
                size_t selectedDepth;
                bool selectedRecords;
                foreach (end; start + 2 .. node.children.length + 1) {
                    if (end - start > 64)
                        break;
                    if (end == start + 2 && (!closedEmpty(graph, node.children[start])
                            || !graph.regularLeaf(node.children[start])))
                        break;
                    if (!closedEmpty(graph, node.children[end - 1]) || !graph.regularLeaf(node
                            .children[end - 1]))
                        break;
                    Expression region;
                    region.kind = ExpressionKind.sequence;
                    region.combinator = "and";
                    region.children = node.children[start .. end].dup;
                    region.source = "and!(";
                    foreach (i, child; region.children) {
                        const text = graph.expressions[child].source;
                        region.arguments ~= text;
                        region.source ~= (i ? ", " : "") ~ text;
                    }
                    region.source ~= ")";
                    const savedRegion = graph.expressions.length;
                    const root = graph.appendExpression(region);
                    graph.appendFacts(root);
                    size_t referenceDepth;
                    bool hasRecords;
                    const table = regularTable(graph, root, referenceDepth, hasRecords);
                    graph.truncate(savedRegion);
                    // Closed terminal regions have identical scanning policies in
                    // recognition and record modes; named calls retain rule budgets.
                    if (!table.length || referenceDepth || hasRecords)
                        break;
                    selected = end;
                    selectedTable = table;
                    selectedDepth = referenceDepth;
                    selectedRecords = hasRecords;
                }
                if (selected == start + 1) {
                    regions ~= emitTokens(graph, node.children[start], rule, count, declarations);
                } else {
                    const symbol = "_dfa_" ~ rule ~ (count ? "_" ~ number(count) : "");
                    ++count;
                    declarations ~= "struct " ~ symbol ~ " { enum automaton = " ~ selectedTable ~ "; enum valid = automaton.valid; enum requireEnd = automaton.requireEnd; }\n";
                    string original = "and!(";
                    foreach (i, child; node.children[start .. selected])
                        original ~= (i ? ", " : "") ~ emitExpression(graph, child);
                    regions ~= "dfaToken!(" ~ original ~ "), " ~ symbol ~ ", " ~ number(
                            selectedDepth) ~ ", " ~ (selectedRecords ? "true" : "false") ~ ")";
                }
                start = selected;
            }
            string result = "and!(";
            foreach (i, region; regions)
                result ~= (i ? ", " : "") ~ region;
            return result ~ ")";
        }
        if (!node.children.length)
            return node.source;
        string result = node.combinator ~ "!(";
        foreach (i, argument; node.arguments)
            result ~= (i ? ", " : "") ~ (i < node.children.length ? emitTokens(graph,
                    node.children[i], rule, count, declarations) : argument);
        return result ~ ")";
    }

    nothrow unittest {
        Frontend frontend;
        frontend.input = "Partial: Token <- 'a'* 'a'";
        frontend.read();
        frontend.prepareAnalysis();
        size_t count;
        string declarations;
        const string body = frontend.emitTokens(frontend.analyzed, frontend.analyzed.roots[0],
                "Token", count, declarations);
        assert(count == 1 && startsWith(body, "and!(dfaToken!("));
        assert(startsWith(declarations, "struct _dfa_Token { enum automaton = compileDFA(["));
    }

    /// Empty fast paths only compile closed expressions; opaque calls stay untouched.
    private bool closedEmpty(ref GrammarAnalysis graph, size_t index, size_t depth = 0) nothrow {
        auto node = graph.expressions[index];
        if (depth >= 64 || node.kind == ExpressionKind.reference || node.kind == ExpressionKind
                .unknown)
            return false;
        foreach (child; node.children)
            if (!closedEmpty(graph, child, depth + 1))
                return false;
        return true;
    }

    nothrow unittest {
        Frontend frontend;
        GrammarAnalysis graph;
        auto root = frontend.expressionNode(graph, "zeroOrMore!(literal!(\"a\"))");
        assert(frontend.closedEmpty(graph, root));
        assert(!frontend.closedEmpty(graph, root, 64));
        root = frontend.expressionNode(graph, "and!(literal!(\"a\"), externalParser)");
        assert(!frontend.closedEmpty(graph, root));
    }

    /// 0: unknown/possibly consumes, 1: zero-width success, 2: zero-width failure.
    /// Reachable predicates are deliberately unknown; they may inspect a suffix.
    private int zeroMatch(ref GrammarAnalysis graph, size_t index, int byteValue, size_t depth = 0) nothrow {
        if (depth >= 64)
            return 0;
        auto node = graph.expressions[index];
        const op = node.combinator;
        if (op == "and") {
            foreach (child; node.children) {
                const result = zeroMatch(graph, child, byteValue, depth + 1);
                if (result != 1)
                    return result;
            }
            return 1;
        }
        if (op == "or") {
            foreach (child; node.children) {
                const result = zeroMatch(graph, child, byteValue, depth + 1);
                if (result != 2)
                    return result;
            }
            return 2;
        }
        if (op == "predictiveChoice") {
            if (!node.children.length)
                return 2;
            foreach (branch; node.children)
                if (byteValue < 256 && graph.facts[branch].first.contains(cast(ubyte)byteValue))
                    return 0;
            const last = node.children[$ - 1];
            return graph.facts[last].nullable == Nullable.yes ? zeroMatch(graph, last, byteValue, depth + 1) : 2;
        }
        if (op == "zeroOrMore" || op == "option" || op == "oneOrMore") {
            const result = zeroMatch(graph, node.children[0], byteValue, depth + 1);
            return result == 2 && op != "oneOrMore" ? 1 : result;
        }
        if (op == "discard" || op == "fuse" || op == "keep" || op == "drop" || op == "propagate"
                || op == "named" || op == "defined" || op == "dfaToken" || op == "branch")
            return zeroMatch(graph, node.children[0], byteValue, depth + 1);
        if (node.kind != ExpressionKind.terminal)
            return 0;
        if (node.source == "eps" || startsWith(node.source, "literal!(") && node.byteWidth == 0)
            return 1;
        if (node.source == "eoi" || node.source == "endOfInput")
            return byteValue == 256 ? 1 : 2;
        if (node.source == "fail")
            return 2;
        if (node.byteTerminal && (byteValue == 256 || !node.first.contains(cast(ubyte)byteValue)))
            return 2;
        return 0;
    }

    nothrow unittest {
        Frontend frontend;
        GrammarAnalysis graph;
        foreach (source; [
            "and!(zeroOrMore!(literal!(\"a\")), option!(literal!(\"b\")))",
            "or!(literal!(\"a\"), eps)", "oneOrMore!(eps)",
            "fuse!(zeroOrMore!(literal!(\"a\")))", "discard!(eps)", "keep!(eps)",
            "drop!(eps)", "propagate!(eps)", "named!(eps, \"x\")", "defined!(eps, \"x\")",
        ]) {
            const root = frontend.expressionNode(graph, source);
            graph.appendFacts(root);
            assert(frontend.zeroMatch(graph, root, 'x') == 1);
        }
        foreach (source; [
            "and!(literal!(\"a\"), eps)", "or!(literal!(\"a\"), literal!(\"b\"))",
            "oneOrMore!(literal!(\"a\"))", "fail", "eoi"
        ]) {
            const root = frontend.expressionNode(graph, source);
            graph.appendFacts(root);
            assert(frontend.zeroMatch(graph, root, 'x') == 2);
        }
        const literalRoot = frontend.expressionNode(graph, "literal!(\"x\")");
        assert(frontend.zeroMatch(graph, literalRoot, 'x') == 0);
        assert(frontend.zeroMatch(graph, literalRoot, 'x', 64) == 0);
        const end = frontend.expressionNode(graph, "eoi");
        assert(frontend.zeroMatch(graph, end, 256) == 1);
        const endInput = frontend.expressionNode(graph, "endOfInput");
        assert(frontend.zeroMatch(graph, endInput, 256) == 1);
        assert(frontend.zeroMatch(graph, endInput, 'x') == 2);
        const emptyLit = frontend.expressionNode(graph, "literal!(\"\")");
        assert(frontend.zeroMatch(graph, emptyLit, 'x') == 1);
        const dfaNode = frontend.expressionNode(graph, "dfaToken!(eps, _dfa, 0, false)");
        assert(frontend.zeroMatch(graph, dfaNode, 'x') == 1);
        const branchNode = frontend.expressionNode(graph, "branch!(eps, 0UL, 0UL, 0UL, 0UL, true)");
        assert(frontend.zeroMatch(graph, branchNode, 'x') == 1);
        const predChoice = frontend.expressionNode(graph, "predictiveChoice!(branch!(literal!(\"a\"), 0UL, 0x2UL, 0UL, 0UL, false), branch!(eps, 0UL, 0UL, 0UL, 0UL, true))");
        graph.appendFacts(predChoice);
        assert(frontend.zeroMatch(graph, predChoice, 'a') == 0);
        assert(frontend.zeroMatch(graph, predChoice, 'z') == 1);
        const predFail = frontend.expressionNode(graph, "predictiveChoice!(branch!(literal!(\"a\"), 0UL, 0x2UL, 0UL, 0UL, false), branch!(literal!(\"b\"), 0UL, 0x4UL, 0UL, 0UL, false))");
        graph.appendFacts(predFail);
        assert(frontend.zeroMatch(graph, predFail, 'z') == 2);
        const suffix = frontend.expressionNode(graph, "option!(negLookahead!(literal!(\"xy\")))");
        assert(frontend.zeroMatch(graph, suffix, 'x') == 0);
    }

    /// Probe the existing optimized expression at CTFE, then batch only proven
    /// zero-width paths. One spare work unit keeps DFA speculation off its budget edge.
    private string emitEmpty(ref GrammarAnalysis graph, size_t root, string rule, out string guard,
            int outputMode, string position = "p", string complete = "return true;") nothrow {
        guard = null;
        auto facts = graph.facts[root];
        if (!facts.known || facts.nullable != Nullable.yes
                || graph.expressions[root].source.length > 16384 || !closedEmpty(graph, root))
            return null;
        int outside;
        while (outside < 256 && facts.first.contains(cast(ubyte)outside))
            ++outside;
        const ordinary = outside < 256 && zeroMatch(graph, root, outside) == 1;
        const atEnd = zeroMatch(graph, root, 256) == 1;
        if (!ordinary && !atEnd)
            return null;
        const type = "_Empty_" ~ rule ~ "_" ~ number(outputMode);
        string declarations = "private struct " ~ type ~ " { size_t cost; bool diagnostic, valid; }\n";
        foreach (eof; [false, true]) {
            const symbol = "_empty_" ~ rule ~ "_" ~ number(outputMode) ~ (eof ? "_eof" : "_byte");
            const eligible = eof ? atEnd : ordinary;
            declarations ~= "private enum " ~ symbol ~ " = ";
            if (!eligible)
                declarations ~= type ~ ".init;\n";
            else {
                declarations ~= "() { State!(true, " ~ number(outputMode) ~ ") state; " ~ (outputMode == 2 ? "import npegged.records : RecordBuffer; Arena owner; state.arena = &owner; RecordBuffer output; output.arena = &owner; state.attachRecords(output); " : "") ~ "state.context.stepLimit = 65536; state.input = " ~ quoted(
                        eof ? "" : [cast(char)outside].idup) ~ "; auto matched = " ~ graph
                    .expressions[root].source ~ "(state, 0); auto failure = state.checkpointFailure(); return " ~ type ~ "(state.steps, failure.present, state.status == Status.ok && matched.successful" ~ " && matched.end == 0 && matched.failEnd == 0 && (!failure.present || failure.failEnd == 0)); }();\n";
            }
            guard ~= "static if (" ~ symbol ~ ".valid && " ~ symbol
                ~ ".cost >= 3) { if (s.status == Status.ok" ~ " && s.context.trace is null && "
                ~ position ~ " " ~ (eof ? "==" : "<") ~ " s.input.length";
            if (!eof)
                guard ~= " && !CharSetMask([" ~ ulongHex(facts.first.bits[0]) ~ ", " ~ ulongHex(
                        facts.first.bits[1]) ~ ", " ~ ulongHex(facts.first.bits[2]) ~ ", " ~ ulongHex(
                        facts.first.bits[3]) ~ "]).contains(cast(ubyte)s.input[" ~ position ~ "])";
            guard ~= " && s.steps < s.context.stepLimit && s.context.stepLimit - s.steps > "
                ~ symbol ~ ".cost) { s.steps += " ~ symbol ~ ".cost; static if (" ~ symbol
                ~ ".diagnostic) s.recordFailure(s.node("
                ~ position ~ ", " ~ position ~ ", false)); " ~ complete ~ " } }\n";
        }
        return declarations;
    }

    nothrow unittest {
        Frontend frontend;
        GrammarAnalysis graph;
        string guard;
        const empty = frontend.expressionNode(graph, "and!(zeroOrMore!(literal!(\" \")), zeroOrMore!(and!(literal!(\"#\"), zeroOrMore!(any))))");
        graph.appendFacts(empty);
        auto source = frontend.emitEmpty(graph, empty, "Probe", guard, 2);
        assert(startsWith(source, "private struct _Empty_Probe_2"));
        assert(guard.length);
        const any = frontend.expressionNode(graph, "option!(any)");
        graph.appendFacts(any);
        assert(frontend.emitEmpty(graph, any, "ProbeAny", guard, 1).length);
        const predicate = frontend.expressionNode(graph, "option!(negLookahead!(literal!(\"xy\")))");
        graph.appendFacts(predicate);
        assert(frontend.emitEmpty(graph, predicate, "ProbeSuffix", guard, 1) is null && guard is null);
        const required = frontend.expressionNode(graph, "literal!(\"x\")");
        graph.appendFacts(required);
        assert(frontend.emitEmpty(graph, required, "Required", guard, 1) is null);
        char[16384] large;
        large[] = 'a';
        const oversized = frontend.expressionNode(graph, "zeroOrMore!(literal!(" ~ quoted(cast(string)large[]) ~ "))");
        graph.appendFacts(oversized);
        assert(frontend.emitEmpty(graph, oversized, "Large", guard, 1) is null);
    }

    /// Lower rule-local recognition control flow without intermediate aggregate results.
    /// Terminals, scanners, predicates and unsupported operators retain their contracts.
    private string emitDirect(ref GrammarAnalysis graph, size_t index, string start, string target,
            ref size_t serial, size_t depth = 0, int outputMode = 1) nothrow {
        auto expression = graph.expressions[index];
        const position = "_p" ~ number(serial++);
        string code = "size_t " ~ target ~ "End = " ~ start ~ ", " ~ target ~ "Fail = " ~ start
            ~ "; bool "
            ~ target ~ "Ok = s.status == Status.ok; { const size_t " ~ position ~ " = " ~ start ~ ";\n";
        const op = expression.combinator;
        const checkpoint = "_checkpoint" ~ number(serial++);
        if (outputMode == 2 && (op == "or" || op == "predictiveChoice"))
            code ~= "const size_t " ~ checkpoint ~ " = s.outputCheckpoint();\n";
        code ~= "do {\n";
        // Bound rule-local expansion, including duplicated nullable fallback arms.
        const lower = depth < 64 && serial < 2048;
        if (lower && index < graph.facts.length && (op == "and" || op == "or" || op == "predictiveChoice"
                || op == "zeroOrMore" || op == "oneOrMore" || op == "option")) {
            bool cheap;
            if ((op == "zeroOrMore" || op == "oneOrMore" || op == "option") && expression.children
                    .length) {
                auto child = graph.expressions[expression.children[0]];
                cheap = child.kind == ExpressionKind.terminal && !child.children.length
                    && child.source != "space" && child.source != "blank";
            }
            if (!cheap) {
                string guard;
                const complete = target ~ "End = " ~ position ~ "; " ~ target ~ "Fail = " ~ position
                    ~ "; " ~ target ~ "Ok = true; break;";
                directDeclarations ~= emitEmpty(graph, index, directRule ~ position, guard,
                        outputMode, position, complete);
                code ~= guard;
            }
        }
        const reference = expression.kind == ExpressionKind.reference ? graph.referenceRule(expression) : size_t
            .max;
        if (reference < scalarRules.length && scalarRules[reference]) {
            string entry = "recognizeRule";
            string tag = ", false";
            if (outputMode == 2) {
                entry = "recognizeRecordedRule";
                tag = ", -1L";
                if (recordKinds.length) {
                    if (recordKinds[reference] != uint.max)
                        tag = ", " ~ number(cast(ulong)recordKinds[reference] | (
                                recordLeaves[reference] ? 1UL << 32 : 0UL)) ~ "L";
                    else
                        tag = recordSubtrees[reference] ? ", -2L" : ", -3L";
                }
            }
            code ~= target ~ "Ok = s." ~ entry ~ "!(_cursor_" ~ expression.reference ~ ", " ~ quoted(
                    name ~ "." ~ expression.reference) ~ tag ~ ")(" ~ target ~ "End, " ~ target ~ "Fail);\n";
        } else if (outputMode == 2 && op == "dfaToken" && expression.arguments.length == 4) {
            string innerRecords = expression.arguments[3];
            while (innerRecords.length && (innerRecords[0] == ' ' || innerRecords[0] == '\t'))
                innerRecords = innerRecords[1 .. $];
            const next = "_d" ~ number(serial++);
            if (innerRecords == "true")
                code ~= emitDirect(graph, expression.children[0], position, next, serial, depth + 1, outputMode);
            else
                code ~= "auto " ~ next ~ " = " ~ expression.source ~ "(s, " ~ position ~ ");\n";
            if (innerRecords == "true")
                code ~= target ~ "End = " ~ next ~ "End; " ~ target ~ "Fail = " ~ next ~ "Fail; " ~ target
                    ~ "Ok = " ~ next ~ "Ok;\n";
            else
                code ~= target ~ "End = " ~ next ~ ".end; " ~ target ~ "Fail = " ~ next ~ ".failEnd; "
                    ~ target ~ "Ok = " ~ next ~ ".successful;\n";
        } else if (lower && (op == "discard" || op == "fuse" || op == "keep" || op == "drop"
                || op == "propagate" || op == "named" || op == "defined")) {
            const next = "_d" ~ number(serial++);
            const scanner = op == "discard" || op == "fuse";
            if (scanner)
                code ~= "static if (!__traits(hasMember, "
                    ~ graph.expressions[expression.children[0]].source ~ ", \"scan\")) {\n";
            code ~= emitDirect(graph, expression.children[0], position, next, serial, depth + 1, outputMode);
            code ~= target ~ "End = " ~ next ~ "End; " ~ target ~ "Fail = " ~ next ~ "Fail; " ~ target
                ~ "Ok = " ~ next ~ "Ok;\n";
            if (scanner) {
                const scanned = "_scanned" ~ number(serial++);
                code ~= "} else { auto " ~ scanned ~ " = " ~ expression.source ~ "(s, " ~ position
                    ~ "); " ~ target
                    ~ "End = " ~ scanned ~ ".end; " ~ target ~ "Fail = " ~ scanned ~ ".failEnd; "
                    ~ target ~ "Ok = " ~ scanned ~ ".successful; }\n";
            }
        } else if (lower && op == "and") {
            foreach (child; expression.children) {
                const next = "_d" ~ number(serial++);
                code ~= "if (!s.tick()) { " ~ target ~ "End = " ~ position ~ "; " ~ target ~ "Fail = "
                    ~ position ~ "; " ~ target ~ "Ok = false; break; }\n";
                code ~= emitDirect(graph, child, target ~ "End", next, serial, depth + 1, outputMode);
                code ~= "if (!" ~ next ~ "Ok) { " ~ target ~ "Ok = false; " ~ target ~ "Fail = " ~ next
                    ~ "Fail; break; } " ~ target ~ "End = " ~ next ~ "End;\n";
            }
        } else if (lower && (op == "posLookahead" || op == "negLookahead" || op == "predictiveNot")) {
            const next = "_d" ~ number(serial++);
            const saved = "_probe" ~ number(serial++);
            const nested = "_nested" ~ number(serial++);
            const failure = "_failure" ~ number(serial++);
            if (op == "predictiveNot") {
                const probe = "_not" ~ number(serial++);
                code ~= "alias " ~ probe ~ " = " ~ expression.source
                    ~ "; if (s.context.trace is null && " ~ position ~ " < s.input.length && !" ~ probe
                    ~ ".mask.contains(cast(ubyte)s.input["
                    ~ position ~ "])) { " ~ target ~ "Ok = s.tick(); break; }\n";
            }
            code ~= "const " ~ saved ~ " = s.beginProbe();\n" ~ emitDirect(graph,
                    expression.children[0],
                    position, next, serial, depth + 1, outputMode) ~ "const " ~ nested
                ~ " = s.finishProbe(" ~ saved ~ ");\n" ~ target ~ "Ok = (" ~ next ~ "Ok == " ~ (
                        op == "posLookahead"
                        ? "true" : "false") ~ ") && s.status == Status.ok; if (!" ~ target ~ "Ok) {\n";
            if (op == "posLookahead")
                code ~= target ~ "Fail = " ~ next ~ "Fail; auto " ~ failure ~ " = s.node(" ~ position
                    ~ ", " ~ position ~ ", false); "
                    ~ failure ~ ".failEnd = " ~ nested ~ ".present ? " ~ nested ~ ".failEnd : " ~ next
                    ~ "Fail; s.recordFailure(" ~ failure ~ ");\n";
            else
                code ~= "s.failure(" ~ position ~ ", \"negative lookahead\");\n";
            code ~= "}\n";
        } else if (lower && op == "predictiveChoice") {
            const dispatch = "_choice" ~ number(serial++);
            code ~= "if (!s.tick()) { " ~ target ~ "Ok = false; break; }\n" ~ "alias " ~ dispatch
                ~ " = " ~ expression.source ~ ";\n" ~ "const ubyte " ~ dispatch ~ "Selected = " ~ position
                ~ " < s.input.length ? " ~ dispatch ~ ".branchTable[cast(ubyte)s.input[" ~ position
                ~ "]] : cast(ubyte)" ~ dispatch ~ ".fallback; switch (" ~ dispatch ~ "Selected) {\n";
            foreach (i, branch; expression.children) {
                const next = "_d" ~ number(serial++);
                code ~= "case " ~ number(i + 1) ~ ": {\n";
                code ~= emitDirect(graph, graph.expressions[branch].children[0], position, next,
                        serial, depth + 1, outputMode);
                code ~= target ~ "End = " ~ next ~ "End; " ~ target ~ "Fail = " ~ next ~ "Fail; " ~ target
                    ~ "Ok = " ~ next ~ "Ok;\n";
                const last = expression.children[$ - 1];
                const args = graph.expressions[last].arguments;
                string nullableArgument = args.length == 6 ? args[5] : null;
                while (nullableArgument.length && (nullableArgument[0] == ' ' || nullableArgument[0] == '\t'))
                    nullableArgument = nullableArgument[1 .. $];
                if (i + 1 != expression.children.length && nullableArgument == "true") {
                    const fallback = "_d" ~ number(serial++);
                    code ~= "if (!" ~ next ~ "Ok && s.status == Status.ok) {\n" ~ (outputMode == 2
                            ? "s.rollbackOutput(" ~ checkpoint ~ ");\n" : "") ~ emitDirect(graph,
                            graph.expressions[last].children[0], position, fallback, serial, depth + 1,
                            outputMode) ~ target ~ "End = " ~ fallback ~ "End; " ~ target ~ "Fail = "
                        ~ fallback ~ "Fail; " ~ target ~ "Ok = " ~ fallback ~ "Ok; }\n";
                }
                code ~= "break; }\n";
            }
            code ~= "default: { auto failed = s.failure(" ~ position ~ ", \"choice\"); " ~ target
                ~ "End = failed.end; "
                ~ target ~ "Fail = failed.failEnd; " ~ target ~ "Ok = failed.successful; break; } }\n";
        } else if (lower && op == "or") {
            code ~= target ~ "Ok = false;\n";
            foreach (child; expression.children) {
                if (outputMode == 2)
                    code ~= "s.rollbackOutput(" ~ checkpoint ~ ");\n";
                const next = "_d" ~ number(serial++);
                code ~= emitDirect(graph, child, position, next, serial, depth + 1, outputMode);
                code ~= "if (" ~ next ~ "Ok || " ~ next ~ "Fail >= " ~ target ~ "Fail) { " ~ target
                    ~ "End = " ~ next ~ "End; " ~ target ~ "Fail = " ~ next ~ "Fail; " ~ target ~ "Ok = "
                    ~ next ~ "Ok; } if (" ~ next ~ "Ok) break;\n";
            }
        } else if (lower && (op == "zeroOrMore" || op == "oneOrMore" || op == "option")) {
            const next = "_d" ~ number(serial++);
            const count = "_count" ~ number(serial++);
            code ~= "size_t " ~ count ~ " = 0; while (" ~ (op == "option" ? count ~ " < 1 && " : "") ~ "s.tick()) {\n";
            if (outputMode == 2)
                code ~= "const size_t " ~ checkpoint ~ " = s.outputCheckpoint();\n";
            code ~= emitDirect(graph, expression.children[0], target ~ "End", next, serial, depth + 1,
                    outputMode);
            code ~= "if (!" ~ next ~ "Ok) {\n";
            if (outputMode == 2)
                code ~= "s.rollbackOutput(" ~ checkpoint ~ ");\n";
            if (op == "oneOrMore")
                code ~= "if (!" ~ count ~ ") { " ~ target ~ "End = " ~ next ~ "End; " ~ target ~ "Fail = "
                    ~ next ~ "Fail; " ~ target ~ "Ok = false; }\n";
            code ~= "break; } ++" ~ count ~ "; if (" ~ next ~ "End == " ~ target ~ "End) break; "
                ~ target ~ "End = " ~ next ~ "End; }\n";
            code ~= "if (s.status != Status.ok" ~ (op == "oneOrMore" ? " || !" ~ count : "") ~ ") "
                ~ target ~ "Ok = false;\n";
        } else if (startsWith(expression.source, "literal!(")) {
            const text = decodedLiteral(expression.source);
            code ~= "if (!s.tick()) { " ~ target ~ "Ok = false; break; }\n";
            if (text.length) {
                const bytes = "_literal" ~ number(serial++);
                const matched = "_matched" ~ number(serial++);
                code ~= "enum " ~ bytes ~ " = " ~ quoted(text) ~ ";\n" ~ "if (" ~ position
                    ~ " <= s.input.length && " ~ bytes ~ ".length <= s.input.length - "
                    ~ position ~ " && s.input[" ~ position ~ " .. " ~ position ~ " + " ~ bytes
                    ~ ".length] == " ~ bytes
                    ~ ") { " ~ target ~ "End += " ~ bytes ~ ".length; " ~ target ~ "Fail = " ~ target
                    ~ "End; } else { size_t "
                    ~ matched ~ "; while (" ~ matched ~ " < " ~ bytes ~ ".length && " ~ position ~ " + "
                    ~ matched ~ " < s.input.length && s.input["
                    ~ position ~ " + " ~ matched ~ "] == " ~ bytes ~ "[" ~ matched ~ "]) ++" ~ matched
                    ~ "; " ~ target ~ "Ok = false; "
                    ~ target ~ "Fail += " ~ matched ~ "; s.recordFailure(s.node(" ~ position ~ ", "
                    ~ target ~ "Fail, false)); }\n";
            }
        } else if (expression.byteTerminal && expression.byteWidth == 1
                && (expression.source == "any"
                    || expression.source == "digit" || expression.source == "alpha"
                    || expression.source == "Alpha" || expression.source == "hexDigit"
                    || startsWith(expression.source, "charClass!(") || startsWith(expression.source, "charRange!("))) {
            const mask = "_mask" ~ number(serial++);
            code ~= "enum ulong[4] " ~ mask ~ " = [" ~ ulongHex(
                    expression.alphabet.bits[0]) ~ ", " ~ ulongHex(expression.alphabet.bits[1])
                ~ ", " ~ ulongHex(expression.alphabet.bits[2]) ~ ", " ~ ulongHex(
                        expression.alphabet.bits[3])
                ~ "]; if (!s.tick() || " ~ position ~ " >= s.input.length || (" ~ mask
                ~ "[cast(ubyte)s.input[" ~ position ~ "] >> 6] & (1UL << (cast(ubyte)s.input["
                ~ position ~ "] & 63))) == 0) { " ~ target ~ "Ok = false; s.recordFailure(s.node("
                ~ position ~ ", " ~ position ~ ", false)); } else { ++" ~ target ~ "End; " ~ target
                ~ "Fail = " ~ target ~ "End; }\n";
        } else if (expression.source == "eps") {
            // Empty success neither consumes input nor charges a work unit.
        } else if (expression.source == "eoi" || expression.source == "endOfInput" || expression
                .source == "fail") {
            code ~= "if (" ~ (expression.source == "fail"
                    ? "true" : position ~ " != s.input.length") ~ ") { " ~ target
                ~ "Ok = false; s.recordFailure(s.node(" ~ position ~ ", " ~ position ~ ", false)); }\n";
        } else {
            const next = "_node" ~ number(serial++);
            code ~= "auto " ~ next ~ " = " ~ expression.source ~ "(s, " ~ position ~ "); " ~ target
                ~ "End = " ~ next ~ ".end; " ~ target ~ "Fail = " ~ next ~ ".failEnd; " ~ target ~ "Ok = "
                ~ next ~ ".successful;\n";
        }
        code ~= "} while (false);\n";
        if (outputMode == 2 && op == "or" && lower)
            code ~= "if (!" ~ target ~ "Ok) s.rollbackOutput(" ~ checkpoint ~ ");\n";
        return code ~ "}\n";
    }

    nothrow unittest {
        Frontend frontend;
        GrammarAnalysis graph;
        const root = frontend.expressionNode(graph, "and!(or!(literal!(\"a\"), literal!(\"b\")), oneOrMore!(option!(literal!(\"x\"))), zeroOrMore!(eps))");
        size_t serial;
        auto code = frontend.emitDirect(graph, root, "p", "result", serial);
        assert(code.length && serial > 10);
        assert(startsWith(code, "size_t resultEnd"));
        serial = 0;
        assert(frontend.emitDirect(graph, root, "p", "result", serial, 64).length);
        foreach (expr; [
            "named!(literal!(\"a\"), \"x\")", "defined!(literal!(\"a\"), \"x\")",
            "keep!(literal!(\"a\"))", "drop!(literal!(\"a\"))", "propagate!(literal!(\"a\"))",
            "discard!(literal!(\"a\"))", "fuse!(literal!(\"a\"))",
            "posLookahead!(literal!(\"a\"))", "negLookahead!(literal!(\"a\"))",
            "predictiveNot!(literal!(\"a\"), 0UL, 0UL, 0UL, 0UL)",
            "dfaToken!(literal!(\"a\"), _dfa, 0, true)",
            "dfaToken!(literal!(\"a\"), _dfa, 0, false)",
            "endOfInput", "space", "blank", "charRange!(97, 122)",
        ]) {
            serial = 0;
            const node = frontend.expressionNode(graph, expr);
            assert(frontend.emitDirect(graph, node, "p", "result", serial, 0, 2).length);
        }
    }

    string emit() nothrow {
        prepareAnalysis();
        foreach (i, ref rule; rules)
            rule.body = emitExpression(analyzed, analyzed.roots[i]);
        bool actionGrammar;
        foreach (rule; rules)
            foreach (i; 0 .. rule.body.length)
                if (startsWith(rule.body[i .. $], "action!("))
                    actionGrammar = true;
        scalarRules = new bool[rules.length];
        foreach (i, rule; rules)
            scalarRules[i] = backend == ParserBackend.direct && !actionGrammar && !params.length
                && !rule.params.length && !analyzed.leftRecursive[i] && !analyzed.conservative
                && (!memoize || selective);
        string result = "struct " ~ name ~ params ~ " {\n";
        if (recordKinds.length) {
            result ~= "enum string[] compactRuleNames = [";
            foreach (i, rule; rules)
                result ~= (i ? ", " : "") ~ quoted(name ~ "." ~ rule.name);
            result ~= "];\nenum uint[] compactRuleKinds = [";
            foreach (i, kind; recordKinds)
                result ~= (i ? ", " : "") ~ number(kind);
            result ~= "];\n";
        }
        if (recordKinds.length) {
            recordLeaves = analyzed.selectedLeaves(recordKinds);
            recordSubtrees = analyzed.selectedSubtrees(recordKinds);
        }
        bool spacingDefined;
        foreach (rule; rules)
            if (rule.name == "Spacing")
                spacingDefined = true;
        if (!spacingDefined)
            result ~= "alias Spacing = npegged.peg.spacing;\n";
        auto ruleChunks = new string[rules.length];
        foreach (ruleIndex, rule; rules) {
            string ruleOut;
            bool cache = memoize && (!selective || analyzed.conservative || analyzed.leftRecursive[ruleIndex]);
            if (params.length || rule.params.length)
                cache = memoize;
            string recordTag;
            if (recordKinds.length) {
                if (recordKinds[ruleIndex] != uint.max)
                    recordTag = ", " ~ number(cast(ulong)recordKinds[ruleIndex] | (
                            recordLeaves[ruleIndex] ? 1UL << 32 : 0UL)) ~ "L";
                else if (recordSubtrees[ruleIndex])
                    recordTag = ", -2L";
                else
                    recordTag = ", -3L";
            }
            if (rule.params.length)
                ruleOut ~= "template " ~ rule.name ~ rule.params ~ " {\n";
            string r = rule.name;
            string entryName = rule.params.length ? "_entry" : r;
            const savedRuleExprs = analyzed.expressions.length;
            scope (exit)
                analyzed.truncate(savedRuleExprs);
            size_t tokenRoot = analyzed.roots[ruleIndex];
            if (rule.body != analyzed.expressions[tokenRoot].source) {
                tokenRoot = expressionNode(analyzed, rule.body);
                analyzed.appendFacts(tokenRoot);
            }
            size_t count;
            string declarations;
            const string body = emitTokens(analyzed, tokenRoot, r, count, declarations);
            ruleOut ~= declarations;
            const directRule = backend == ParserBackend.direct && !actionGrammar
                && !analyzed.leftRecursive[ruleIndex] && !params.length && !rule.params.length;
            bool useDirect, directRecords;
            if (directRule) {
                alias directGraph = analyzed;
                size_t directRoot = tokenRoot;
                if (body != analyzed.expressions[tokenRoot].source) {
                    directRoot = expressionNode(directGraph, body);
                    directGraph.appendFacts(directRoot);
                }
                const op = directGraph.expressions[directRoot].combinator;
                useDirect = op == "and" || op == "or" || op == "predictiveChoice" || op == "zeroOrMore"
                    || op == "oneOrMore"
                    || op == "option" || op == "posLookahead" || op == "negLookahead" || op == "predictiveNot";
                if ((op == "discard" || op == "fuse" || op == "keep" || op == "drop" || op == "propagate"
                        || op == "named" || op == "defined") && directGraph.expressions[directRoot]
                        .children.length) {
                    const child = directGraph.expressions[directRoot].children[0];
                    const childOp = directGraph.expressions[child].combinator;
                    // Sequences/choices and generated rule functions have no scan member.
                    useDirect = childOp == "and" || childOp == "or" || childOp == "predictiveChoice"
                        || directGraph.expressions[child].kind == ExpressionKind.reference;
                }
                if (op == "dfaToken" && directGraph.expressions[directRoot].arguments.length == 4) {
                    string inner = directGraph.expressions[directRoot].arguments[3];
                    while (inner.length && (inner[0] == ' ' || inner[0] == '\t'))
                        inner = inner[1 .. $];
                    directRecords = inner == "true";
                }
                foreach (check; [1, 2]) {
                    directDeclarations = null;
                    this.directRule = r;
                    size_t serial;
                    const cursorBody = emitDirect(directGraph, directRoot, "p", "_result", serial, 0, check);
                    ruleOut ~= directDeclarations;
                    ruleOut ~= (useDirect || check == 2 && directRecords ? "" : "pragma(inline, true) ") ~ "private static bool _cursor_" ~ r ~ "(ref State!(false, " ~ number(
                            check) ~ ") s, ref size_t cursor, ref size_t failure) @nogc nothrow { enum CT = false; const size_t p = cursor;\n" ~ cursorBody ~ "cursor = _resultEnd; failure = _resultFail; return _resultOk; }\n";
                }
                ruleOut ~= "pragma(inline, true) private static State!(CT, Check).Node _direct_" ~ r ~ "(bool CT, int Check)(ref State!(CT, Check) s, size_t p) nothrow { size_t end = p, failure = p; " ~ "const successful = _cursor_" ~ r ~ "(s, end, failure); " ~ "auto result = s.node(p, end, successful); result.successful = successful; result.failEnd = failure; return result; }\n";
            }
            ruleOut ~= "private static State!(CT, Check).Node _" ~ r
                ~ "(bool CT, int Check = 0)(ref State!(CT, Check) s, size_t p) nothrow { ";
            const original = analyzed.expressions[analyzed.roots[ruleIndex]].source;
            if (original != rule.body)
                ruleOut ~= "if (s.context.trace !is null) return defined!(" ~ original ~ ", " ~ quoted(
                        name ~ "." ~ r) ~ ")(s,p); ";
            if (useDirect || directRecords)
                ruleOut ~= "static if (!CT && ((Check == 1 && " ~ (useDirect
                        ? "true" : "false") ~ ") || (Check == 2 && " ~ (useDirect || directRecords
                        ? "true" : "false")
                    ~ "))) { if (s.context.trace is null) return defined!(_direct_"
                    ~ r ~ "!(CT, Check), " ~ quoted(name ~ "." ~ r) ~ ")(s,p); } ";
            ruleOut ~= "return defined!(" ~ body ~ ", " ~ quoted(name ~ "." ~ r) ~ ")(s,p); }\n";
            // Concrete overloads break recursive attribute-inference cycles.
            foreach (mode; [
                "false, false", "true, false", "false, true", "true, true", "false, 2", "true, 2"
            ]) {
                auto attributes = !startsWith(mode, "true") ? " @nogc nothrow" : " nothrow";
                ruleOut ~= "static State!(" ~ mode ~ ").Node " ~ entryName ~ (startsWith(mode, "true")
                        ? "(CompileTime = void)" : "") ~ "(ref State!(" ~ mode ~ ") s, size_t p)" ~ attributes;
                if (actionGrammar && (mode != "false, false" && mode != "true, false"))
                    ruleOut ~= " { return s.treeFallback!(" ~ entryName ~ ")(p); }\n";
                else
                    ruleOut ~= " { return s.rule!(_" ~ r ~ "!(" ~ mode ~ "), " ~ quoted(
                            name ~ "." ~ r) ~ ", " ~ (cache ? "true" : "false") ~ recordTag ~ ")(p); }\n";
            }
            ruleOut ~= "static ParseResult " ~ entryName ~ "(Context)(ref Context ctx, string input) @nogc nothrow if (is(Context == ParseContext)) { return parse!(" ~ entryName ~ ")(ctx,input); }\n";
            ruleOut ~= "static ParseTree " ~ entryName
                ~ "(Input)(Input input) nothrow if (is(Input == string)) { return parseCT!("
                ~ entryName ~ ")(input); }\n";
            if (rule.params.length)
                ruleOut ~= "alias " ~ r ~ " = _entry;\n}\n";
            ruleChunks[ruleIndex] = ruleOut;
        }
        size_t totalLen = result.length;
        foreach (chunk; ruleChunks)
            totalLen += chunk.length;
        auto outBuf = new char[totalLen + 1024];
        outBuf[0 .. result.length] = result[];
        size_t outPos = result.length;
        foreach (chunk; ruleChunks) {
            outBuf[outPos .. outPos + chunk.length] = chunk[];
            outPos += chunk.length;
        }
        result = cast(string)outBuf[0 .. outPos];
        if (!rules[0].params.length) {
            auto first = rules[0].name;
            foreach (mode; [
                "false, false", "true, false", "false, true", "true, true", "false, 2", "true, 2"
            ]) {
                result ~= "static State!(" ~ mode ~ ").Node opCall" ~ (startsWith(mode, "true")
                        ? "(CompileTime = void)" : "") ~ "(ref State!(" ~ mode ~ ") s, size_t p)" ~ (
                        !startsWith(mode, "true") ? " @nogc" : "") ~ " nothrow { auto t = " ~ first
                    ~ "(s,p); " ~ ((mode != "false, false" && mode != "true, false")
                            ? "" : "t.name = " ~ quoted(name) ~ "; ") ~ "return t; }\n";
            }
            result ~= "static ParseResult opCall(Context)(ref Context ctx, string input) @nogc nothrow if (is(Context == ParseContext)) { return parse!(opCall)(ctx,input); }\n";
            result ~= "static ParseTree opCall(Input)(Input input) nothrow if (is(Input == string)) { return parseCT!(opCall)(input); }\n";
        }
        result ~= "}\n";
        return result;
    }
}

nothrow unittest {
    Frontend parser;
    parser.input = "ChoiceTest: Term <- Add / Sub Add <- '+' Term Sub <- '-' Term Cycle <- Cycle";
    parser.read();
    assert(!parser.error.message.length);
    auto emitted = parser.emit();
    assert(startsWith(parser.rules[0].body, "predictiveChoice!("));

    // Test computeFirstSet
    auto firstAdd = parser.computeFirstSet("Add");
    assert(firstAdd.known && !firstAdd.canBeEmpty && firstAdd.mask.contains('+'));
    auto firstSub = parser.computeFirstSet("Sub");
    assert(firstSub.known && !firstSub.canBeEmpty && firstSub.mask.contains('-'));
    assert(!firstAdd.mask.intersects(firstSub.mask));

    // Test literals and escapes in computeFirstSet
    assert(parser.computeFirstSet(`literal!("\n")`).mask.contains('\n'));
    assert(parser.computeFirstSet(`literal!("\r")`).mask.contains('\r'));
    assert(parser.computeFirstSet(`literal!("\t")`).mask.contains('\t'));
    assert(parser.computeFirstSet(`literal!("\0")`).mask.contains('\0'));
    assert(parser.computeFirstSet(`literal!("\\")`).mask.contains('\\'));
    assert(parser.computeFirstSet(`literal!("\"")`).mask.contains('"'));
    assert(parser.computeFirstSet(`literal!("foo")`).mask.contains('f'));
    assert(parser.computeFirstSet(`literal!("")`).canBeEmpty);
    assert(!parser.computeFirstSet(`literal!(`).known);

    // Test charRange
    assert(parser.computeFirstSet("charRange!(97, 122)").mask.contains('a'));
    assert(!parser.computeFirstSet("charRange!(300, 400)").known);
    assert(!parser.computeFirstSet("charRange!(100, 50)").known);
    assert(!parser.computeFirstSet("charRange!(invalid)").known);

    // Test charClass
    assert(parser.computeFirstSet("charClass!(0x1UL, 0x2UL, 0x3UL, 0x4UL)").known);
    assert(parser.computeFirstSet("charClass!(10UL, 20UL, 30UL, 40UL)").known);
    assert(!parser.computeFirstSet("charClass!(invalid)").known);

    // Test combinator unwrapping
    assert(parser.computeFirstSet(`and!(literal!("a"), literal!("b"))`).mask.contains('a'));
    assert(parser.computeFirstSet(`discard!(literal!("a"))`).mask.contains('a'));
    assert(parser.computeFirstSet(`fuse!(literal!("b"))`).mask.contains('b'));
    assert(parser.computeFirstSet(`keep!(literal!("c"))`).mask.contains('c'));
    assert(parser.computeFirstSet(`drop!(literal!("d"))`).mask.contains('d'));
    assert(parser.computeFirstSet(`oneOrMore!(literal!("e"))`).mask.contains('e'));

    // Test predefined symbols
    assert(parser.computeFirstSet("digit").mask.contains('5'));
    assert(parser.computeFirstSet("alpha").mask.contains('k'));
    assert(parser.computeFirstSet("Alpha").mask.contains('K'));
    assert(parser.computeFirstSet("hexDigit").mask.contains('f'));
    assert(parser.computeFirstSet("space").mask.contains(' '));
    assert(parser.computeFirstSet("blank").mask.contains('\n'));
    assert(parser.computeFirstSet("ident").mask.contains('_'));
    assert(parser.computeFirstSet("identifier").mask.contains('_'));
    assert(!parser.computeFirstSet("nonExistentRule").known);
    assert(!parser.computeFirstSet("Cycle").known); // recursion guard

    // Test splitTemplateArgs
    auto args = Frontend.splitTemplateArgs(`A, and!(B, C), literal!(",")`);
    assert(args.length == 3);

    // Test optimizeChoice
    assert(parser.optimizeChoice(["A"]) is null); // less than 2
    assert(parser.optimizeChoice(["unknown1", "unknown2"]) is null);

    // Shared prefixes are extracted before suffix dispatch.
    Frontend overlap;
    overlap.input = "OverlapTest: Term <- 'a' 'b' / 'a' 'c'";
    overlap.read();
    assert(!overlap.error.message.length);
    auto emittedOverlap = overlap.emit();
    assert(startsWith(overlap.rules[0].body, "and!(literal!(\"a\"), predictiveChoice!("));

    // Test character classes in primary
    Frontend charClasses;
    charClasses.input = "CharClasses: Single <- [a] ByteEsc <- [\\xFF] NonAscii <- [\\u03B1-\\u03C9] Mixed <- [a-z\\u03B1-\\u03C9] Empty <- []";
    charClasses.read();
    assert(!charClasses.error.message.length);
    auto emittedClasses = charClasses.emit();
    assert(emittedClasses.length > 0);

    assert(ulongHex(0x1234UL) == "0x1234UL");
    assert(ulongHex(0UL) == "0x0UL");

    Frontend opt;
    opt.input = "Opt: A <- 'a' / 'b' Single <- 'x'";
    opt.read();
    opt.emit();
    assert(opt.optimizeRule("or!(literal!('a'), literal!('b'))").length);
    assert(opt.optimizeRule("or!(literal!('a'), literal!('b'))").length);
    assert(opt.optimizeRule("longest_match!(literal!('a'), literal!('b'))").length);
    assert(opt.optimizeRule("predictiveChoice!(literal!('a'), literal!('b'))").length);
    assert(opt.optimizeRule("option!(literal!('a'))").length);
    assert(opt.optimizeRule("zeroOrMore!(literal!('a'))").length);
    assert(opt.optimizeRule("posLookahead!(literal!('a'))").length);
    assert(opt.optimizeRule("negLookahead!(literal!('a'))").length);
    assert(opt.optimizeRule("named!(literal!('a'), \"name\")").length);
    assert(opt.optimizeRule("branch!(literal!('a'), 0UL, 0UL, 0UL, 0UL)").length);
    assert(opt.optimizeRule("eps").length);
    assert(opt.optimizeRule("eoi").length);
    assert(opt.optimizeRule("endOfInput").length);
    assert(opt.optimizeRule("fail").length);
    assert(opt.optimizeRule("any").length);
    assert(opt.optimizeRule("spacing").length);
    assert(opt.optimizeRule("doublequote").length);
    assert(opt.optimizeRule("backslash").length);
    assert(opt.optimizeRule("quote").length);
    assert(opt.optimizeRule("slash").length);
    assert(opt.optimizeRule("backquote").length);
    assert(opt.optimizeRule("tab").length);
    assert(opt.optimizeRule("endOfLine").length);
    assert(opt.optimizeRule("eol").length);
    assert(opt.primitiveFirstSet("  literal!(\"a\")  ").known);
    assert(opt.primitiveFirstSet("literal!(\"\")").canBeEmpty);
    assert(opt.primitiveFirstSet("charClass!(0x1UL, 0X2UL, 3UL, 4UL)").known);
    assert(opt.primitiveFirstSet("charRange!(  10 ,  20 )").known);
    assert(Frontend.splitTemplateArgs(`"\\", a`).length == 2);
    assert(Frontend.splitTemplateArgs("a, b").length == 2);

    Frontend aheadTest;
    aheadTest.input = "DefAhead: Rule(T = ')') <- 'a' Other <- Rule";
    aheadTest.read();
    assert(!aheadTest.error.message.length);
    assert(aheadTest.emit().length);
}

unittest {
    foreach (definition; [
        "Test(Token = 'x'): A <- List(Token, ',') List(T, S = ',') < T (:S T)*",
        "Test: A <~ '\\u00E9' / '\\U0001F600' / '\\x80' / '\\377'",
        "Test: A <- [a-zé-ê] | 'ABC'i",
        "Test: A <: 'x' B <^ 'y' C <; 'z' D <% A E <{act} 'a'",
        "Test: A <- 'x'{ p => { /* }, */ return p; }, p => p }",
        "Test: A <- 'x'{ p => { /+ }, /+ nested +/ +/ return p; } }",
        "Test: A <- 'x'{ p => { // },\n return p; } }", "Test: A <- ^'x' %B :eoi B <- 'x'",
        "Test: A <- &'a' !'b' ~'c'? :'d'* ;'e'+ %'f' ^'g'",
        "Test: A <- Other.Rule('x') Other2.Thing",
        "Test: A <- 'x' B(X = '(') <- X", "Test: A <- '' / []",
    ]) {
        Frontend parser;
        parser.input = definition;
        parser.read();
        assert(!parser.error.message.length, parser.error.message);
        assert(parser.emit().length);
    }
    foreach (definition; [
        "", "Test:", "Test: A <-", "Test: A <- (", "Test: A <- 'x", "Test: A <- '\\'",
        "Test: A <- '\\uX000'", "Test: A <- '\\UFFFFFFFF'", "Test: A <- '\\u12'",
        "Test: A <- 'a' / 'b' | 'c'", "Test: A <- 'x'{ act", "Test: A(,) <- 'x'",
        "Test: A <- '\xff'", "Test: A <- 'x'{p => { /*", "Test: A <- 'x'{p => { /+"
    ]) {
        Frontend parser;
        parser.input = definition;
        parser.read();
        assert(parser.error.message.length);
    }
    assert(quoted("\0\r\t\x01\x80") == "\"\\0\\r\\t\\x01\\x80\"");
}

nothrow unittest {
    foreach (definition; [
        "Test:\r\t A <- 'a' # trailing comment", "Test: A <- / 'a' / 'b'",
        "Test: A <- | 'a' | 'b'", "Test: A <- [-a-]",
        "Test: A <- '\\b\\f\\v\\uFaBc\\xAf\\0\\07\\078'",
        "Test: A <- 'x'{p => foo('x', [1, 2], `raw`)}", "Test: A <- 'x'{p => p / 2}",
    ])
        assert(generate(definition).status == Status.ok);
    foreach (definition; [
        "Test: A <- @", "Test: A <- [a-", "Test: A <- '\\uD800'", "Test: A <- '\\u12",
        "Test: A <- '\\x", "Test: A <- '\\", "Test: A <- 'x'{p /", "Test: A(X='\\'",
        "Test: A <- 'x'{ // trailing"
    ])
        assert(generate(definition).status == Status.invalidInput);
    auto cached = grammar("Test: A <- 'a'");
    assert(cached.length);
    auto invalid = grammar("Test:");
    assert(invalid.length);
    auto uncached = generate!(Memoization.no)("Test: A <- 'a'");
    assert(uncached.status == Status.ok);
}

private string encode(dchar value) pure nothrow {
    if (value < 0x80)
        return [cast(char)value].idup;
    if (value < 0x800)
        return [cast(char)(0xC0 | value >> 6), cast(char)(0x80 | value & 0x3F)].idup;
    if (value < 0x10000)
        return [
        cast(char)(0xE0 | value >> 12), cast(char)(0x80 | value >> 6 & 0x3F),
        cast(char)(0x80 | value & 0x3F)
    ].idup;
    return [
        cast(char)(0xF0 | value >> 18), cast(char)(0x80 | value >> 12 & 0x3F),
        cast(char)(0x80 | value >> 6 & 0x3F), cast(char)(0x80 | value & 0x3F)
    ].idup;
}

unittest {
    assert(encode('a') == "a");
    assert(encode('é') == "é");
    assert(encode('€') == "€");
    assert(encode('😀') == "😀");
}

/// Returns D source for mixin() or cold runtime generation. Grammar errors become static diagnostics.
string grammar(Memoization memo = Memoization.yes, alias Selector = void,
        ParserBackend backend = ParserBackend.combinators)(string definition) nothrow {
    Frontend frontend;
    frontend.input = definition;
    frontend.memoize = memo != Memoization.no;
    frontend.selective = memo == Memoization.selective;
    frontend.backend = backend;
    frontend.read();
    if (frontend.error.message.length)
        return "static assert(false, " ~ quoted(
                frontend.error.message ~ " at byte " ~ number(frontend.error.offset)) ~ ");";
    frontend.configureRecords!Selector();
    return frontend.emit();
}

unittest {
    enum generated = grammar("Tiny: A <- 'x'+ eoi");
    static assert(generated.length > 0);
    mixin(generated);
    enum result = Tiny("xxx");
    static assert(result.successful && result.matches == ["x", "x", "x"]);
    enum invalid = grammar("Broken: A <- (");
    static assert(invalid.length > 0);
}

nothrow unittest {
    foreach (definition; [
        "DirectCold: Root <- Item+ eoi Item <- '(' Root ')' / 'a' 'x'? / 'b' / eps 'x'",
        "DirectCold: Root <- (!')' Item)* &')' Item <- '(' Root ')' / 'a'",
        "DirectCold: Root <- Item eoi Item <- 'a' Item 'x' / 'b'?", "DirectCold: Root <- [0-9]+ eoi",
        "DirectCold: Root <- Item* eoi Item <- '(' Root ')' / 'abé' / [a-z] '.' / ![()z] .",
        "DirectCold: Root <- '' fail", "DirectCold: Root <- Root '+' [0-9]+ / [0-9]+",
        "DirectCold(T=identifier): Root <- T", "DirectCold: Root <- 'a'{p => p}",
        "DirectCold: Rec <- '(' Rec ')' / 'a' ZStar <- Rec* ZPlus <- Rec+ ZOpt <- Rec? ZPos <- &Rec ZNeg <- !Rec ZPredNot <- !'a' . ZOr <- Rec 'a' / Rec 'b' ZDisc <- :(Rec 'a') ZFuse <- ~(Rec 'a') ZKeep <- ^(Rec 'a' / Rec 'b') ZDrop <- ;('a' / 'b') ZProp <- %Rec",
    ]) {
        auto direct = generate!(Memoization.selective, void, ParserBackend.direct)(definition);
        assert(direct.status == Status.ok && direct.source.length);
    }
    foreach (definition; [
        "DirectCold: Root <- Leaf+ Ignored eoi Leaf <- [a-z] Ignored <: ' '?",
        "DirectCold: Root <- Ignored eoi Ignored <- Leaf Leaf <- [a-z]",
        "DirectCold: Root <- alpha Alpha digit hexDigit . eoi",
        "DirectCold: Root <~ [a-z]+ ':' Leaf Leaf <- [a-z]",
    ]) {
        auto selected = generate!(Memoization.selective, compactTag, ParserBackend.direct)(definition);
        assert(selected.status == Status.ok && selected.source.length);
    }
    auto invalid = generate!(Memoization.selective, void, ParserBackend.direct)("Broken:");
    assert(invalid.status == Status.invalidInput);
}

version (unittest) mixin(grammar(`
RuntimeTest:
    Expr <- Expr '+' Number / Number
    Number <~ [0-9]+
`));

@nogc nothrow unittest {
    ParseContext ctx;
    auto result = RuntimeTest(ctx, "1+2+3");
    assert(result.successful && result.end == 5);
    assert(result.matches == ["1", "+", "2", "+", "3"]);
    assert(result.children[0].name == "RuntimeTest.Expr");
    auto bad = RuntimeTest(ctx, "x");
    assert(!bad.successful);
    ctx.depthLimit = 0;
    auto limited = RuntimeTest(ctx, "1");
    assert(limited.status == Status.resourceLimit);
}

@nogc nothrow unittest {
    foreach (budget; 0 .. 80) {
        ParseContext context;
        context.memoryLimit = budget * 128;
        auto memory = RuntimeTest(context, "1+2+3+4");
        assert(memory.status == Status.ok || memory.status == Status.resourceLimit);
        context = ParseContext.init;
        context.stepLimit = budget;
        auto work = RuntimeTest(context, "1+2+3+4");
        assert(work.status == Status.ok || work.status == Status.resourceLimit);
    }
}

@nogc nothrow unittest {
    ParseContext context;
    foreach (input; ["1+2+3", "x", "1+"]) {
        auto tree = RuntimeTest(context, input);
        auto recognized = check!(RuntimeTest.opCall)(context, input);
        assert(recognized.status == tree.status);
        assert(recognized.successful == tree.successful && recognized.end == tree.end);
        assert(recognized.failEnd == tree.failEnd);
    }
    context.depthLimit = 0;
    assert(check!(RuntimeTest.opCall)(context, "1").status == Status.resourceLimit);
    context = ParseContext.init;
    context.memoryLimit = 0;
    assert(check!(RuntimeTest.opCall)(context, "1").status == Status.resourceLimit);
}

version (unittest) private ParseTree countAction(bool CT)(ref State!CT state, ParseTree tree) nothrow {
    ++*cast(size_t*)state.context.userData;
    return tree;
}

version (unittest) mixin(grammar(`ActionRecognition: Root <- (Root 'a' / 'a'){countAction}`));
version (unittest) mixin(grammar(`PredicateAction: Root <- (&('a'{countAction}) 'a' / 'b') eoi`));
version (unittest) mixin(grammar(`NegativeAction: Root <- !(&('a'{countAction}) 'z') . eoi`));
version (unittest) mixin(grammar(`NegativeBoundary: Root <- !Boundary . eoi Boundary <- eoi / 'a' 'b'`));
version (unittest) mixin(grammar!(Memoization.selective)(`SelectiveAction: Root <- (Root 'a' / 'a'){countAction}`));

@nogc nothrow unittest {
    ParseContext context;
    size_t calls;
    context.userData = &calls;
    auto tree = ActionRecognition(context, "aaa");
    const treeCalls = calls;
    calls = 0;
    auto recognized = check!(ActionRecognition.opCall)(context, "aaa");
    assert(recognized.successful == tree.successful && recognized.end == tree.end);
    assert(calls == treeCalls && calls > 0);
    calls = 0;
    auto selected = check!(SelectiveAction.opCall)(context, "aaa");
    assert(selected.successful && selected.end == tree.end);
    assert(calls == treeCalls && selected.arena.allocationCalls > 0);
}

@nogc nothrow unittest {
    ParseContext context;
    size_t calls;
    context.userData = &calls;
    auto tree = PredicateAction(context, "b");
    assert(tree.successful && calls == 1);
    calls = 0;
    auto recognized = check!(PredicateAction.opCall)(context, "b");
    assert(recognized.successful && calls == 1);
}

@nogc nothrow unittest {
    ParseContext context;
    size_t calls;
    context.userData = &calls;
    assert(check!(NegativeAction.opCall)(context, "a").successful && calls == 1);
    foreach (input; ["", "a", "b", "x", "ab", "ax"]) {
        auto tree = NegativeBoundary(context, input);
        auto result = check!(NegativeBoundary.opCall)(context, input);
        assert(tree.successful == result.successful && tree.end == result.end);
        assert(tree.failEnd == result.failEnd);
    }
    calls = 0;
    context.trace = &countRecordTrace;
    assert(check!(NegativeBoundary.opCall)(context, "x").successful && calls == 2);
}

version (unittest) mixin(grammar!(Memoization.selective)(`
SelectiveLeft:
    Root <- Expr eoi
    Expr <- Expr '+' Number / Number
    Number <~ [0-9]+
`));
version (unittest) mixin(grammar!(Memoization.selective)(`
SelectiveNested:
    Root <- '(' Root ')' / 'x'
`));
version (unittest) mixin(grammar!(Memoization.selective)(`
SelectiveHidden:
    Root <- Prefix? Root 'a' / 'a'
    Prefix <- 'b'
`));

@nogc nothrow unittest {
    ParseContext context;
    foreach (input; ["1+2+3", "x", "1+"]) {
        auto full = RuntimeTest(context, input);
        auto selected = SelectiveLeft.Expr(context, input);
        assert(selected.successful == full.successful && selected.end == full.end);
        auto recognized = check!(SelectiveLeft.Expr)(context, input);
        assert(recognized.successful == selected.successful && recognized.end == selected.end);
    }
    auto nested = check!(SelectiveNested.opCall)(context, "(((x)))");
    assert(nested.successful && nested.end == 7 && nested.arena.allocationCalls == 0);
    auto hidden = check!(SelectiveHidden.opCall)(context, "aaaa");
    assert(hidden.successful && hidden.end == 4 && hidden.arena.allocationCalls > 0);
}

unittest {
    Frontend graph;
    graph.input = "Test: A <- B? C B <- 'b' C <- 'c'";
    graph.read();
    auto first = graph.computeFirstSet("A");
    assert(first.known && !first.canBeEmpty && first.mask.contains('b') && first.mask.contains('c'));
    assert(!graph.computeFirstSet("charRange!(128, 255)").known);
    assert(graph.optimizeRule(`literal!("or!(x)")`) == `literal!("or!(x)")`);
    auto args = Frontend.splitTemplateArgs(`literal!("\\"), literal!("a")`);
    assert(args.length == 2);
    auto selected = grammar!(Memoization.selective)("Nested: A <- '(' A ')' / 'x'");
    assert(selected.length);
}

version (unittest) private uint compactTag(string name) @nogc nothrow pure {
    if (name.length >= 5 && name[$ - 5 .. $] == ".Root")
        return 0;
    if (name.length >= 5 && name[$ - 5 .. $] == ".Leaf")
        return 1;
    if (name.length >= 8 && name[$ - 8 .. $] == ".Ignored")
        return uint.max;
    return 2;
}

version (unittest) mixin(grammar!(Memoization.selective)(`
RecordNested:
    Root <- Ignored Branch eoi
    Ignored <: ' '?
    Branch <- '[' Leaf (',' Leaf)* ']'
    Leaf <~ [a-z]+
`));
version (unittest) mixin(grammar!(Memoization.yes, compactTag)(`
RecordBacktrack:
    Root <- (Branch / Leaf) eoi
    Branch <- Leaf ':' Leaf
    Leaf <~ [a-z]+
`));
version (unittest) mixin(grammar(`
RecordPredicate:
    Root <- &Branch Branch eoi
    Branch <- Leaf
    Leaf <~ [a-z]+
`));
version (unittest) mixin(grammar!(Memoization.selective)(`
RecordLeft:
    Root <- Expr eoi
    Expr <- Expr '+' Leaf / Leaf
    Leaf <~ [0-9]+
`));
version (unittest) mixin(grammar!(Memoization.yes, compactTag)(`
RecordLongest:
    Root <- (Short | Long) eoi
    Short <- Leaf
    Long <- Leaf Leaf
    Leaf <- [a-z]
`));
version (unittest) mixin(grammar(`
RecordAction:
    Root <- Branch eoi
    Branch <- Leaf {countAction}
    Leaf <~ [a-z]+
`));

@nogc nothrow unittest {
    ParseContext context;
    auto nested = parseRecords!(RecordNested.opCall, compactTag)(context, "[a,b]");
    assert(nested.successful && nested.nodes.length == 4);
    assert(nested.nodes[0] == CompactNode(0, 0, 5));
    assert(nested.nodes[1] == CompactNode(2, 0, 5, 0));
    assert(nested.nodes[2] == CompactNode(1, 1, 2, 1));
    assert(nested.nodes[3] == CompactNode(1, 3, 4, 1));
    auto backtrack = parseRecords!(RecordBacktrack.opCall, compactTag)(context, "a");
    assert(backtrack.successful && backtrack.nodes.length == 2);
    assert(backtrack.nodes[1] == CompactNode(1, 0, 1, 0));
    auto predicate = parseRecords!(RecordPredicate.opCall, compactTag)(context, "abc");
    assert(predicate.successful && predicate.nodes.length == 3);
    assert(predicate.nodes[1] == CompactNode(2, 0, 3, 0));
    assert(predicate.nodes[2] == CompactNode(1, 0, 3, 1));
    auto left = parseRecords!(RecordLeft.opCall, compactTag)(context, "1+2+3");
    assert(left.successful && left.nodes.length == 7);
    assert(left.nodes[4] == CompactNode(1, 0, 1, 3));
    assert(left.nodes[5] == CompactNode(1, 2, 3, 2));
    assert(left.nodes[6] == CompactNode(1, 4, 5, 1));
    auto longest = parseRecords!(RecordLongest.opCall, compactTag)(context, "ab");
    assert(longest.successful && longest.nodes.length == 4);
    assert(longest.nodes[1] == CompactNode(2, 0, 2, 0));
    assert(longest.nodes[2] == CompactNode(1, 0, 1, 1));
    assert(longest.nodes[3] == CompactNode(1, 1, 2, 1));
    size_t calls;
    context.userData = &calls;
    auto action = parseRecords!(RecordAction.opCall, compactTag)(context, "abc");
    assert(action.successful && calls == 1 && action.nodes.length == 3);
    assert(action.nodes[2] == CompactNode(1, 0, 3, 1));
    auto bad = parseRecords!(RecordNested.opCall, compactTag)(context, "[a,]");
    assert(!bad.successful && bad.status == Status.mismatch && bad.nodes.length == 0);
    auto limited = parseRecords!(RecordNested.opCall, compactTag)(context, "[a]", 0);
    assert(!limited.successful && limited.status == Status.resourceLimit && limited.nodes.length == 0);
    foreach (budget; 0 .. 100) {
        context = ParseContext.init;
        context.stepLimit = budget;
        auto trial = parseRecords!(RecordLeft.opCall, compactTag)(context, "1+2+3");
        assert(trial.status == Status.ok || trial.status == Status.resourceLimit);
        if (!trial.successful)
            assert(trial.nodes.length == 0);
    }
}

version (unittest) private uint wrongCompactTag(string name) @nogc nothrow pure {
    return uint.max;
}

version (unittest) enum staticRecordDefinition = `StaticRecords:
    Root <- Ignored &Leaf Leaf eoi
    Ignored <: ' '?
    Leaf <~ [a-z]+
`;
version (unittest) mixin(grammar!(Memoization.selective, compactTag)(staticRecordDefinition));

@nogc nothrow unittest {
    ParseContext context;
    auto result = parseRecords!(StaticRecords.opCall, compactTag, false)(context, " abc");
    assert(result.successful && result.nodes.length == 2 && result.input is null);
    assert(result.nodes[0] == CompactNode(0, 0, 4));
    assert(result.nodes[1] == CompactNode(1, 1, 4, 0));
    auto typeEntry = parseRecords!(StaticRecords, compactTag)(context, "abc");
    assert(typeEntry.successful && typeEntry.nodes.length == 2 && typeEntry.input == "abc");
    static assert(!__traits(compiles, parseRecords!(StaticRecords.opCall, wrongCompactTag)(context, "abc")));
    auto owned = parseRecords!(RecordNested.opCall, compactTag)(context, "[a,b]");
    auto borrowed = parseRecords!(RecordNested.opCall, compactTag, false)(context, "[a,b]");
    assert(owned.nodes == borrowed.nodes && borrowed.input is null);
    assert(borrowed.arena.allocationCalls == 0 && owned.arena.allocationCalls == 1);
    auto rejectedLeaf = parseRecords!(StaticRecords.Leaf, compactTag, false)(context, "!", 0);
    assert(rejectedLeaf.status == Status.mismatch && rejectedLeaf.outputArena.allocationCalls == 0);
    auto limitedLeaf = parseRecords!(StaticRecords.Leaf, compactTag, false)(context, "abc", 0);
    assert(limitedLeaf.status == Status.resourceLimit && limitedLeaf.nodes.length == 0);
    assert(limitedLeaf.end == 3);
    foreach (budget; 0 .. 60) {
        context.stepLimit = budget;
        auto checked = check!(StaticRecords.opCall)(context, " abc");
        auto captured = parseRecords!(StaticRecords.opCall, compactTag, false)(context, " abc");
        assert(captured.status == checked.status && captured.end == checked.end);
        assert(captured.failEnd == checked.failEnd);
        if (!captured.successful)
            assert(captured.nodes.length == 0);
    }
}

nothrow unittest {
    auto source = generate!(Memoization.selective, compactTag)(staticRecordDefinition);
    assert(source.status == Status.ok && source.source.length > 0);
}

version (unittest) private void countRecordTrace(string name, size_t pos, bool success, void* user) @nogc nothrow {
    ++*cast(size_t*)user;
}

version (unittest) mixin(grammar!(Memoization.selective, compactTag)(`
RecordLookLeft:
    Root <- Expr eoi
    Expr <- &Expr 'a' / 'a'
`));

@nogc nothrow unittest {
    ParseContext context;
    size_t calls;
    context.userData = &calls;
    context.trace = &countRecordTrace;
    auto checked = check!(RecordLookLeft.opCall)(context, "a");
    const expectedCalls = calls;
    assert(checked.successful && expectedCalls == 2);
    calls = 0;
    auto captured = parseRecords!(RecordLookLeft.opCall, compactTag)(context, "a");
    assert(captured.successful && captured.nodes.length == 2 && calls == expectedCalls);
    foreach (budget; 0 .. 24) {
        context.stepLimit = budget;
        calls = 0;
        auto reference = check!(RecordLookLeft.opCall)(context, "a");
        const referenceCalls = calls;
        calls = 0;
        auto candidate = parseRecords!(RecordLookLeft.opCall, compactTag)(context, "a");
        assert(candidate.status == reference.status && candidate.end == reference.end);
        assert(candidate.failEnd == reference.failEnd && calls == referenceCalls);
    }
}

version (unittest) mixin(grammar!(Memoization.selective, compactTag)(`
ShadowedBuiltin(digit = 'x'):
    Root <- digit / 'y'
`));
version (unittest) mixin(grammar!(Memoization.selective, compactTag)(`
ShadowedRule:
    Root <- Item('x')
    Item(digit = 'x') <- digit / 'y'
`));

@nogc nothrow unittest {
    ParseContext context;
    auto grammarParam = parseRecords!(ShadowedBuiltin!().opCall, compactTag)(context, "x");
    assert(grammarParam.successful && grammarParam.nodes.length == 1);
    auto ruleParam = parseRecords!(ShadowedRule.opCall, compactTag)(context, "x");
    assert(ruleParam.successful && ruleParam.nodes.length == 2);
    assert(check!(ShadowedBuiltin!().opCall)(context, "y").successful);
    assert(!check!(ShadowedBuiltin!().opCall)(context, "1").successful);
}

/// Cold runtime generation reports errors explicitly. Output uses selective druntime GC.
struct GenerationResult {
    Status status = Status.invalidInput;
    string source;
    Diagnostic diagnostic;
}

GenerationResult generate(Memoization memo = Memoization.yes, alias Selector = void,
        ParserBackend backend = ParserBackend.combinators)(string definition, string moduleName = "") nothrow {
    Frontend frontend;
    frontend.input = definition;
    frontend.memoize = memo != Memoization.no;
    frontend.selective = memo == Memoization.selective;
    frontend.backend = backend;
    frontend.read();
    if (frontend.error.message.length)
        return GenerationResult(Status.invalidInput, null, frontend.error);
    frontend.configureRecords!Selector();
    auto source = frontend.emit();
    if (moduleName.length)
        source = "module " ~ moduleName ~ ";\npublic import npegged.peg;\npublic import npegged.dfa;\n" ~ source;
    return GenerationResult(Status.ok, source);
}

unittest {
    auto result = generate("Test: A <- 'a'", "test_generated");
    assert(result.status == Status.ok && result.source.length);
    auto invalid = generate("Test: A <- (");
    assert(invalid.status == Status.invalidInput);
}

Status asModule(Memoization memo = Memoization.yes, alias Selector = void,
        ParserBackend backend = ParserBackend.combinators)(string moduleName, string fileName,
        string definition, string header = "") nothrow {
    import npegged.io : File;

    auto result = generate!(memo, Selector, backend)(definition);
    if (result.status != Status.ok)
        return result.status;
    auto file = File.open(fileName ~ ".d", true);
    if (file.write("// Generated from Pegged-derived npegged grammar. Boost 1.0.\n") != Status.ok)
        return Status.ioError;
    if (file.write("module " ~ moduleName ~ ";\npublic import npegged.peg;\npublic import npegged.dfa;\n") != Status
            .ok)
        return Status.ioError;
    if (header.length && file.write(header ~ "\n") != Status.ok)
        return Status.ioError;
    return file.write(result.source);
}

unittest {
    assert(asModule("test", "/nonexistent/npegged", "Test: A <- 'a'") == Status.ioError);
    assert(asModule("test", "build/invalid", "Test:") == Status.invalidInput);
    assert(asModule("test", "build/roundtrip", "Test: A <- 'a'", "// custom header") == Status.ok);
}

/// Generate from a successful grammar parse while its owning result remains alive.
string grammar(Memoization memo = Memoization.yes, alias Selector = void,
        ParserBackend backend = ParserBackend.combinators)(scope const ref ParseTree definition) nothrow {
    if (!definition.successful)
        return "static assert(false, `Cannot generate from a failed grammar parse`);";
    return grammar!(memo, Selector, backend)(definition.input);
}

nothrow unittest {
    import npegged.parser : Pegged;

    ParseContext context;
    auto parsed = Pegged(context, "TreeInput: A <- 'a'");
    auto source = grammar(parsed.tree);
    assert(source.length);
    ParseTree invalid;
    auto failure = grammar(invalid);
    assert(failure.length);
}

/// Borrow a scoped file and generate a parser module, preserving I/O error status.
Status asModule(Memoization memo = Memoization.yes, alias Selector = void,
        ParserBackend backend = ParserBackend.combinators)(string moduleName, string destination,
        ref npegged.io.File input, string header = "") nothrow {
    import npegged.storage : Buffer;

    Buffer!char text;
    auto status = input.read(text);
    if (status != Status.ok)
        return status;
    return asModule!(memo, Selector, backend)(moduleName, destination, cast(string)text.data, header);
}

nothrow unittest {
    import npegged.io : File;

    File invalid;
    assert(asModule("test", "build/from-file", invalid) == Status.ioError);
    {
        auto output = File.open("build/input.peg", true);
        assert(output.write("FromFile: A <- 'a'") == Status.ok);
    }
    auto input = File.open("build/input.peg");
    assert(asModule("from_file", "build/from-file", input) == Status.ok);
}

version (unittest) mixin(grammar(`RawBytes: Start <- [\xFF] :eoi`));
@nogc nothrow unittest {
    ParseContext context;
    auto raw = RawBytes(context, "\xff");
    assert(raw.successful && raw.end == 1);
    auto unicode = RawBytes(context, "ÿ");
    assert(!unicode.successful);
}
